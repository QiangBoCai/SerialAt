package com.example.shentan;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.example.shentan.service.ForegroundCoreService;
import com.example.shentan.catchExection.MyCrashHandler;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.singleton.DeviceStateSingleton;
import com.example.shentan.singleton.TCPIPConnectSingleton;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.ATConstant;
import com.example.shentan.util.Constant;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;
import com.example.shentan.util.WriteLogUtil;

import org.json.JSONObject;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

public class MainActivity extends SerialPortActivity implements View.OnClickListener {

    Button sim_1;
    Button sim_2;
    Button sim_3;
    Button restart_modem;
    Button cipshut;
    Button send_at;
    Button reboot;
    Button serialport_open;
    Button serialport_close;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Intent intent = new Intent(this, ForegroundCoreService.class);
        stopService(intent);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtil.print("enter MainActivity onCreate ...");
        setContentView(R.layout.activity_main);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LogUtil.print("开启线程捕获异常.写入文件中");
        Thread.currentThread().setUncaughtExceptionHandler(MyCrashHandler.INSTANCE);
        LogUtil.print("开启前台保活服务 ForegroundCoreService");
        Intent intent = new Intent(this, ForegroundCoreService.class);
        startService(intent);
        LogUtil.print("初始化按钮及监听事件");
        cipshut = findViewById(R.id.cipshut);//重连TCP
        send_at = findViewById(R.id.send_at);//向后台发送测试数据
        reboot = findViewById(R.id.reboot);//重启
        sim_1 = findViewById(R.id.sim_1);//切换sim 1
        sim_2 = findViewById(R.id.sim_2);//切换sim 2
        sim_3 = findViewById(R.id.sim_3);//切换sim 3
        restart_modem = findViewById(R.id.restart_modem);//重启modem，检测信号
        serialport_open = findViewById(R.id.serialport_open);//打开串口
        serialport_close = findViewById(R.id.serialport_close);//关闭串口

        cipshut.setOnClickListener(this);
        send_at.setOnClickListener(this);
        reboot.setOnClickListener(this);
        sim_1.setOnClickListener(this);
        sim_2.setOnClickListener(this);
        sim_3.setOnClickListener(this);
        serialport_open .setOnClickListener(this);
        serialport_close.setOnClickListener(this);
        restart_modem.setOnClickListener(this);
    }


    @SuppressLint("NonConstantResourceId")

    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.cipshut: {
                onDataReceivedTcpIp(Constant.TCP_CLOSED);
                break;
            }
            case R.id.send_at: {

                String sendStr = "{\"cpin\":\"1\", \"tac\":\"0X4B1200\", \"eci\":\"0XB417A102\", \"pci\":\"250\", \"arfcn\":\"633984\", \"rssi\":\"-102\", \"state\":\"0\", \"sysinfo\":{\"srvStatus\":\"2\", \"srvDomain\":\"2\", \"roamStatus\":\"0\", \"sysMode\":\"12\", \"simState\":\"1\"}, \"devCode\":\"864023040034073\", \"infoCode\":\"B01\", \"channelCode\":\"null\", \"packId\":\"e96b57a7-a916-43f2-a570-17efbf9c57ff\", \"sign\":\"04b49d827c59e993503f53171a1db020\", \"sysTime\":\"1629873299101\"}";
                sendCommandTo4G(sendStr, bufferedOutputStream);

                break;
            }


            case R.id.reboot: {
                Constant.Interrupted_Need_Restart = false;

                CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            FutureTask<Boolean> futureTask = futureTaskUtils.reboot();
                            CachedThreadPoolSingleton.getInstance().execute(futureTask);

                            futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                });
                break;
            }

            case R.id.sim_1: {
                setOperator(Constant.CODE_1);
                break;
            }
            case R.id.sim_2: {
                setOperator(Constant.CODE_2);
                break;
            }
            case R.id.sim_3: {
                setOperator(Constant.CODE_3);
                break;
            }
            case R.id.restart_modem: {

                if (iservice != null){
                    CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                FutureTask<Boolean> futureTask = futureTaskUtils.restartModemFutureTask();

                                CachedThreadPoolSingleton.getInstance().execute(futureTask);
                                futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    });
                }

                break;
            }
            case R.id.serialport_open : {
                open4GSerialPort();
                break;
            }
            case R.id.serialport_close : {
                close4GSerialPort(false);
                break;
            }



            default:
                break;
        }

    }


    private final StringBuilder receiveSB = new StringBuilder();
    private final StringBuilder packIdSB = new StringBuilder();

    @Override
    public void onDataReceivedTcpIp(final String receiveWebData) {

        Utils.clearSB(receiveSB);
        LogUtil.print("enter into onDataReceivedTcpIp  receiveWebData:"+receiveWebData);
        //若是主动关闭链接后再重新建立连接，在ATConstant.ATCIPSTATUS这一步可能会收到连接状态为CLOSED，所以需要排除这个情况
        //【如果上报"+PDP:DEACT"，标识 GPRS 被网络释放，此时仍然需要执行 AT+CIPSHUT 来改变状态。】若收到Constant.PDP_DEACT，需要重新建立连接
        if (!Constant.AT_STEP_4G.toString().equals(ATConstant.ATCIPSTATUS) &&
                (receiveWebData.contains(Constant.TCP_CLOSED) || receiveWebData.contains(Constant.PDP_DEACT))){
            WriteLogUtil.d("连接断开","连接断开");
            LogUtil.print("连接断开");
            //关闭TCP连接
            Constant.TCP_OPEN=false;
            add4GStr(ATConstant.ATCIPCLOSE,false,false);
            return;
        }

        //收到了mcu数据
        if (receiveWebData.contains(Constant.MCU_PRE)){
            LogUtil.print("收到mcu数据");
            businessDeal.setBusinessStrategy(mcuStrategy).dealBusiness(receiveWebData);
            return;
        }
        //数据已发送给串口
        if (receiveWebData.contains(Constant.DATA_ACCEPT)){
            webReceivedData(true);
        }

        //如果TCPIP通道没打开，则打开通道
        //将 ATConstant.ATCIPSEND 的逻辑也放在打开通道这里处理，因为另一部分都是跟模块交互的数据，避免跟后台数据混合
        //不是json数据并且符合其他条件
        LogUtil.print("!Utils.isJson(receiveWebData) "+!Utils.isJson(receiveWebData));
        if (!Utils.isJson(receiveWebData)&&
                (!Constant.ACTIVE_4G ||
                 !Constant.TCP_OPEN ||
                 Constant.AT_STEP_4G.toString().equals(ATConstant.ATCIPSEND)||
                 Constant.AT_STEP_4G.toString().equals(ATConstant.ATCIPSHUT)||
                 Constant.AT_STEP_4G.toString().equals(ATConstant.AT_CGSN)||
                 Constant.AT_STEP_4G.toString().equals(ATConstant.ATCIPCLOSE))){
            //进入AtStrategy
            LogUtil.print("进入AtStrategy");
            businessDeal.setBusinessStrategy(atStrategy).dealBusiness(receiveWebData);
            return;
        }

        if (!receiveWebData.contains("infoCode")){
            LogUtil.print("不包含infoCode return");
            return;
        }


        JSONObject jsonObject;

        try {

            jsonObject = new JSONObject(receiveWebData);
            Constant.infoCode = (String)jsonObject.get("infoCode");
            LogUtil.print("Constant.infoCode:"+Constant.infoCode);

        } catch (Exception e) {
            //没有infoCode则返回
            LogUtil.print("json 解析异常");
            return;
        }

        //收到业务指令消息，但设备正忙
        if (DeviceStateSingleton.INSTANCE.isDeviceBusyState()&&(
                Constant.infoCode.equals(Constant.NO_RESTART)||
                        Constant.infoCode.equals(Constant.NO_PHONE)||
                        Constant.infoCode.equals(Constant.NO_SMS)||
                        Constant.infoCode.equals(Constant.NO_APP)||
                        Constant.infoCode.equals(Constant.NO_BROWSER)
        )){
            WriteLogUtil.d(Constant.RECEIVE_DATA_FROM_WEB_ERR,"收到infoCode = "+Constant.infoCode +"，但设备正忙");
            LogUtil.print("收到infoCode = "+Constant.infoCode +"，但设备正忙");

            try {
                Utils.replaceSB(packIdSB,jsonObject.get("packId").toString());
                sendCommonReturnToWebFail(Constant.infoCode, packIdSB.toString(),"设备正忙");
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }

        switch (Constant.infoCode){

            case Constant.NO_HEART : {
                TCPIPConnectSingleton.INSTANCE.setDeviceState();
                //不需要break，接收到心跳包也需要调用webReceivedData方法
            }
            case Constant.NO_RESTART_RESULT :
            case Constant.NO_PHONE_RESULT :
            case Constant.NO_SMS_RESULT :
            case Constant.NO_APP_RESULT:
            case Constant.NO_BROWSER_RESULT : {
                //在收到串口回复DATA ACCEPT时已经设置了，此处不能删除的原因是防止串口没回复DATA ACCEPT
                webReceivedData(true);
                break;
            }

            default : {
                //通过infoCode获取对应的策略
                LogUtil.print("通过infoCode获取对应的策略");
                BusinessStrategy businessStrategy = strategyFactory.getStrategy(Constant.TotalStrategyMapEnum.MAP_TYPE_BUSINESS,Constant.infoCode);
                businessStrategy.dealBusiness(receiveWebData);
                break;

            }

        }

    }
}