package com.example.shentan.catchExection;

import com.example.shentan.util.WriteLogUtil;
import org.jetbrains.annotations.NotNull;

public enum MyCrashHandler implements Thread.UncaughtExceptionHandler {

    INSTANCE;


    /**
     * 当程序中有未被捕获的异常，系统会自动调用uncaughtException()这个方法
     * @param t 为出现未捕获异常的线程
     * @param ex 为未捕获的异常，包含异常信息
     */
    @Override
    public void uncaughtException(@NotNull Thread t, @NotNull Throwable ex) {
        WriteLogUtil.d("__uncaughtException","t.getName = "+t.getName()+ " ex.getMessage = "+ex.getMessage());
    }
}
