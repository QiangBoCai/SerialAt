package com.example.shentan.util;

import com.google.gson.JsonObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class IpConfigUtil {

    public static String ip_file_name = "0_IP_CONFIG.txt";
    public static final String SERVER_IP ="180.169.180.122";// "61.177.139.106";
    public static final String SERVER_PORT = "17001";
    public static void createIPFile(){
        isExist(WriteLogUtil.PATH_LOG);

        try {

            File file = new File(WriteLogUtil.PATH_LOG, ip_file_name);
            if (!file.exists()) {
                file.createNewFile();
                FileOutputStream outStream = new FileOutputStream(file);
				///data/media/0/Log/0_IP_CONFIG.txt
//                {"ip":"180.169.180.122","port":17001}
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("ip",SERVER_IP);
                jsonObject.addProperty("port",SERVER_PORT);
                outStream.write(jsonObject.toString().getBytes());
                outStream.close();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static String ReadIPFile() {
        String result=null;
        try {
            File f=new File(WriteLogUtil.PATH_LOG + "/"+ ip_file_name);
            int length=(int)f.length();
            byte[] buff=new byte[length];
            FileInputStream fin=new FileInputStream(f);
            fin.read(buff);
            fin.close();
            result=new String(buff,"UTF-8");
        }catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 判断文件夹是否存在,如果不存在则创建文件夹
     */
    public static void isExist(String path) {
        File file = new File(path);
        if (!file.exists()) {
            file.mkdirs();
        }
    }
}
