package com.example.shentan.util;

import android.util.SparseArray;

public class ATConstant {


    /**
     * TCPIP通信指令
     * 收到TCPIP通道关闭需要去开启
     */


    //回车换行 占两个字节
    public static final String RETURN = "\r\n";
    public static final String RETURN_HEX = "0d0a";
    //循环发送AT;收到OK(开机检测模块，通过发送AT指令自动训练波特率)
    public static final String AT = "AT";


    //关闭移动网络
    public static final String ATCIPSHUT = "AT+CIPSHUT";
    //进入飞行模式(等待5秒然后AT+CFUN=1)
    public static final String ATCFUN0 = "AT+CFUN=0";
    //退出飞行模式
    public static final String ATCFUN1 = "AT+CFUN=1";
    //查询卡状态;收到+CPIN: READY(检查是否插卡，间隔500ms发送，尝试20次，失败则重启模块，因为不支持热插拔)
    //返回的数据使用 +CPIN: 判断
    public static final String ATCPIN = "AT+CPIN?";
    //查看当前GPRS附着状态;收到+CGATT: 1
    public static final String ATCGATT = "AT+CGATT?";
    //设置为单链接模式(配置TCP的连接通道方式)
    public static final String ATCIPMUX = "AT+CIPMUX=0";
    //设置为快发模式（推荐使用这种模式）(发送模式)
    public static final String ATCIPQSEND = "AT+CIPQSEND=1";
    //启动任务，设置APN;收到OK
    public static final String ATCSTT = "AT+CSTT";
    //激活移动场景，获取IP地址;收到OK(未收到，最多等待90秒)
    public static final String ATCIICR = "AT+CIICR";
    //查询分配的IP地址
    public static final String ATCIFSR = "AT+CIFSR";
    //查询链接状态;收到STATE: IP STATUS;收到STATE: CONNECT O(IP状态未准备好)
    public static final String ATCIPSTATUS = "AT+CIPSTATUS";
    //配置连接;收到CONNECT OK(连接不成功，最多等75秒)  AT+CIPSTART="TCP","61.177.139.106",17001
    //AT+CIPSTART="TCP","180.169.180.122",17001
    public static final String ATCIPSTART = "AT+CIPSTART=\"TCP\",";

    public static final SparseArray<String> tcpList = new SparseArray<String>(){{
        put(Constant.DIGIT_0,ATCIPSHUT);
        put(Constant.DIGIT_1,ATCFUN0);
        put(Constant.DIGIT_2,ATCFUN1);
        put(Constant.DIGIT_3,ATCPIN);
        put(Constant.DIGIT_4,ATCGATT);
        put(Constant.DIGIT_5,ATCIPMUX);
        put(Constant.DIGIT_6,ATCIPQSEND);
        put(Constant.DIGIT_7,ATCSTT);
        put(Constant.DIGIT_8,ATCIICR);
        put(Constant.DIGIT_9,ATCIFSR);
        put(Constant.DIGIT_10,ATCIPSTATUS);
        put(Constant.DIGIT_11,ATCIPSTART);
    }};





    //重启4G模块
    public static final String ATRESET = "AT+RESET";

    //查询当前GPRS注册状态;(通常两分钟内都可以注册，如果超过2分钟没有注册则进飞行模式)
    public static final String ATCREG = "AT+CREG?";



    //设置接收的数据末尾是否自动添加回车换行
    public static final String ATCIPRXF =  "AT+CIPRXF=0";
    //发送数据（不定长度，手动发送）
    public static final String ATCIPSEND = "AT+CIPSEND=";

    //关闭 TCP 连接
    public static final String ATCIPCLOSE = "AT+CIPCLOSE";


    /**
     * 循环上报设备信息
     */

    //IMEI
    public static final String AT_CGSN = "AT+CGSN";

}
