package com.example.shentan.util;


import com.odmsz.control.RILConstants;

import java.util.HashMap;
import java.util.Map;

public class Constant {

    public static final String GAODE_PACKAGE_NAME = "com.autonavi.minimap";
    public static final String WEBVIEW_PACKAGE_NAME = "mark.via";

    public static final String ODMSZ_TOKEN = "odmsz";


    /**
     * 当前运营商标志  1：移动，2：电信，3：联通
     */
    public static int OPERATOR_FLAG = 1;
    public static final int OPERATOR_FLAG_YD = 1;
    public static final int OPERATOR_FLAG_DX = 2;
    public static final int OPERATOR_FLAG_LT = 3;

    //接收到新短信标志
    public static String RECEIVE_NEW_SMS = "";
    //存储无需应答的号码
    public static String PHONE_DISRESPONSE_NUMBER = "";

    public static final String SECRET_KEY = "stdz2021";


    /**
     * WriteLogUtil  TAG
     */
    //发送AT指令错误
    public static final String SEND_AT_TAG_INFO = "SendATInfo";
    public static final String SEND_AT_TAG_ERR = "SendATErr";
    //4G模块启动成功(发送AT指令能收到回复)
    public static final String START_MODULE_4G_SUCCESS = "StartModule4GSuccess";
    public static final String START_MODULE_4G_ERR = "StartModule4GErr";

    //读写ip配置文件
    public static final String IPCONFIG_TAG_Success = "IpConfigSuccess";
    public static final String IPCONFIG_TAG_ERR = "IpConfigErr";
    //建立TcpIp通道
    public static final String TCPIP_TAG_INFO = "TcpIpInfo";
    public static final String TCPIP_TAG_ERR = "TcpIpErr";
    public static final String TCPIP_TAG_SUCCESS = "TcpIpSuccess";

    //4G模块串口收到WEB数据
    public static final String RECEIVE_DATA_FROM_WEB_ERR = "ReceiveDataFromWebErr";
    public static final String RECEIVE_DATA_FROM_WEB = "ReceiveDataFromWeb";
    //5G模块串口收到WEB数据
    public static final String RECEIVE_DATA_FROM_5G = "ReceiveDataFrom5G";
    //收到WEB的数据后，给WEB回复收到
    public static final String RETURN_RECEIVE_TO_WEB = "ReturnReceiveToWeb";

    //5G模块重启
    public static final String RESTART_5G_TAG_ERR = "Restart5GErr";
    public static final String RESTART_5G_TAG_SUCCESS = "Restart5GSuccess";
    //设备信息
    public static final String DEVICE_TAG_ERR = "DeviceErr";
    public static final String DEVICE_TAG_SUCCESS = "DeviceSuccess";

    //语音通话
    public static final String PHONE_TAG_ERR = "PhoneErr";
    public static final String PHONE_TAG_SUCCESS = "PhoneSuccess";
    //短信
    public static final String SMS_TAG_ERR = "SmsErr";
    public static final String SMS_TAG_SUCCESS = "SmsSuccess";
    public static final String SMS_TAG_INFO = "SmsInfo";
    //高德地图
    public static final String GAODE_TAG_ERR = "GaoDeErr";
    public static final String GAODE_TAG_SUCCESS = "GaoDeSuccess";
    //微信
    public static final String WEICHAT_TAG_ERR = "WeiChatErr";
    public static final String WEICHAT_TAG_SUCCESS = "WeiChatSuccess";
    //网页
    public static final String BROWSER_TAG_ERR = "BrowserErr";
    public static final String BROWSER_TAG_SUCCESS = "BrowserSuccess";
    //获取ICCID
    public static final String ICCID_TAG_ERR = "ICCIDErr";
    public static final String ICCID_TAG_SUCCESS = "ICCIDSuccess";
    //删除前转
    public static final String DELETE_TRANSFER_ERR = "DeleteTransferErr";
    public static final String DELETE_TRANSFER_SUCCESS = "DeleteTransferSuccess";


    /**
     * 检测模块是否启动标志
     */
    //true 则表示给4G模块发送at指令能收到响应，说明串口已经能收发数据
    public static boolean ACTIVE_4G = false;
    //TCP是否连接成功标志，连接成功才能给后端发送数据
    public static boolean TCP_OPEN = false;

    /**
     * 串口路径
     */
    public static final String PORT_4G = "/dev/ttyMSM0";

    /**
     * 业务编号
     */



    //region 业务对应的编号相关


    //存储指令编号
    public static String infoCode;
    //存储指令编号中的业务编号，为了与指令编号区分开
    public static String infoCode_business;

    public static final String NO_HEART = "B01";
    public static final String NO_RESTART = "B02";
    public static final String NO_RESTART_RESULT = "B03";
    public static final String NO_PHONE = "B04";
    public static final String NO_PHONE_RESULT = "B05";
    public static final String NO_SMS = "B06";
    public static final String NO_SMS_RESULT = "B07";
    public static final String NO_APP = "B08";
    public static final String NO_APP_RESULT = "B09";
    public static final String NO_BROWSER = "B10";
    public static final String NO_BROWSER_RESULT = "B11";
    public static final String NO_GET_ICCID = "B12";
    public static final String NO_GET_ICCID_RESULT = "B13";
    public static final String CODE_SUCCESS = "200";
    public static final String CODE_FAIL = "201";
    //endregion


    public static final String MSG_SUCCESS = "成功";
    public static final String MSG_FAIL = "失败";
    public static final String PARAMS_ERR = "参数错误";


    //region 存储业务策略的key
    public enum TotalStrategyMapEnum {
        MAP_TYPE_BUSINESS,MAP_TYPE_PHONE,MAP_TYPE_SMS,MAP_TYPE_APP
    }//endregion

    //2E是小数点
    public static final String DECIMAL = "2E";
    //2C是逗号
    public static final String COMMA= "2C";


    //region 通用数字或字符串数字
    public static final String CODE_1_NEGATIVE = "-1";
    public static final String CODE_0 = "0";
    public static final String CODE_1 = "1";
    public static final String CODE_2 = "2";
    public static final String CODE_3 = "3";
    public static final String CODE_4 = "4";
    public static final String CODE_5 = "5";
    public static final String CODE_6 = "6";
    public static final String CODE_7 = "7";
    public static final String CODE_8 = "8";
    public static final String CODE_9 = "9";
    public static final String CODE_10 = "10";
    public static final String CODE_11 = "11";
    public static final String CODE_12 = "12";
    public static final String CODE_13 = "13";
    public static final String CODE_14 = "14";
    public static final String CODE_15 = "15";
    public static final String CODE_16 = "16";
    public static final int DIGIT_1_negative = -1;
    public static final int DIGIT_0 = 0;
    public static final int DIGIT_1 = 1;
    public static final int DIGIT_2 = 2;
    public static final int DIGIT_3 = 3;
    public static final int DIGIT_4 = 4;
    public static final int DIGIT_5 = 5;
    public static final int DIGIT_6 = 6;
    public static final int DIGIT_7 = 7;
    public static final int DIGIT_8 = 8;
    public static final int DIGIT_9 = 9;
    public static final int DIGIT_10 = 10;
    public static final int DIGIT_11 = 11;
    public static final int TRY_FAIL_TIMES = 20;
    //endregion

    //4G模块AT指令步骤标志
    public static StringBuffer AT_STEP_4G = new StringBuffer();

    //在线程被异常中断时，判断是否需要去重启线程
    public static volatile boolean Interrupted_Need_Restart = false;


    public static String OK = "OK";
    public static String ERROR = "ERROR";
    public static final String RESPONSE_OK = "OK";
    public static final String RESPONSE_READY = "READY";
    public static final String RESPONSE_CGATT_0 = "+CGATT: 0";
    public static final String RESPONSE_CGATT_1 = "+CGATT: 1";
    public static final String RESPONSE_CONNECT_OK = "CONNECT OK";
    public static final String RESPONSE_ALREADY_CONNECT = "ALREADY CONNECT";
    public static final String RESPONSE_STATE_CONNECT_OK = "CONNECT OK";
    public static final String ERROR_3 = "ERROR: 3";
    public static final String TCP_CLOSED = "CLOSED";
    public static final String PDP_DEACT = "+PDP:DEACT";


    //region 微信部分
    public static final String WXTOOL_PACKAGE_NAME = "org.odmsz.wxtools";
    public static final String WXTOOL_CLASS_NAME = "org.odmsz.wxtools.external.open.RunIntentActivity";

    //0.一键顺序执行所有主动示例
    public static final String ALL_ACTION = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/0.一键顺序执行所有主动示例.js";
    //1.查看好友头像
    public static final String LOOK_FRIEND_HEARD_KEY = "1.查看好友头像";
    public static final String LOOK_FRIEND_HEARD = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/1.查看好友头像.js";
    //2.查看朋友圈
    public static final String LOOK_CIRCLE_KEY = "5.查看朋友圈";
    public static final String LOOK_CIRCLE = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/5.查看朋友圈.js";
    //3.查看群好友头像
    public static final String LOOK_GROUP_FRIEND_HEARD_KEY = "2.查看群好友头像";
    public static final String LOOK_GROUP_FRIEND_HEARD = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/2.查看群好友头像.js";
    //4.点对点发送视频通话
    public static final String REQUEST_VIDEO_POINT_TO_POINT_KEY = "9.点对点发送视频通话";
    public static final String REQUEST_VIDEO_POINT_TO_POINT = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/9.点对点发送视频通话.js";
    //5.点对点发送文件
    public static final String SEND_FILE_POINT_TO_POINT_KEY = "7.点对点发送文件";
    public static final String SEND_FILE_POINT_TO_POINT = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/7.点对点发送文件.js";
    //6.点对点发送文字消息
    public static final String SEND_TEXT_POINT_TO_POINT_KEY = "6.点对点发送文字消息";
    public static final String SEND_TEXT_POINT_TO_POINT = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/6.点对点发送文字消息.js";
    //7.点对点发送语音通话
    public static final String REQUEST_SOUND_POINT_TO_POINT_KEY = "8.点对点发送语音通话";
    public static final String REQUEST_SOUND_POINT_TO_POINT = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/8.点对点发送语音通话.js";
    //8.点对点接收通话10s以上挂断
    public static final String ANSWER_AND_BREAK_ABOVE_TEN_SECONDS_POINT_TO_POINT_KEY = "3.点对点接收通话10s以上挂断";
    public static final String ANSWER_AND_BREAK_ABOVE_TEN_SECONDS_POINT_TO_POINT = "/data/data/org.odmsz.wxtools/files/sample/2.被动示例_V2/2.点对点接收通话10s以上挂断.js"
            ;
    //9.点对点接收文件并下载
    public static final String RECEIVE_AND_DOWNLOAD_FILE_POINT_TO_POINT = "/data/data/org.odmsz.wxtools/files/sample/2.被动示例_V2/1.接收文字消息并回复和下载文件.js";
    //10.点对点接收文字消息并回复
    public static final String RECEIVE_AND_RESPONSE_TEXT_POINT_TO_POINT = "/data/data/org.odmsz.wxtools/files/sample/2.被动示例_V2/1.接收文字消息并回复和下载文件.js";
    //11.发朋友圈1_文字
    public static final String SHOW_TO_CIRCLE_WITH_TEXT_KEY = "3.发朋友圈1_文字";
    public static final String SHOW_TO_CIRCLE_WITH_TEXT = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/3.发朋友圈1_文字.js";
    //12.发朋友圈2_文字和照片
    public static final String SHOW_TO_CIRCLE_WITH_TEXT_AND_PHOTO_KEY = "4.发朋友圈2_文字和照片";
    public static final String SHOW_TO_CIRCLE_WITH_TEXT_AND_PHOTO = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/4.发朋友圈2_文字和照片.js";
    //13.群内发送文件
    public static final String SEND_FILE_IN_GROUP_KEY = "11.群内发送文件";
    public static final String SEND_FILE_IN_GROUP = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/11.群内发送文件.js";
    //14.群内发送文字消息
    public static final String SEND_TEXT_IN_GROUP_KEY = "10.群内发送文字消息";
    public static final String SEND_TEXT_IN_GROUP = "/data/data/org.odmsz.wxtools/files/sample/1.主动示例_V2/10.群内发送文字消息.js";
    //15.群内接收文件
    public static final String RECEIVE_GROUP_FILE = "/data/data/org.odmsz.wxtools/files/sample/2.被动示例_V2/1.接收文字消息并回复和下载文件.js";
    //16.群内接收文字回复消息
    public static final String RECEIVE_AND_RESPONSE_TEXT_IN_GROUP = "/data/data/org.odmsz.wxtools/files/sample/2.被动示例_V2/1.接收文字消息并回复和下载文件.js";

    public static final String RECEIVE_AND_RESPONSE_AND_DOWNLOAD = "1.接收文字消息并回复和下载文件";
    public static final String RECEIVE_AND_RESPONSE_AND_DOWNLOAD_TEXT = "回复文字消息";
    public static final String RECEIVE_AND_RESPONSE_AND_DOWNLOAD_FILE = "下载文件来自";

    public static Map<String,String> weiChat_action_map = new HashMap<String,String>(){{
        this.put(Constant.CODE_1,LOOK_FRIEND_HEARD);
        this.put(Constant.CODE_2,LOOK_CIRCLE);
        this.put(Constant.CODE_3,LOOK_GROUP_FRIEND_HEARD);
        this.put(Constant.CODE_4,REQUEST_VIDEO_POINT_TO_POINT);
        this.put(Constant.CODE_5,SEND_FILE_POINT_TO_POINT);
        this.put(Constant.CODE_6,SEND_TEXT_POINT_TO_POINT);
        this.put(Constant.CODE_7,REQUEST_SOUND_POINT_TO_POINT);
        this.put(Constant.CODE_8,ANSWER_AND_BREAK_ABOVE_TEN_SECONDS_POINT_TO_POINT);
        this.put(Constant.CODE_9,RECEIVE_AND_DOWNLOAD_FILE_POINT_TO_POINT);
        this.put(Constant.CODE_10,RECEIVE_AND_RESPONSE_TEXT_POINT_TO_POINT);
        this.put(Constant.CODE_11,SHOW_TO_CIRCLE_WITH_TEXT);
        this.put(Constant.CODE_12,SHOW_TO_CIRCLE_WITH_TEXT_AND_PHOTO);
        this.put(Constant.CODE_13,SEND_FILE_IN_GROUP);
        this.put(Constant.CODE_14,SEND_TEXT_IN_GROUP);
        this.put(Constant.CODE_15,RECEIVE_GROUP_FILE);
        this.put(Constant.CODE_16,RECEIVE_AND_RESPONSE_TEXT_IN_GROUP);
    }};
    public static Map<String,String> weiChat_action_map_key = new HashMap<String,String>(){{
        this.put(LOOK_FRIEND_HEARD_KEY                                  ,Constant.CODE_1);
        this.put(LOOK_CIRCLE_KEY                                        ,Constant.CODE_2);
        this.put(LOOK_GROUP_FRIEND_HEARD_KEY                            ,Constant.CODE_3);
        this.put(REQUEST_VIDEO_POINT_TO_POINT_KEY                       ,Constant.CODE_4);
        this.put(SEND_FILE_POINT_TO_POINT_KEY                           ,Constant.CODE_5);
        this.put(SEND_TEXT_POINT_TO_POINT_KEY                           ,Constant.CODE_6);
        this.put(REQUEST_SOUND_POINT_TO_POINT_KEY                       ,Constant.CODE_7);
        this.put(ANSWER_AND_BREAK_ABOVE_TEN_SECONDS_POINT_TO_POINT_KEY  ,Constant.CODE_8);
        this.put(SHOW_TO_CIRCLE_WITH_TEXT_KEY                           ,Constant.CODE_11);
        this.put(SHOW_TO_CIRCLE_WITH_TEXT_AND_PHOTO_KEY                 ,Constant.CODE_12);
        this.put(SEND_FILE_IN_GROUP_KEY                                 ,Constant.CODE_13);
        this.put(SEND_TEXT_IN_GROUP_KEY                                 ,Constant.CODE_14);
    }};
    //endregion

    //region 制式池
    public static HashMap<Integer,Integer> formatMap2G = new HashMap<Integer,Integer>(){{
        this.put(OPERATOR_FLAG_YD, RILConstants.NETWORK_MODE_GSM_ONLY);
        this.put(OPERATOR_FLAG_LT, RILConstants.NETWORK_MODE_GSM_ONLY);
        this.put(OPERATOR_FLAG_DX, RILConstants.NETWORK_MODE_CDMA_NO_EVDO);
    }};
    public static HashMap<Integer,Integer> formatMap3G = new HashMap<Integer,Integer>(){{
        this.put(OPERATOR_FLAG_YD, RILConstants.NETWORK_MODE_TDSCDMA_ONLY);
        this.put(OPERATOR_FLAG_LT, RILConstants.NETWORK_MODE_WCDMA_ONLY);
        this.put(OPERATOR_FLAG_DX, RILConstants.NETWORK_MODE_EVDO_NO_CDMA);
    }};
    public static HashMap<Integer,Integer> formatMap4G = new HashMap<Integer,Integer>(){{
        this.put(OPERATOR_FLAG_YD, RILConstants.NETWORK_MODE_LTE_ONLY);
        this.put(OPERATOR_FLAG_LT, RILConstants.NETWORK_MODE_LTE_ONLY);
        this.put(OPERATOR_FLAG_DX, RILConstants.NETWORK_MODE_LTE_ONLY);
    }};
    public static HashMap<Integer,Integer> formatMap5G = new HashMap<Integer,Integer>(){{
        this.put(OPERATOR_FLAG_YD, RILConstants.NETWORK_MODE_NR_ONLY);
        this.put(OPERATOR_FLAG_LT, RILConstants.NETWORK_MODE_NR_ONLY);
        this.put(OPERATOR_FLAG_DX, RILConstants.NETWORK_MODE_NR_ONLY);
    }};

    public static HashMap<String,HashMap<Integer,Integer>> formatTotal = new HashMap<String,HashMap<Integer,Integer>>(){{
        this.put(Constant.CODE_2,formatMap2G);
        this.put(Constant.CODE_3,formatMap3G);
        this.put(Constant.CODE_4,formatMap4G);
        this.put(Constant.CODE_5,formatMap5G);
    }};
    //endregion

    //region 结果回复内容
    public static final String NO_SIM = "没有检查到SIM卡";
    public static final String NO_SERVICE = "没有网络";
    public static final String SET_NET_FAIL = "设置网络制式失败";
    public static final String DIAL_FAIL = "拨号失败";
    public static final String DIAL_AND_END = "拨号后立刻挂断";
    public static final String TARGET_PHONE_NULL = "targetPhone为空";
    public static final String SERVICE_NULL = "service为null";
    public static final String MODULE_FORMAT_NULL = "moduleFormat为空";
    public static final String CONDITION_PHONE_NULL = "conditionsPhone 为 null";
    public static final String ATA_FAIL = "接听失败";
    public static final String BREAK_FAIL = "拒接/挂断失败";
    public static final String INACTIVE_WAITING_FAIL = "禁用呼叫等待失败";
    public static final String ACTIVE_WAITING_FAIL = "设置呼叫等待失败";
    public static final String INACTIVE_ALL_TRANSFER_FAIL = "取消所有前转失败";
    public static final String SET_NO_RELAY_TRANSFER_FAIL = "设置无应答前转失败";
    public static final String SET_UNCONDITIONAL_TRANSFER_FAIL = "设置无条件前转失败";
    public static final String SET_BUSY_TRANSFER_FAIL = "设置遇忙前转失败";
    public static final String SET_INACCESSABLE_TRANSFER_FAIL = "设置无法接通前转失败";
    public static final String HAVE_NO_NEW_SMS = "没有接收到短信";
    public static final String SET_NET_SUCCESS_BUT_NO_SERVICE = "切换制式成功，但该制式没有网络服务";
    //endregion

    //语音是否播放标志
    public static boolean SOUND_PLAY = false;
    public static final String DIAL_AUDIO_PATH_2 = "/sdcard/alipay_sound.wav";

    //卡槽位置缓存
    public static int SLOT_FLAG = 0;

    //若果连续三次给后台发送数据出现错误则重连
    public static int SEND_WEB_DATA_ERR_TIMERS = 0;
    public static final int SEND_WEB_DATA_ERR_TIMERS_LIMIT = 3;


    //region 彩信相关
    //彩信发送端图片保存路径
    public static String CAIXIN_IMG_FOLD_NAME_SEND = "caixin_img/send";
    //彩信接收端图片保存路径
    public static String CAIXIN_IMG_FOLD_NAME_RECEIVE = "caixin_img/receive";
    public static String CAIXIN_IMG_NAME = "1.jpg";
    //用来存储最新彩信的发送号码
    public static String CAIXIN_TARGET_PHONE = "";
    //用来存储最新彩信的信息
    public static String CAIXIN_MSG = "";
    //发送彩信标志位
    public static boolean CAIXIN_SEND = false;
    //endregion


//    public static final String TRANSFER_UNCONDITIONAL_ACTIVITY = "**21*"+phone+"#";//启动无条件转移
    public static final String TRANSFER_UNCONDITIONAL_CANCEL = "##21#";//取消无条件转移
    public static final String TRANSFER_UNCONDITIONAL_QUERY = "*#21#";//查询无条件转移

//    public static final String TRANSFER_BUSY_ACTIVITY = "**67*"+phone+"#";//启动遇忙呼叫转移
    public static final String TRANSFER_BUSY_CANCEL = "##67#";//取消遇忙呼叫转移
    public static final String TRANSFER_BUSY_QUERY = "*#67#";//查询遇忙呼叫转移

//    public static final String TRANSFER_NO_RELY_ACTIVITY = "**61*"+phone+"#";//启动无应答呼叫转移
    public static final String TRANSFER_NO_RELY_CANCEL = "##61#";//取消无应答呼叫转移
    public static final String TRANSFER_NO_RELY_QUERY = "*#61#";//查询无应答呼叫转移

    //**62*Phone# 设置转移号码
//    public static final String TRANSFER_INACCESSABLE_ACTIVITY = "**62*"+Phone+"#";
    public static final String TRANSFER_INACCESSABLE_CANCEL = "#62#";
    public static final String TRANSFER_INACCESSABLE_OPEN = "*62##";
    public static final String TRANSFER_INACCESSABLE_QUERY = "*#62#";

    public static final String TRANSFER_CANCEL_ALL = "##002#";//取消所有呼叫转移

    //呼叫转移设置存储标志，用于在广播中与结果比较
    public static String TRANSFER_FLAG = "";
    //呼叫转移设置结果存储标志
    public static boolean TRANSFER_FLAG_RESULT = false;


    /**
     * 0：取消所有前转
     * 1：启用无条件前转
     * 2：停用无条件前转
     * 3：启用无应答前转
     * 4：停用无应答前转
     * 5：启用遇忙前转
     * 6：停用遇忙前转
     * 7：启用无法接通时转移
     * 8：停用无法接通时转移
     */
    public static final int FLAG_TRANSFER_CANCEL_ALL = 0;
    public static final int FLAG_TRANSFER_ALL_ACTIVITY = 1;
    public static final int FLAG_TRANSFER_ALL_INACTIVITY = 2;
    public static final int FLAG_TRANSFER_NO_RESPONSE_ACTIVITY = 3;
    public static final int FLAG_TRANSFER_NO_RESPONSE_INACTIVITY = 4;
    public static final int FLAG_TRANSFER_BUSY_ACTIVITY = 5;
    public static final int FLAG_TRANSFER_BUSY_INACTIVITY = 6;
    public static final int FLAG_TRANSFER_INACCESSABLE_ACTIVITY = 7;
    public static final int FLAG_TRANSFER_INACCESSABLE_CANCEL = 8;
    public static boolean IS_FLAG_TRANSFER_INACCESSABLE = false;



    public static final String COM_ODMSZ_CONTROL = "com.odmsz.control";
    public static final String ACTION = "com.odmsz.control.OdmSzControlService.start";



    //响铃开始时间，给后台的通话时长是从响铃开始计时的
    public static long DIAL_RING = 0;
    //电话接通时间
    public static long DIAL_ACCEPT = 0;
    //电话挂断时间
    public static long DIAL_BREAK = 0;

    public static final String DATA_ACCEPT = "DATA ACCEPT";

    public static final int MCU_DATA_LENGTH = 6;

    //手机主板发送，stdz,心跳,CPU温度,手机主板电池电量,电池温度,SIM配置
    public static final String MCU_PRE = "stdz,";
    public static final byte[] MCU_HEADER = {115, 116, 100, 122};
    public static final byte[] MCU_END = {13, 10};
    //MCU心跳包业务号
    public static final String MCU_HEART = "00";

    public static boolean IS_MCU_COMMAND = false;

    public static int TIMER_OUT = 30;

    public static String REBOOT_DEVICE = "reboot_device";
}
