package com.example.shentan.util;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Environment;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class Utils {


    public static String strTo16(String str) {

        StringBuilder hexStr = new StringBuilder();
        if (TextUtils.isEmpty(str)){
            return null;
        }
        for (int i = 0; i < str.length(); i++) {
            int ch = str.charAt(i);
            String s4 = Integer.toHexString(ch);
            hexStr.append(s4);
        }


        return hexStr.toString();
    }


    public static String md5(String string) {
        if (TextUtils.isEmpty(string)) {
            return "";
        }
        MessageDigest md5;
        try {
            md5 = MessageDigest.getInstance("MD5");
            byte[] bytes = md5.digest(string.getBytes());
            StringBuilder result = new StringBuilder();
            for (byte b : bytes) {
                String temp = Integer.toHexString(b & 0xff);
                if (temp.length() == 1) {
                    temp = "0" + temp;
                }
                result.append(temp);
            }
            return result.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }


    public static String getUUID(){
        return UUID.randomUUID().toString();
    }


    public static void forceStopPackage(Context context, String packageName) {

        try {
            ActivityManager mActivityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            Method method = Class.forName("android.app.ActivityManager").getMethod("forceStopPackage",String.class);
            method.invoke(mActivityManager,packageName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isJson(String content) {
        if(TextUtils.isEmpty(content)){
            return false;
        }
        boolean isJsonObject = true;
        boolean isJsonArray = true;
        try {
            JSON.parseObject(content);
        } catch (Exception e) {
            isJsonObject = false;
        }
        try {
            JSON.parseArray(content);
        } catch (Exception e) {
            isJsonArray = false;
        }
        //不是json格式
        return isJsonObject || isJsonArray;
    }


    public static void createSaveFile(Boolean isUseExternalFilesDir,Bitmap bitmap) {
        File destFile;
        String filePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        if (isUseExternalFilesDir) {
            destFile = new File(filePath, Constant.CAIXIN_IMG_NAME);
        } else {
            File file = new File(filePath, Constant.CAIXIN_IMG_FOLD_NAME_RECEIVE);
            if (!file.exists()) {
                file.mkdirs();
            }
            destFile = new File(file, Constant.CAIXIN_IMG_NAME);
        }

        Utils.saveBitmap2SelfDirectroy(bitmap, destFile);

    }

    //保存图片至app私有目录
    public static void saveBitmap2SelfDirectroy(Bitmap bitmap, File file) {
        try {
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static String getOtherOperate(int currentOperate){
        int offline = 0;
        switch (currentOperate){

            case Constant.OPERATOR_FLAG_YD : {
                offline = Constant.OPERATOR_FLAG_DX;
                break;
            }
            case Constant.OPERATOR_FLAG_DX : {
                offline = Constant.OPERATOR_FLAG_LT;
                break;
            }
            case Constant.OPERATOR_FLAG_LT : {
                offline = Constant.OPERATOR_FLAG_YD;
                break;
            }
        }


        return String.valueOf(offline);
    }


    /**
     * 判断字符串是否为全数字的字符串
     * @param str
     * @return
     */
    public static boolean isNumberStr(String str){

        return str.matches("[0-9]+");
    }

    /**
     * MM-dd HH:mm:ss
     * @return
     */
    @SuppressLint("SimpleDateFormat")
    public static String getNowMDHMSTime(){

        SimpleDateFormat mDateFormat = new SimpleDateFormat(
                "MM-dd HH:mm:ss");
        return mDateFormat.format(new Date());
    }

    /**
     * 获取13位时间戳
     */
    public static String getTimeMillis(){
        return String.valueOf(System.currentTimeMillis());
    }

    public static void replaceSB(StringBuilder sb,Object...str){

        if (str.length > 1){
            for (int i = 0; i < str.length; i++) {
                if (i == 0){
                    sb.replace(0,sb.length(),(String) str[i]);
                }else {
                    sb.append(str[i]);
                }
            }
        }else {
            sb.replace(0,sb.length(),String.valueOf(str[0]));
        }
    }
    public static void replaceSB(StringBuffer sb,Object...str){

        if (str.length > 1){
            for (int i = 0; i < str.length; i++) {
                if (i == 0){
                    sb.replace(0,sb.length(),(String) str[i]);
                }else {
                    sb.append(str[i]);
                }
            }
        }else {
            sb.replace(0,sb.length(),String.valueOf(str[0]));
        }
    }

    public static void clearSB(StringBuilder sb){
        sb.delete(0,sb.length());
    }
    public static void clearSB(StringBuffer sb){
        sb.delete(0,sb.length());
    }


}
