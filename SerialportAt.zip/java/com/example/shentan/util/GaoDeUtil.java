package com.example.shentan.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;

import com.example.shentan.entity.GaoDeBean;

public class GaoDeUtil {


    /**
     * 通过经纬度来查找的路线规划
     * https://lbs.amap.com/api/amap-mobile/guide/android/route
     */

    public static GaoDeBean gaoDeMapRoute(String endName, GaoDeBean gaoDeBean, Context context) {

        String url = ("androidamap://route?sourceApplication=appName&dlat="+gaoDeBean.getTargetLat()+"&dlon="+gaoDeBean.getTargetLon()+"&dname="+endName+"&dev=0&t=2");
        return openIntent(context, url ,gaoDeBean);

    }

    /**
     * 通过地点名称来查找的路线规划，需要准确的地点名称
     * @param context
     */
    public static GaoDeBean gaoDeMapRoute(GaoDeBean gaoDeBean,Context context) {


        String url = ("androidamap://route?sourceApplication=appName&dname="+gaoDeBean.getTargetAddress()+"&dev=0&t=2");


        return openIntent(context, url,gaoDeBean);

    }

    /**
     * 打开高德导航
     */
    public static GaoDeBean gaoDeMapNavigation(GaoDeBean gaoDeBean,Context context) {
        String url=("androidamap://navi?sourceApplication=appname&poiname="+gaoDeBean.getTargetAddress()+"&lat="+gaoDeBean.getTargetLon()+"&lon="+gaoDeBean.getTargetLat()+"&dev=1&style=2");

        return openIntent(context, url ,gaoDeBean);

    }


    /**
     * 搜索地址
     */
    public static GaoDeBean gaoDeMapSearch(String searchName,Context context,GaoDeBean gaoDeBean) {

//        String url="androidamap://poi?sourceApplication=softname&keywords=银行|加油站|电影院&lat1=36.1&amp;lon1=116.1&lat2=36.2&lon2=116.2&dev=0";

        String url="androidamap://poi?sourceApplication=softname&keywords="+searchName+"&dev=0";

        return openIntent(context, url ,gaoDeBean);

    }

    private static GaoDeBean openIntent(Context context, String url,GaoDeBean gaoDeBean) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        Uri uri  = Uri.parse(url);
        //将功能Scheme以URI的方式传入data
        intent.setData(uri);

        gaoDeBean.setPackId(Utils.getUUID());
        gaoDeBean.setSysTime(Utils.getTimeMillis());
        gaoDeBean.setInfoCode(Constant.NO_APP_RESULT);

        if (context.getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) != null) {
            try {
                //启动该页面即可
                context.startActivity(intent);
                gaoDeBean.setCommandResult(Constant.CODE_1);

            } catch (Exception e) {
                gaoDeBean.setCommandResult(Constant.CODE_2);

            }
        } else {
            gaoDeBean.setCommandResult(Constant.CODE_2);

        }
        return gaoDeBean;


    }





}
