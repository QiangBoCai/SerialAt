package com.example.shentan.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class NetUtil {

    // 切换制式后，需要一段时间才会有网络，
    // 这里需要做的是，
    // 1、需要循环检测一段时间，而不是立即返回false（没有网络则延时5秒重新检测，检测10次）
    // 2、超出一段时间后还是没有网络再返回false

    //存储检查是否有网络的次数
    public static int checkNetTimes = 0;

    public static boolean checkNet(Context context){

        if (checkNetworkAvailable(context) && ping()){
            return true;
        }else {
            checkNetTimes++;
            return false;

        }
    }


    /** @author suncat
     * @category 判断是否有外网连接（普通方法不能判断外网的网络是否连接，比如连接上局域网）
     * @return
     */
    public static boolean ping() {

        try {
            String ip = "www.baidu.com";// ping 的地址，可以换成任何一种可靠的外网
            Process p = Runtime.getRuntime().exec("ping -c 3 -w 100 " + ip);// ping网址3次
            // 读取ping的内容，可以不加
            InputStream input = p.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(input));
            StringBuilder stringBuffer = new StringBuilder();
            String content;
            while ((content = in.readLine()) != null) {
                stringBuffer.append(content);
            }
            // ping的状态
            int status = p.waitFor();
            if (status == 0) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean checkNetworkAvailable(Context context) {
        ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivity == null) {
            return false;

        } else {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();

            if (info != null) {
                for (NetworkInfo networkInfo : info) {
                    if (networkInfo.getState() == NetworkInfo.State.CONNECTED) {

                        if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                            return true;

                        } else if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                            return true;

                        }

                    }

                }

            }

        }

        return false;

    }
}