package com.example.shentan.util;

import android.os.Environment;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.strategy.McuStrategy;
import com.odmsz.control.CellIdentity;
import com.odmsz.control.RILConstants;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

import static java.lang.Thread.sleep;

public class FutureTaskUtils {
    private final SerialPortActivity serialPortActivity;
    public FutureTaskUtils(SerialPortActivity serialPortActivity){
        this.serialPortActivity = serialPortActivity;
    }

    @Nullable
    public FutureTask<Boolean> getVersion() {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                try {
                    serialPortActivity.iservice.getVersion(Constant.ODMSZ_TOKEN);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return null;
            }
        });
    }

    @Nullable
    public FutureTask<Boolean> reboot() {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                try {
                    serialPortActivity.iservice.reboot(Constant.ODMSZ_TOKEN,1,1,0);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return null;
            }
        });
    }

    @Nullable
    public FutureTask<Boolean> shutdown() {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                try {
                    serialPortActivity.iservice.shutdown(Constant.ODMSZ_TOKEN,false);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return null;
            }
        });
    }


    @NotNull
    public FutureTask<Boolean> sendTextMessageFutureTask(String targetPhone, String msg) {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean isSuccess = false;
                try {
                    isSuccess = serialPortActivity.iservice.sendTextMessage(Constant.ODMSZ_TOKEN, targetPhone, null, msg);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return isSuccess;
            }
        });
    }

    @NotNull
    public FutureTask<Boolean> setSmscAddressFutureTask(String smscAddress) {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean isSuccess = false;
                try {
                    isSuccess = serialPortActivity.iservice.setSmscAddress(Constant.ODMSZ_TOKEN, smscAddress);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return isSuccess;
            }
        });
    }

    @NotNull
    public FutureTask<String> getSmscAddressFutureTask() {
        return new FutureTask<>(new Callable<String>() {
            @Override
            public String call() {
                String smscAddress = "";
                try {
                    //设置一下短信中心号码，因为发送彩信会失败，所以先设置一下
                    smscAddress = serialPortActivity.iservice.getSmscAddress(Constant.ODMSZ_TOKEN);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return smscAddress;
            }
        });
    }

    @NotNull
    public FutureTask<Integer> getCallWaitingStatusFutureTask() {
        return new FutureTask<>(new Callable<Integer>() {
            @Override
            public Integer call() {
                int waitState = 0;
                try {
                    //先查询一下呼叫等待的状态，需要禁用再去禁用
                    waitState = serialPortActivity.iservice.getCallWaitingStatus(Constant.ODMSZ_TOKEN);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return waitState;
            }
        });
    }
    @NotNull
    public FutureTask<Boolean> endCallFutureTask() {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean isSuccess = false;
                try {
                    isSuccess = serialPortActivity.iservice.endCall(Constant.ODMSZ_TOKEN);
                    LogUtil.print("endCall result="+isSuccess);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return isSuccess;
            }
        });
    }


    @NotNull
    public FutureTask<Boolean> setCallWaitingStatusFutureTask() {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean isSuccess = false;
                try {
                    isSuccess = serialPortActivity.iservice.setCallWaitingStatus(Constant.ODMSZ_TOKEN,true);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return isSuccess;
            }
        });
    }
    @NotNull
    public FutureTask<Boolean> airPlaneModeFutureTask() {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean airPlaneClose = false;
                try {
                    airPlaneClose = serialPortActivity.iservice.setAirPlaneMode(Constant.ODMSZ_TOKEN,true);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return airPlaneClose;
            }
        });
    }

    public FutureTask<String> iccidFutureTask() {
        return new FutureTask<>(new Callable<String>() {
            @Override
            public String call() {
                String iccid = "";
                try {
                    iccid = serialPortActivity.iservice.getIccid(Constant.ODMSZ_TOKEN);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return iccid;
            }
        });
    }

    @NotNull
    public FutureTask<Integer> serviceStateFutureTask() {
        return new FutureTask<>(new Callable<Integer>() {
            @Override
            public Integer call() {
                int serviceState = -1;
                try {
                    serviceState = serialPortActivity.iservice.getServiceState(Constant.ODMSZ_TOKEN);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return serviceState;
            }
        });
    }

    @NotNull
    public FutureTask<Boolean> roamingEnabledFutureTask() {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean roamingState = false;
                try {
                    //0非漫游状态 1 漫游状态
                    roamingState = serialPortActivity.iservice.isDataRoamingEnabled(Constant.ODMSZ_TOKEN);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return roamingState;
            }
        });
    }

    @NotNull
    public FutureTask<Integer> getPhoneTypeFutureTask() {
        return new FutureTask<>(new Callable<Integer>() {
            @Override
            public Integer call() {
                int phoneType = -1;
                try {
                    phoneType = serialPortActivity.iservice.getPhoneType();
                }catch (Exception e){
                    e.printStackTrace();
                }
                return phoneType;
            }
        });
    }

    @NotNull
    public FutureTask<Boolean> restartModemFutureTask() {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean restartModem = false;
                try {
                    restartModem = serialPortActivity.iservice.restartModem(Constant.ODMSZ_TOKEN);
                    Thread.sleep(10000);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return restartModem;
            }
        });
    }

    @NotNull
    public FutureTask<Boolean> sendMmsFutureTask(String etContent) {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean sendMms = false;
                try {
                    String url = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+Constant.CAIXIN_IMG_FOLD_NAME_SEND +"/1.jpg";
                    String subject ="发送了彩信图片";
                    sendMms = serialPortActivity.iservice.sendMms(Constant.ODMSZ_TOKEN, etContent, subject, null, url, null);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return sendMms;
            }
        });
    }

    @NotNull
    public FutureTask<Boolean> callFutureTask(String targetPhone) {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean isDialSuccess = false;
                try {
                    isDialSuccess = serialPortActivity.iservice.call(Constant.ODMSZ_TOKEN, targetPhone);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return isDialSuccess;
            }
        });
    }


    @NotNull
    public FutureTask<Boolean> acceptRingingCallFutureTask() {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean isSuccess = false;
                try {
                    isSuccess = serialPortActivity.iservice.acceptRingingCall(Constant.ODMSZ_TOKEN);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return isSuccess;
            }
        });
    }

    @Nullable
    public FutureTask<Integer> getSimStateFutureTaskMcu() {
        return new FutureTask<>(new Callable<Integer>() {
            @Override
            public Integer call() {
                int simStateResult = 0;
                try {

                    // 检查Sim卡state
                    while (simStateResult != RILConstants.SIM_STATE_READY && McuStrategy.getSimStateTimes < 5){
                        simStateResult = serialPortActivity.iservice.getSimState(Constant.ODMSZ_TOKEN);
                        McuStrategy.getSimStateTimes ++;
                        Thread.sleep(5000);
                    }
                }catch (Exception e){
                    simStateResult = 0;
                    e.printStackTrace();
                }finally {
                    McuStrategy.getSimStateTimes = 0;

                }
                return simStateResult;
            }
        });
    }


    @NotNull
    public FutureTask<Integer> simStateFutureTask() {
        return new FutureTask<>(new Callable<Integer>() {
            @Override
            public Integer call() {
                int state = -1;
                try {
                    state = serialPortActivity.iservice.getSimState(Constant.ODMSZ_TOKEN);//slot卡槽  0表示卡1,1表示卡2
                }catch (Exception e){
                    e.printStackTrace();
                }
                return state;
            }
        });
    }

    @NotNull
    public FutureTask<List<CellIdentity>> getCellInfoFutureTask() {
        return new FutureTask<>(new Callable<List<CellIdentity>>() {
            @Override
            public List<CellIdentity> call() {
                ArrayList<CellIdentity> finalCellIdentitys = new ArrayList<>();
                try {
                    finalCellIdentitys.addAll(serialPortActivity.iservice.getCellInfo(Constant.ODMSZ_TOKEN));
                }catch (Exception e){
                    e.printStackTrace();
                }
                return finalCellIdentitys;
            }
        });
    }

    public FutureTask<Integer> getNetFutureTask() {
        return new FutureTask<>(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                int netResult;
                netResult = serialPortActivity.iservice.getPreferredNetwork(Constant.ODMSZ_TOKEN, Constant.SLOT_FLAG);
                return netResult;
            }
        });
    }

    public FutureTask<Boolean> setNetFutureTask(int netType) {
        return new FutureTask<>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean netResult = false;
                try {
                    netResult = serialPortActivity.iservice.setPreferredNetwork(Constant.ODMSZ_TOKEN, Constant.SLOT_FLAG, netType);
                    LogUtil.print("setPreferredNetwork netResult="+netResult);
                    sleep(5000);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return netResult;
            }
        });
    }
}
