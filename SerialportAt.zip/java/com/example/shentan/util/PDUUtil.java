package com.example.shentan.util;

import com.example.shentan.entity.SmsPduBean;

public class PDUUtil {

    /**
     * 组合
     */
    public static SmsPduBean combine(String smsPhone, String receivePhone, String sms){

//        1、手机号码前加上字符串 01000D91（1100：固定，0D：手机号码的长度，不算＋号，十六进制表示，
//        91：发送到手机为91，发送到小灵通为81）。即 phone = "01000D91" + phone
//        01000D91683106423346F9
//        2、手机号码后加上 001B 和刚才的短信息内容，001B也写死就可以了
//        即 phone = phone + "001B" + msg
//        即 01000D91683106423346F9 + 001B + 0A5DE54F5C61095FEBFF01
//        => phone = 01000D91683106423346F9001B0A5DE54F5C61095FEBFF01
//        3、phone 长度除以2，格式化成2位的十进制数
//        即 01000D91683106423346F9001B0A5DE54F5C61095FEBFF01 => 50位 / 2 => 25

//        1、手机号码前加上字符串 01000D91
        StringBuilder smsPhoneBuilder = new StringBuilder(receivePhone);
//        2、手机号码后加上 001B 和刚才的短信息内容
        smsPhoneBuilder.insert(0,"01000D91").append("001B").append(sms);

//        3、phone 长度除以2，格式化成2位的十进制数
        StringBuilder sendLengthBuilder = new StringBuilder(""+smsPhoneBuilder.length() / 2);

        if (sendLengthBuilder.length() < 2){
            sendLengthBuilder.insert(0,"0");
        }

        smsPhoneBuilder.insert(0,smsPhone);

        return new SmsPduBean((Integer.parseInt(sendLengthBuilder.toString())),smsPhoneBuilder.toString());

    }
    public static SmsPduBean combineNoSmsPhone(String receivePhone, String sms){

//        1、手机号码前加上字符串 01000D91（1100：固定，0D：手机号码的长度，不算＋号，十六进制表示，
//        91：发送到手机为91，发送到小灵通为81）。即 phone = "01000D91" + phone
//        01000D91683106423346F9
//        2、手机号码后加上 001B 和刚才的短信息内容，001B也写死就可以了
//        即 phone = phone + "001B" + msg
//        即 01000D91683106423346F9 + 001B + 0A5DE54F5C61095FEBFF01
//        => phone = 01000D91683106423346F9001B0A5DE54F5C61095FEBFF01
//        3、phone 长度除以2，格式化成2位的十进制数
//        即 01000D91683106423346F9001B0A5DE54F5C61095FEBFF01 => 50位 / 2 => 25

//        1、手机号码前加上字符串 01000D91
        StringBuilder smsPhoneBuilder = new StringBuilder(receivePhone);
//        2、手机号码后加上 001B 和刚才的短信息内容
        smsPhoneBuilder.insert(0,"01000D91").append("001B").append(sms);

//        3、phone 长度除以2，格式化成2位的十进制数
        StringBuilder sendLengthBuilder = new StringBuilder(""+smsPhoneBuilder.length() / 2);

        if (sendLengthBuilder.length() < 2){
            sendLengthBuilder.insert(0,"0");
        }


        return new SmsPduBean((Integer.parseInt(sendLengthBuilder.toString())),smsPhoneBuilder.toString());

    }



    /**
     * 短信息部分处理
     */
    public static String sms(String str){

        //1、将字符串转化为Unicode码
        StringBuilder unicode = new StringBuilder();
        for (int i=0;i<str.length();i++) {
            // 取出每一个字符
            char c = str.charAt(i);
            // 转换为unicode
            String strUnicode = Integer.toHexString(c);
            if (strUnicode.length() < 4){

                for (int j = 0;j < (4 - strUnicode.length());j++){
                    unicode.append("0");
                }
            }
            unicode.append(Integer.toHexString(c));
        }

        //2、将unicode长度除以2，保留两位16进制数
        int halfTransBuildLength = unicode.length() / 2;

        String sixteen = Integer.toHexString(halfTransBuildLength);

        if (sixteen.length() < 2){
            unicode.insert(0,"0"+sixteen);
        }else{
            unicode.insert(0,sixteen);
        }

        return unicode.toString();
    }

    /**
     * 手机号码处理
     */
    public static String receivePhone(String str){

        //1、去除加号
        StringBuilder strBuild = new StringBuilder();

        char[] strArrays = str.toCharArray();

        for (char strArr : strArrays){
            if (strArr != '+'){
                strBuild.append(strArr);
            }
        }

        //2、判断是否为偶数位，不是加F
        if (strBuild.length() % 2 != 0){
            strBuild.append("F");
        }

        //3、奇数位和偶数位反转
        StringBuilder strJ = new StringBuilder();
        StringBuilder strO = new StringBuilder();

        for (int i=0;i<strBuild.length();i++){

            if (i % 2 != 0){
                strJ.append(strBuild.charAt(i));
            }else{
                strO.append(strBuild.charAt(i));
            }
        }

        StringBuilder transBuild = new StringBuilder();

        for (int i = 0;i< strBuild.length() / 2;i++){
            transBuild.append(strJ.charAt(i));
            transBuild.append(strO.charAt(i));
        }

        return transBuild.toString();
    }

    /**
     * 短信中心号码处理
     */
    public static String smsPhone(String str){

        //1、去除加号

        StringBuilder strBuild = new StringBuilder();

        char[] strArrays = str.toCharArray();

        for (char strArr : strArrays){
            if (strArr != '+'){
                strBuild.append(strArr);
            }
        }
        //2、判断是否为偶数位，不是加F4
        if (strBuild.length() % 2 != 0){
            strBuild.append("F");
        }

        //3、奇数位和偶数位反转
        StringBuilder strJ = new StringBuilder();
        StringBuilder strO = new StringBuilder();

        for (int i=0;i<strBuild.length();i++){

            if (i % 2 != 0){
                strJ.append(strBuild.charAt(i));
            }else{
                strO.append(strBuild.charAt(i));
            }
        }


        StringBuilder transBuild = new StringBuilder();

        for (int i = 0;i< strBuild.length() / 2;i++){
            transBuild.append(strJ.charAt(i));
            transBuild.append(strO.charAt(i));
        }

        //4、头部加91
        transBuild.insert(0,"91");

        //5、算出字符串长度，结果除以2，格式化成两位的16进制字符，放在头部

        int halfTransBuildLength = transBuild.length() / 2;

        String sixteen = Integer.toHexString(halfTransBuildLength);

        if (sixteen.length() < 2){
            transBuild.insert(0,"0"+sixteen);
        }else{
            transBuild.insert(0,sixteen);
        }

        return transBuild.toString();
    }
}
