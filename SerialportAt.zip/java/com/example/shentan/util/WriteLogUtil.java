package com.example.shentan.util;


import android.icu.util.Calendar;
import android.os.Environment;

import com.example.shentan.singleton.CachedThreadPoolSingleton;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <Pre>
 * 将日志文件输出在本地日志
 * </Pre>
 *
 * @author zhengjy
 * @version 1.0
 *          <p/>
 *          Create by 2016/11/15 11:49
 */
public class WriteLogUtil {
  public  static final String cacheDir= Environment.getExternalStorageDirectory().getAbsolutePath();

  public static final String PATH_LOG = cacheDir + "/Log";
  public static final String UNCATCH_FILE_NAME = "uncatch_file";
  public static final String LOG_FILE_NAME = ".txt";
  private static final DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
  public static final String UEPATH = cacheDir + "/LogUe";
  public static final String UE_LOG_FILE_NAME = "_ue_stdz5g_log.txt";
  public static int sendUeTimes;
  public static int receiverUeTimes;
  public static int failureUeTimes;
  public static int successUeTimes;
  /**
   * 是否写入日志文件
   */
  public static final boolean LOG_WRITE_TO_FILE = true;

  /**
   * 错误信息
   */
  public static void e(String TAG, String msg) {
    //        Logger.e(TAG, msg);
    if (LOG_WRITE_TO_FILE) writeLogtoFile("e", TAG, msg);
  }

  /**
   * 警告信息
   */
  public static void w(String TAG, String msg) {
    //        Logger.w(TAG, msg);
    if (LOG_WRITE_TO_FILE) writeLogtoFile("w", TAG, msg);
  }

  /**
   * 调试信息
   */
  public static void d(String TAG, String msg) {
    //        Logger.d(TAG, msg);
    if (LOG_WRITE_TO_FILE) writeLogtoFile("d", TAG, msg);
  }

  /**
   * 提示信息
   */
  public static void i(String TAG, String msg) {
    //        Logger.i(TAG, msg);
    if (LOG_WRITE_TO_FILE) writeLogtoFile("i", TAG, msg);
  }

  /**
   * 写入日志到文件中
   */
  private static void writeLogtoFile(String logType, String tag, String msg) {
    isExist(PATH_LOG);
    //isDel();
    String needWriteMessage =
        "\r\n" + Utils.getNowMDHMSTime() + "\r\n" + logType + "  " + tag + "  " + msg + "\r\n";
    try {
      String filePre = formatter.format(new Date());
      File file = new File(PATH_LOG, filePre + LOG_FILE_NAME);
      if (!file.exists()) {
        file.createNewFile();
      }
      CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
        @Override
        public void run() {
          try {
            FileWriter filerWriter = new FileWriter(file, true);
            BufferedWriter bufWriter = new BufferedWriter(filerWriter);
            bufWriter.write(needWriteMessage);
            bufWriter.newLine();
            bufWriter.close();
            filerWriter.close();
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
      });

    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * 删除日志文件
   */
  public static void delFile() {

    File file = new File(PATH_LOG, LOG_FILE_NAME);
    if (file.exists()) {
      file.delete();
    }
  }

  /**
   * 判断文件夹是否存在,如果不存在则创建文件夹
   */
  public static void isExist(String path) {
    File file = new File(path);
    if (!file.exists()) {
      file.mkdirs();
    }
  }




  /**
   * clear count
   */
  public static void clearCount(){
    sendUeTimes=0;
    failureUeTimes=0;
    successUeTimes=0;
    receiverUeTimes=0;
  }
  /**
   * 删除七天之前的日志文件
   */
  public static void deleteFileBeforeSevenDays() {

    File file1 = new File(PATH_LOG);
    File[] files = file1.listFiles();// 读取

    if (files != null) {// 先判断目录是否为空，否则会报空指针
      for (File file : files) {
//        if (file.isDirectory()) {
//          getFileName(file.listFiles());
//        } else
//        {
        String fileName = file.getName();
        if (fileName.equalsIgnoreCase(IpConfigUtil.ip_file_name)){
          continue;
        }
        if (fileName.endsWith(".txt")) {
          try {
            String s = fileName.substring(0, fileName.lastIndexOf("."));
            if (daysBetween(s.trim(), getStringToday()) >= 7) {
              file.delete();
            }
          } catch (ParseException e) {
            e.printStackTrace();

          }// 当前时间
        }
//        }
      }
    }
  }

  /**
   * 得到现在时间
   *
   * @return 字符串 yyyyMMdd HHmmss
   */
  public static String getStringToday() {
    Date currentTime = new Date();
    return formatter.format(currentTime);
  }

  /**
   * 字符串的日期格式的计算
   */
  public static int daysBetween(String smdate, String bdate) throws ParseException {
    Calendar cal;
    long between_days = 0;
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
      cal = Calendar.getInstance();
      cal.setTime(formatter.parse(smdate));
      long time1 = cal.getTimeInMillis();
      cal.setTime(formatter.parse(bdate));
      long time2 = cal.getTimeInMillis();
      between_days = (time2 - time1) / (1000 * 3600 * 24);
    }

    return Integer.parseInt(String.valueOf(between_days));
  }

}
