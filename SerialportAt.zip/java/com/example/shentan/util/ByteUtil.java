package com.example.shentan.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.util.ArrayList;

/**
 * Author by Winds on 2016/10/18.
 * Email heardown@163.com.
 */
public class ByteUtil {

    private static char forDigit(int digit, int radix) {
        if ((digit >= radix) || (digit < 0)) {
            return '\0';
        }
        if ((radix < Character.MIN_RADIX) || (radix > Character.MAX_RADIX)) {
            return '\0';
        }
        if (digit < 10) {
            return (char) ('0' + digit);
        }
        return (char) ('A' - 10 + digit);
    }


    /**
     * 字节数组转换成对应的16进制表示的字符串
     *
     * @param src
     * @return
     */
    public static String bytes2HexStr(byte[] src) {
        StringBuilder builder = new StringBuilder();
        if (src == null || src.length <= 0) {
            return "";
        }
        char[] buffer = new char[2];
        for (byte b : src) {
            buffer[0] = forDigit((b >>> 4) & 0x0F, 16);
            buffer[1] = forDigit(b & 0x0F, 16);
            builder.append(buffer);
        }
        return builder.toString();
    }

    /**
     * 十六进制字节数组转字符串
     *
     * @param src 目标数组
     * @param dec 起始位置
     * @param length 长度
     * @return
     */
    public static String bytes2HexStr(byte[] src, int dec, int length) {
        byte[] temp = new byte[length];
        System.arraycopy(src, dec, temp, 0, length);
        return bytes2HexStr(temp);
    }


    /**
     * 把十六进制表示的字节数组字符串，转换成十六进制字节数组
     *
     * @param
     * @return byte[]
     */
    public static byte[] hexStr2bytes(String hex) {
        if(hex.length()==3&&hex.startsWith("0")){
            hex = hex.substring(1,hex.length());
        }
        int len = (hex.length() / 2);
        byte[] result = new byte[len];
        char[] achar = hex.toUpperCase().toCharArray();
        for (int i = 0; i < len; i++) {
            int pos = i * 2;
            result[i] = (byte) (hexChar2byte(achar[pos]) << 4 | hexChar2byte(achar[pos + 1]));
        }
        return result;
    }


    /**
     * 把16进制字符[0123456789abcde]（含大小写）转成字节
     *
     * @param c
     * @return
     */
    private static int hexChar2byte(char c) {
        switch (c) {
            case '0':
                return 0;
            case '1':
                return 1;
            case '2':
                return 2;
            case '3':
                return 3;
            case '4':
                return 4;
            case '5':
                return 5;
            case '6':
                return 6;
            case '7':
                return 7;
            case '8':
                return 8;
            case '9':
                return 9;
            case 'a':
            case 'A':
                return 10;
            case 'b':
            case 'B':
                return 11;
            case 'c':
            case 'C':
                return 12;
            case 'd':
            case 'D':
                return 13;
            case 'e':
            case 'E':
                return 14;
            case 'f':
            case 'F':
                return 15;
            default:
                return -1;
        }
    }


    public static byte[] addBytes(ArrayList<byte[]> byteArr) {
        int byteTotalLength = 0;
        int byteCurrentLength = 0;
        for (int i = 0; i < byteArr.size(); i++) {
            byteTotalLength = byteTotalLength + byteArr.get(i).length;
        }
        byte[] newDatas = new byte[byteTotalLength];

        for (int i = 0; i<byteArr.size(); i++){
            System.arraycopy(byteArr.get(i),0,newDatas, byteCurrentLength,byteArr.get(i).length);
            byteCurrentLength = byteCurrentLength + byteArr.get(i).length;
        }
        return newDatas;


    }

    /**
     * 16进制转换成为string类型字符串
     * @param s
     * @return
     */
    public static String hexStringToString(String s) {
        if (s == null || s.equals("")) {
            return null;
        }
        s = s.replace(" ", "");
        byte[] baKeyword = new byte[s.length() / 2];
        for (int i = 0; i < baKeyword.length; i++) {
            try {
                baKeyword[i] = (byte) (0xff & Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            s = new String(baKeyword, "UTF-8");
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return s;
    }

    public static int getByteIndex(byte[] fatherByte, byte[] childByte,int fatherByteStartIndex) {
        int index1 = fatherByteStartIndex;
        int index2 = 0;
        if(childByte!=null) {
            while(index1 < fatherByte.length) {
                int dsite = 0;
                while(fatherByte[index1+dsite]==childByte[index2+dsite]) {
                    if(index2+dsite+1>=childByte.length){
                        return index1;

                    }

                    dsite++;
                    if(index1+dsite>=fatherByte.length || index2+dsite>=childByte.length){
                        break;

                    }
                }
                index1++;
            }
            return -1;
        }
        else{
            return index1;
        }

    }
    public static ArrayList<byte[]> splitByte = new ArrayList<>();

    public static void splitByte(byte[] fatherByte, byte[] childByte, int fatherByteStartIndex) {
        splitByte.clear();
        int startIndex = fatherByteStartIndex;
        int index1 = fatherByteStartIndex;
        int index2 = 0;
        if(childByte!=null) {
            while(index1 < fatherByte.length) {
                int dsite = 0;
                while(fatherByte[index1+dsite]==childByte[index2+dsite]) {
                    if(index2+dsite+1>=childByte.length){
                        //找到相同
                        splitByte.add(subBytes(fatherByte,startIndex,index1+2-startIndex));
                        startIndex = index1+2;

                    }

                    dsite++;
                    if(index1+dsite>=fatherByte.length || index2+dsite>=childByte.length){
                        break;

                    }
                }
                index1++;
            }
        }

    }

    public static byte[] subBytes(byte[] src, int begin, int count) {
        byte[] bs = new byte[count];
        System.arraycopy(src, begin, bs, 0, count);
        return bs;
    }

    public static Bitmap Bytes2Bimap(byte[] b) {
        if (b.length != 0) {
            return BitmapFactory.decodeByteArray(b, 0, b.length);
        } else {
            return null;
        }
    }

    /**
     * 用16进制的方式打印byte数组
     */
    public static String bytes2hex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        String tmp = null;
        sb.append("[");
        for (byte b : bytes) {
            // 将每个字节与0xFF进行与运算，然后转化为10进制，然后借助于Integer再转化为16进制
            tmp = Integer.toHexString(0xFF & b);
            if (tmp.length() == 1) {
                tmp = "0" + tmp;//只有一位的前面补0
            }
            sb.append(tmp).append(" ");//每个byte空格隔开
        }
        sb.delete(sb.length()-1,sb.length());//删除最后一个字节后面多余的空格
        sb.append("]");
        return sb.toString();
    }
}
