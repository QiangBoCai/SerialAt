package com.example.shentan;



import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class SerialPort {
    private static final String TAG = "SerialPort";
    private final FileInputStream mFileInputStream;
    private final FileOutputStream mFileOutputStream;
    /*
     * Do not remove or rename the field mFd: it is used by native method close();
     */
    private FileDescriptor mFd;
    public SerialPort(File device, int baudrate, int flags) throws SecurityException, IOException {


        mFd = open(device.getAbsolutePath(), baudrate, flags);
        if (mFd == null) {
            throw new IOException();
        }
        mFileInputStream = new FileInputStream(mFd);
        mFileOutputStream = new FileOutputStream(mFd);
    }

    // Getters and setters
    public BufferedInputStream getBufferedInputStream() {
        return new BufferedInputStream(mFileInputStream);
    }

    public BufferedOutputStream getBufferedOutputStream() {
        return new BufferedOutputStream(mFileOutputStream);
    }

    // JNI
    private native static FileDescriptor open(String path, int baudrate, int flags);
    public native void close();
    static {
        System.loadLibrary("serialport");
    }
}
