package com.example.shentan.chain;


import java.util.LinkedList;

interface InterceptorCallBack {

    LinkedList<String> handle(Chain chain);

    interface Chain {
        LinkedList<String> proceed(int interceptorIndex);
        LinkedList<String> proceed(byte[] receiveByte,int byteSize,String receiveWebData);
        String getReceiveWebData();
        byte[] getReceiveByte();
        int getByteSize();
        LinkedList<String> getReceiveDataList();
        void addReceiveData(String receiveData);
        void addReceiveAllData(LinkedList<String> receiveDatas);
        void clearData();

    }
}
