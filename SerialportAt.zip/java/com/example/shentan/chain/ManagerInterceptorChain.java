package com.example.shentan.chain;


import com.example.shentan.util.Constant;

import java.util.LinkedList;

/**
 * 拦截器管理类
 */
public class ManagerInterceptorChain implements InterceptorCallBack.Chain {

    private final LinkedList<InterceptorCallBack> interceptorList = new LinkedList<>();
    private int byteSize = 0;
    private byte[] receiveByte;
    private final LinkedList<String> receiveDataList = new LinkedList<>();
    private String receiveWebData;
    public static volatile ManagerInterceptorChain instance;
    public static ManagerInterceptorChain getInstance(){
        if (instance == null){
            synchronized (ManagerInterceptorChain.class){
                if (instance == null){
                    instance = new ManagerInterceptorChain();
                }
            }
        }
        return instance;
    }
    private ManagerInterceptorChain(){
        //注意拦截器的添加顺序
        addInterceptor(new InterceptorDispatch());
        addInterceptor(new InterceptorMcu());
        addInterceptor(new InterceptorOther());
    }

    @Override
    public LinkedList<String> proceed(int interceptorIndex) {
        if (interceptorList.size() == Constant.DIGIT_0) return receiveDataList;
        if (interceptorIndex < Constant.DIGIT_0 || interceptorIndex >= interceptorList.size()) return receiveDataList;

        return interceptorList.get(interceptorIndex).handle(this);
    }

    @Override
    public LinkedList<String> proceed(byte[] receiveByte, int size, String receiveWebData) {
        this.byteSize = size;
        this.receiveByte = receiveByte;
        this.receiveWebData = receiveWebData;
        receiveDataList.clear();
        if (interceptorList.size() == Constant.DIGIT_0) return receiveDataList;

        return interceptorList.get(Constant.DIGIT_0).handle(this);

    }

    @Override
    public String getReceiveWebData() {
        return receiveWebData;
    }

    @Override
    public byte[] getReceiveByte() {
        return receiveByte;
    }

    @Override
    public int getByteSize() {
        return byteSize;
    }

    @Override
    public void addReceiveData(String receiveData){
        receiveDataList.add(receiveData);
    }

    @Override
    public void addReceiveAllData(LinkedList<String> receiveDatas) {
        receiveDataList.addAll(receiveDatas);

    }

    @Override
    public void clearData() {
        receiveDataList.clear();

    }

    @Override
    public LinkedList<String> getReceiveDataList(){
        return receiveDataList;
    }

    public void addInterceptor(InterceptorCallBack interceptorCallBack) {
        interceptorList.add(interceptorCallBack);
    }

    public void removeInterceptor(InterceptorCallBack interceptorCallBack) {
        interceptorList.remove(interceptorCallBack);
    }

    public void removeAllInterceptor() {
        interceptorList.clear();
    }
}

