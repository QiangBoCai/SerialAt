package com.example.shentan.chain;

import android.text.TextUtils;

import com.example.shentan.util.ByteUtil;
import com.example.shentan.util.Constant;
import com.example.shentan.util.Utils;

import java.util.LinkedList;

/**
 * mcu心跳包数据拦截器
 */
public class InterceptorMcu implements InterceptorCallBack{
    private final StringBuilder preStrSB = new StringBuilder();
    private final StringBuilder hexStrSB = new StringBuilder();
    private final StringBuilder lastStrSB = new StringBuilder();
    private final StringBuilder mcuStrBuilder = new StringBuilder();

    @Override
    public LinkedList<String> handle(Chain chain) {

        return chain.proceed(dealMcuData(chain,chain.getReceiveByte(),chain.getByteSize())? Constant.DIGIT_1_negative : Constant.DIGIT_2);
    }


    private boolean dealMcuData(Chain chain,byte[] buffer, int size) {

        //mcu数据头位置
        int headerIndex = ByteUtil.getByteIndex(buffer, Constant.MCU_HEADER, 0);
        //mcu数据尾位置
        int endIndex = ByteUtil.getByteIndex(buffer, Constant.MCU_END, headerIndex) + 2;

        //数据是否解析完毕（判断可以直接发出去还是需要进入下一个拦截器）
        boolean parseComplete = false;
        if (endIndex - headerIndex != size){
            try {
                if (headerIndex > 0){ //mcu数据之前还有数据

                    byte[] preByte = ByteUtil.subBytes(buffer,0, headerIndex);
                    Utils.replaceSB(preStrSB,new String(preByte));//mcu数据前面的数据

                    if(!TextUtils.isEmpty(preStrSB.toString())){
                        chain.addReceiveData(preStrSB.toString());
                    }
                }

                if (endIndex < size){
                    byte[] lastByte = ByteUtil.subBytes(buffer, endIndex, (size - endIndex));
                    Utils.replaceSB(lastStrSB,new String(lastByte));//mcu数据后面的数据
                    if(!TextUtils.isEmpty(lastStrSB.toString())){
                        chain.addReceiveData(lastStrSB.toString());
                    }
                }

                //mcu前面没有数据，说明mcu数据后面有粘包数据
                byte[] mcuByte = ByteUtil.subBytes(buffer, headerIndex, (endIndex - headerIndex));
                Utils.replaceSB(hexStrSB,ByteUtil.bytes2HexStr(mcuByte, 0, mcuByte.length));


            }catch (Exception e){
                e.printStackTrace();
            }
        }
        else {

            parseComplete = true;
            Utils.replaceSB(hexStrSB,ByteUtil.bytes2HexStr(buffer, 0, size));

        }
        Utils.replaceSB(hexStrSB,hexStrSB.substring(0, hexStrSB.length()-4).toUpperCase());
        String [] spliteStr = hexStrSB.toString().split(Constant.COMMA);

        Utils.clearSB(mcuStrBuilder);

        try {
            for (int i = 0; i < spliteStr.length; i++) {
                if (i == 0){
                    mcuStrBuilder.append(ByteUtil.hexStringToString(spliteStr[i])); //stdz

                }else {
                    if (spliteStr[i].contains(Constant.DECIMAL)){
                        String[] versionSplit = spliteStr[i].split(Constant.DECIMAL);

                        if (!TextUtils.isEmpty(versionSplit[0])){
                            mcuStrBuilder.append(Integer.parseInt(versionSplit[0],16));
                        }
                        if (!TextUtils.isEmpty(versionSplit[1])){
                            mcuStrBuilder
                                    .append(ByteUtil.hexStringToString(Constant.DECIMAL))
                                    .append(Integer.parseInt(versionSplit[1],16));
                        }


                    }else {
                        try {
                            if (!TextUtils.isEmpty(spliteStr[i])){
                                mcuStrBuilder.append(Integer.parseInt(spliteStr[i],16));

                            }
                        }catch (Exception e){
                            mcuStrBuilder.append(Constant.CODE_0);

                            e.printStackTrace();
                        }
                    }
                }
                if (i < spliteStr.length - 1){
                    mcuStrBuilder.append(",");

                }
            }
            chain.addReceiveData(mcuStrBuilder.toString());
        }catch (Exception e){
            e.printStackTrace();
        }
        return parseComplete;
    }
}
