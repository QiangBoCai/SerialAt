package com.example.shentan.chain;

import android.text.TextUtils;

import com.example.shentan.util.Constant;
import com.example.shentan.util.FindJsonUtil;
import com.example.shentan.util.Utils;

import java.util.LinkedList;

/**
 * 除mcu心跳包以外的数据
 * 包括：AT指令数据、与后端通信数据、无用脏数据
 */
public class InterceptorOther implements InterceptorCallBack{
    private final LinkedList<String> interceptorOtherList = new LinkedList<>();
    private final StringBuilder receiveWebDataBuilderSB = new StringBuilder();
    private final LinkedList<String> jsonArray = new LinkedList<>();

    @Override
    public LinkedList<String> handle(Chain chain) {
        interceptorOtherList.clear();
        if (chain.getReceiveDataList() != null && chain.getReceiveDataList().size() > 0){
            for (String subStr : chain.getReceiveDataList()){
                checkReceiveWebData(subStr);
            }
        }else {
            checkReceiveWebData(chain.getReceiveWebData());

        }

        //数据已经全部解析完成，先清空数据再将解析完成的数据添加进去
        chain.clearData();
        chain.addReceiveAllData(interceptorOtherList);

        return chain.proceed(Constant.DIGIT_1_negative);
    }


    public void checkReceiveWebData(String receiveWebData){

        //receiveWebDataBuilder如果不为空，那就只能拼接}的字符，而不能拼接{的字符，和没有花括号的字符，
        // 这里只支持数据分包两段的情况，多段就没法处理了
        if (!TextUtils.isEmpty(receiveWebDataBuilderSB.toString())&&receiveWebData.contains("}")&&!Utils.isJson(receiveWebData)){
            receiveWebData = receiveWebDataBuilderSB.append(receiveWebData).toString();
            Utils.clearSB(receiveWebDataBuilderSB);

        }
        if (
                receiveWebData.contains(Constant.NO_HEART) ||
                        receiveWebData.contains(Constant.NO_RESTART) ||
                        receiveWebData.contains(Constant.NO_RESTART_RESULT) ||
                        receiveWebData.contains(Constant.NO_PHONE) ||
                        receiveWebData.contains(Constant.NO_PHONE_RESULT) ||
                        receiveWebData.contains(Constant.NO_SMS) ||
                        receiveWebData.contains(Constant.NO_SMS_RESULT) ||
                        receiveWebData.contains(Constant.NO_APP) ||
                        receiveWebData.contains(Constant.NO_APP_RESULT) ||
                        receiveWebData.contains(Constant.NO_BROWSER) ||
                        receiveWebData.contains(Constant.NO_BROWSER_RESULT)
        ){
            //如果字符串中包含这些字符并且不是一个标准字符串，说明有粘包
            if (!Utils.isJson(receiveWebData)){

                jsonArray.clear();
                jsonArray.addAll(FindJsonUtil.format(receiveWebData));
                if (jsonArray.size() > 0){
                    for (String jsonStr : jsonArray){

                        //检测当前json字符串在receiveWebData中的位置
                        int strIndex = receiveWebData.indexOf(jsonStr);
                        // >0 说明字符串前还有数据，则将数据取出发送出去
                        if(strIndex >0){
                            String preStr = receiveWebData.substring(0, strIndex);
                            interceptorOtherList.add(preStr);
                            receiveWebData = receiveWebData.replace(preStr,"");

                        }
                        if (receiveWebData.length() > jsonStr.length() && (receiveWebData.charAt(jsonStr.length())) != '@'){

                            //将当前json字符串发送出去，并删除掉
                            interceptorOtherList.add(jsonStr);
                            receiveWebData = receiveWebData.replace(jsonStr,"");

                        }else {
                            receiveWebData = receiveWebData.substring(receiveWebData.indexOf("@")+1);
                        }
                    }

                    //for循环结束后还有数据，则再拿去检查
                    if (!TextUtils.isEmpty(receiveWebData.trim())){
                        checkReceiveWebData(receiveWebData);
                    }

                }else {
                    receiveWebDataBuilderSB.append(receiveWebData);
                }
            }else {

                //是完整的json，直接发出去
                interceptorOtherList.add(receiveWebData);
            }

        }else {
            //不包含业务号的数据，直接发出去

            if (!receiveWebData.contains("{") && !receiveWebData.contains("}")){
                interceptorOtherList.add(receiveWebData);
                if (!receiveWebData.startsWith(Constant.MCU_PRE)){

                    Utils.clearSB(receiveWebDataBuilderSB);

                }
            }else {
                receiveWebDataBuilderSB.append(receiveWebData);

            }
        }
    }
}
