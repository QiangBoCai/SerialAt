package com.example.shentan.chain;

import com.example.shentan.util.Constant;

import java.util.LinkedList;

/**
 * 责任链的第一个拦截器
 * 用来判断数据应该分发给哪个拦截器
 */
public class InterceptorDispatch implements InterceptorCallBack{
    @Override
    public LinkedList<String> handle(Chain chain) {
        if (chain.getReceiveWebData().contains(Constant.MCU_PRE)) {
            return chain.proceed(Constant.DIGIT_1);

        } else {
            return chain.proceed(Constant.DIGIT_2);

        }

    }
}
