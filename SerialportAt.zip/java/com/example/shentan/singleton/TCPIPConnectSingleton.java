package com.example.shentan.singleton;

import android.text.TextUtils;

import com.example.shentan.util.Utils;

import java.util.UUID;

/**
 * TCP连接状态检测单例
 * 一定时间内没收到TCP连接则重启串口重新建立连接
 * 2022/4/15
 */
public enum TCPIPConnectSingleton {
    INSTANCE;
    private final StringBuilder tcpIpConnectStateFlagSB;
    private final StringBuilder tcpIpConnectStateFlagCheckSB;


    TCPIPConnectSingleton(){
        tcpIpConnectStateFlagSB = new StringBuilder("init");
        tcpIpConnectStateFlagCheckSB = new StringBuilder();
    }
    public void setDeviceState(){
        Utils.replaceSB(tcpIpConnectStateFlagSB,UUID.randomUUID().toString().trim());

    }

    public void setTCPIPConnectStateFlagCheck(){
        Utils.replaceSB(tcpIpConnectStateFlagCheckSB,tcpIpConnectStateFlagSB);

    }

    public boolean compareTCPIPConnectStateFlag(){
        return !TextUtils.isEmpty(tcpIpConnectStateFlagSB.toString()) &&
                !TextUtils.isEmpty(tcpIpConnectStateFlagCheckSB.toString()) &&
                (tcpIpConnectStateFlagSB.toString()).equals(tcpIpConnectStateFlagCheckSB.toString());
    }
}
