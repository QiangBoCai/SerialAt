package com.example.shentan.singleton;

import android.text.TextUtils;

import com.example.shentan.util.Utils;

import java.util.UUID;

/**
 * 设备拨号状态单例
 * 防止挂断失败导致的长时间处于通话状态
 * 当检测到通话时长过长时，自动挂断
 * 通话时长暂定5分钟，后续需注意跟后端沟通通话是否会超过5分钟
 * 2022/4/15
 */
public enum PhoneStateSingleton {
    INSTANCE;
    private final StringBuilder phoneStateFlagSB;
    private final StringBuilder phoneStateFlagCheckSB;

    PhoneStateSingleton(){
        phoneStateFlagSB = new StringBuilder();
        phoneStateFlagCheckSB = new StringBuilder();
    }


    public void setDeviceState(){
        Utils.replaceSB(phoneStateFlagSB,UUID.randomUUID().toString().trim());
    }

    public void setPhoneStateFlagCheck(){
        Utils.replaceSB(phoneStateFlagCheckSB,phoneStateFlagSB.toString());

    }

    public boolean comparePhoneStateFlag(){
        return !TextUtils.isEmpty(phoneStateFlagSB.toString()) &&
                !TextUtils.isEmpty(phoneStateFlagCheckSB.toString()) &&
                (phoneStateFlagSB.toString()).equals(phoneStateFlagCheckSB.toString());
    }
}
