package com.example.shentan.singleton;

import android.text.TextUtils;

import com.example.shentan.util.Utils;

import java.util.UUID;

/**
 * 设备正忙单例
 * 设备从接收到后端指令开始，到设备执行完该指令后给后端发送执行结果结束，此期间为正忙
 * 一定时间内一直处于正忙则重置状态
 * 2022/4/15
 */
public enum DeviceStateSingleton {
    INSTANCE;
    private boolean deviceBusyState;
    private final StringBuilder deviceStateFlagSB;
    private final StringBuilder deviceStateFlagCheckSB;

    DeviceStateSingleton(){
        deviceStateFlagSB = new StringBuilder();
        deviceStateFlagCheckSB = new StringBuilder();
    }

    public void setDeviceState(boolean deviceBusyState){
        this.deviceBusyState = deviceBusyState;

        if (deviceBusyState){
            Utils.replaceSB(this.deviceStateFlagSB,UUID.randomUUID().toString().trim());
        }else {
            Utils.clearSB(this.deviceStateFlagSB);
        }

    }

    public void setDeviceStateFlagCheck(){
        Utils.replaceSB(deviceStateFlagCheckSB,deviceStateFlagSB);
    }

    public boolean compareDeviceStateFlag(){
        return !TextUtils.isEmpty(deviceStateFlagSB.toString()) &&
                !TextUtils.isEmpty(deviceStateFlagCheckSB.toString()) &&
                (deviceStateFlagSB.toString()).equals(deviceStateFlagCheckSB.toString());
    }


    public boolean isDeviceBusyState() {
        return deviceBusyState;
    }
}
