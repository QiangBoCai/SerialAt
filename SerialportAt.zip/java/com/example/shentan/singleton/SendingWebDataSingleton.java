package com.example.shentan.singleton;

import android.text.TextUtils;

import com.example.shentan.util.Utils;

import java.util.UUID;

/**
 * 设备给后端发送数据状态检测单例
 * 给Web端发送数据由两部分组成：1、发送AT+CIPSEND 2、发送数据
 * 从【1】开始，到【2】结束
 * 发送了【1】后，收到串口回复【>】后，才会向串口发送【2】
 * 如果发送了【1】后，一定时间内内没收到回复【>】，重启
 * 2022/4/15
 */
public enum SendingWebDataSingleton {
    INSTANCE;
    private boolean sendingWebStateState;
    private final StringBuilder sendingFlagSB;
    private final StringBuilder sendingFlagCheckSB;
    SendingWebDataSingleton(){
        sendingFlagSB = new StringBuilder();
        sendingFlagCheckSB = new StringBuilder();
    }
    public void setSendingState(boolean deviceBusyState){
        this.sendingWebStateState = deviceBusyState;


        if (deviceBusyState){

            Utils.replaceSB(this.sendingFlagSB,UUID.randomUUID().toString().trim());

        }else {
            Utils.clearSB(sendingFlagSB);

        }

    }

    public void setSendingFlagCheck(){
        Utils.replaceSB(sendingFlagCheckSB,sendingFlagSB);

    }

    public boolean compareSendingStateFlag(){
        return !TextUtils.isEmpty(sendingFlagSB.toString()) &&
                !TextUtils.isEmpty(sendingFlagCheckSB.toString()) &&
                (sendingFlagSB.toString()).equalsIgnoreCase(sendingFlagCheckSB.toString());
    }


    public boolean isSendingWebStateState() {
        return sendingWebStateState;
    }
}
