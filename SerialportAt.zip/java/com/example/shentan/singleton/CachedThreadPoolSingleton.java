package com.example.shentan.singleton;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 线程池
 */
public class CachedThreadPoolSingleton {
    private static volatile ExecutorService cachedThreadPool;

    private CachedThreadPoolSingleton(){

    }

    public static ExecutorService getInstance(){
        if (cachedThreadPool == null){
            synchronized (CachedThreadPoolSingleton.class){
                if (cachedThreadPool == null){
                    cachedThreadPool = Executors.newCachedThreadPool();
                }
            }
        }
        return cachedThreadPool;
    }

    public static void shutdown() {
        if (cachedThreadPool != null){
            cachedThreadPool.shutdown();
            cachedThreadPool = null;
        }
    }

}
