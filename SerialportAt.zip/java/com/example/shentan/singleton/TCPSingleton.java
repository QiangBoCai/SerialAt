package com.example.shentan.singleton;

import android.text.TextUtils;

import com.example.shentan.util.Utils;

import java.util.UUID;

public enum TCPSingleton {
    INSTANCE;
    //存在未收到回复的步骤的索引，-1为没有未回复
    private int tcpLostIndex = -1;
    //tcp当前完成的步骤最后一步的索引
    private int tcpIndex;
    private final StringBuilder indexFlagSB;
    private final StringBuilder indexFlagCheckSB;

    TCPSingleton(){
        indexFlagSB = new StringBuilder();
        indexFlagCheckSB = new StringBuilder();
    }

    public int getTcpLostIndex() {
        return tcpLostIndex;
    }

    public void setTcpLostIndex(int tcpLostIndex) {
        this.tcpLostIndex = tcpLostIndex;
    }

    public void setIndex(int tcpIndex){
        this.tcpIndex = tcpIndex;
        setTcpLostIndex(-1);
        Utils.replaceSB(this.indexFlagSB, UUID.randomUUID().toString().trim());
    }
    public void setIndex(){
        Utils.replaceSB(this.indexFlagSB, UUID.randomUUID().toString().trim());
    }

    public void setIndexFlagCheck(){
        setTcpLostIndex(-1);
        Utils.replaceSB(indexFlagCheckSB, indexFlagSB);
    }

    public boolean compareIndexFlagFlag(){
        return !TextUtils.isEmpty(indexFlagSB.toString()) &&
                !TextUtils.isEmpty(indexFlagCheckSB.toString()) &&
                (indexFlagSB.toString()).equals(indexFlagCheckSB.toString());
    }


    public int getIndex() {
        return tcpIndex;
    }
}

