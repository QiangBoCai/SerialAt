package com.example.shentan.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.shentan.strategy.strategyApp.AppStrategyWeiChat;
import com.example.shentan.util.Constant;

/**
 * 微信动作广播
 */
public class WeiChatActionBroadcastReceiver extends BroadcastReceiver {
    private final AppStrategyWeiChat appStrategyWeiChat;
    public WeiChatActionBroadcastReceiver(AppStrategyWeiChat appStrategyWeiChat){
        this.appStrategyWeiChat = appStrategyWeiChat;
    }

    @Override
    public void onReceive(Context arg0, Intent arg1) {


        String script = arg1.getStringExtra("script");
        String work = arg1.getStringExtra("work");
        boolean result = arg1.getBooleanExtra("result",false);
        //执行的是不是群动作
        boolean isGroup = arg1.getBooleanExtra("isGroup",false);


        if (script.equals(Constant.RECEIVE_AND_RESPONSE_AND_DOWNLOAD)){
            //判断是群组消息还是点对点消息
            if (isGroup){
                if (work.contains(Constant.RECEIVE_AND_RESPONSE_AND_DOWNLOAD_TEXT)){
                    appStrategyWeiChat.weiChatBean.setCommand(Constant.CODE_16);
                }else if (work.contains(Constant.RECEIVE_AND_RESPONSE_AND_DOWNLOAD_FILE)){
                    appStrategyWeiChat.weiChatBean.setCommand(Constant.CODE_15);
                }
            }else {
                if (work.contains(Constant.RECEIVE_AND_RESPONSE_AND_DOWNLOAD_TEXT)){
                    appStrategyWeiChat.weiChatBean.setCommand(Constant.CODE_10);
                }else if (work.contains(Constant.RECEIVE_AND_RESPONSE_AND_DOWNLOAD_FILE)){
                    appStrategyWeiChat.weiChatBean.setCommand(Constant.CODE_9);
                }
            }
        }else {
            appStrategyWeiChat.weiChatBean.setCommand(Constant.weiChat_action_map_key.get(script));

        }


        if (result){

            appStrategyWeiChat.returnWeiChatResult(Constant.CODE_1);
        }else {
            appStrategyWeiChat.returnWeiChatResult(Constant.CODE_2);
        }

    }
}
