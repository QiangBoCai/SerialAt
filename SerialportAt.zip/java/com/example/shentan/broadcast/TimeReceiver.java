package com.example.shentan.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.icu.util.Calendar;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.singleton.DeviceStateSingleton;
import com.example.shentan.singleton.PhoneStateSingleton;
import com.example.shentan.singleton.SendingWebDataSingleton;
import com.example.shentan.singleton.TCPIPConnectSingleton;
import com.example.shentan.util.Constant;

import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

public class TimeReceiver extends BroadcastReceiver {

    private int preMin = 0;

    private final SerialPortActivity serialPortActivity;
    public TimeReceiver(SerialPortActivity serialPortActivity){
        this.serialPortActivity = serialPortActivity;
    }
    @Override
    public void onReceive(Context context, Intent intent) {
        //region 分钟广播
        if (Intent.ACTION_TIME_TICK.equals(intent.getAction())){

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                Calendar cal = Calendar.getInstance();
                int hour = cal.get(Calendar.HOUR_OF_DAY);
                int min = cal.get(Calendar.MINUTE);

                //todo
                // 此处直接重启可能会中断业务流程
                // 后续需要考虑是否检测业务完成后再去重启
                // 需要让后端增加业务结束的标志
                if (hour == 0 && min == 0) {
                    try {
                        FutureTask<Boolean> futureTask = serialPortActivity.futureTaskUtils.reboot();
                        CachedThreadPoolSingleton.getInstance().execute(futureTask);
                        futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);
                    } catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }

                calculate(min);
            }
        }//endregion
    }


    private void calculate(int min){

        //间隔5分钟
        if ((min > preMin && min - preMin >= Constant.DIGIT_5) || (min < preMin && 60 - preMin + min >= Constant.DIGIT_5)){
            preMin = min;
            checkTCPIPConnectSingleton();
            checkSendingWebDataSingleton();
            checkPhoneStateSingleton();
            checkDeviceStateSingleton();
        }
    }

    /**
     *  如果设备正忙状态持续了五分钟，则重置
     */
    private void checkDeviceStateSingleton() {
        if (DeviceStateSingleton.INSTANCE.isDeviceBusyState()) {
            //检测到数据与上一次检查的一致，说明设备状态从上次检测持续到现在
            if (DeviceStateSingleton.INSTANCE.compareDeviceStateFlag()) {
                DeviceStateSingleton.INSTANCE.setDeviceState(false);
            } else {
                DeviceStateSingleton.INSTANCE.setDeviceStateFlagCheck();
            }
        }
    }

    /**
     *检测到拨号状态与上一次检查时一致，
     * 则说明在这段时间内一直在拨号没有挂断
     * 则主动挂断电话
     */
    private void checkPhoneStateSingleton() {

        if (PhoneStateSingleton.INSTANCE.comparePhoneStateFlag()) {

            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        //判断是否在通话中，是则挂断电话
                        if (serialPortActivity.iservice.getCallState(Constant.ODMSZ_TOKEN) == TestControlReceiver.CALL_STATE_OFFHOOK){
                            serialPortActivity.iservice.endCall(Constant.ODMSZ_TOKEN);
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                }
            });

        } else {
            PhoneStateSingleton.INSTANCE.setPhoneStateFlagCheck();
        }
    }

    /**
     *  如果设备正在发送数据状态持续了5分钟，则重启
     */
    private void checkSendingWebDataSingleton() {

        if (SendingWebDataSingleton.INSTANCE.isSendingWebStateState()) {
            //检测到数据与上一次检查的一致，说明设备状态从上次检测持续到现在
            if (SendingWebDataSingleton.INSTANCE.compareSendingStateFlag()) {
                FutureTask<Boolean> futureTask = serialPortActivity.futureTaskUtils.reboot();
                CachedThreadPoolSingleton.getInstance().execute(futureTask);
            } else {
                SendingWebDataSingleton.INSTANCE.setSendingFlagCheck();
            }
        }
    }

    /**
     *  检测到tcpIpConnectStateFlag与上一次检查时一直，
     *  则说明在这段时间内tcpIpConnectStateFlag没变过，
     *  就是在这段时间内没收到心跳回复
     */
    private void checkTCPIPConnectSingleton() {

        if (TCPIPConnectSingleton.INSTANCE.compareTCPIPConnectStateFlag()) {
            TCPIPConnectSingleton.INSTANCE.setDeviceState();
            // 重启串口
            serialPortActivity.close4GSerialPort(true);
        } else {

            TCPIPConnectSingleton.INSTANCE.setTCPIPConnectStateFlagCheck();
        }
    }
}
