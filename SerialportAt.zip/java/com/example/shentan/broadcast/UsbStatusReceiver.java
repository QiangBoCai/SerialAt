package com.example.shentan.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.shentan.MainActivity;
import com.example.shentan.util.LogUtil;

/**
 * android外接存储设备状态判断-USB和SD卡连接状态广播
 * @author amyHuang
 *
 */
public class UsbStatusReceiver extends BroadcastReceiver {


	@Override
	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction();
		LogUtil.print("intent.getAction():"+intent.getAction());
		if(action.equals(Intent.ACTION_MEDIA_MOUNTED)){
			LogUtil.print("UsbStatusReceiver ACTION_MEDIA_MOUNTED");
			Intent it = new Intent(context, MainActivity.class);
			it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			LogUtil.print("startActivity MainActivity");
			context.startActivity(it);
		}

	}

}
