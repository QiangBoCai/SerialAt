package com.example.shentan.broadcast;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.BatteryManager;
import android.text.TextUtils;
import com.example.shentan.SerialPortActivity;
import com.example.shentan.singleton.PhoneStateSingleton;
import com.example.shentan.util.ByteUtil;
import com.example.shentan.util.Constant;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;
import com.odmsz.control.PreciseCallState;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONObject;
import java.text.SimpleDateFormat;


public class TestControlReceiver extends BroadcastReceiver{

	public static final String TAG = "TestControlReceiver";
    public static final String ODMSZ_SMS_RECEIVED = "android.intent.action.ODMSZ_SMS_RECEIVED";
    public static final String ODMSZ_CALL_RECEIVED = "android.intent.action.ODMSZ_CALL_RECEIVED";

	public static final String ODMSZ_MMS_SENT_ACTION =  "android.intent.action.ODMSZ_MMS_SENT";

	public static final String ODMSZ_MMS_RECEIVED = "android.intent.action.ODMSZ_MMS_RECEIVED";
	public static final String ODMSZ_USSD_SENT_ACTION =  "android.intent.action.ODMSZ_USSD_SENT";
	public static final String ODMSZ_CALL_ACTIVE = "android.intent.action.ODMSZ_CALL_ACTIVE";
	public static final String WECHAT_PAY_BROADCAST = "wechat.pay.Broadcast";

	public static int ACCEPT_RING_CALL = 0;
	public static int batteryTemperature=0;
    /**
     * Device call state: No activity.
     */
    public static final int CALL_STATE_IDLE = 0;
    /**
     * Device call state: Ringing. A new call arrived and is
     *  ringing or waiting. In the latter case, another call is
     *  already active.
     */
    public static final int CALL_STATE_RINGING = 1;
    /**
     * Device call state: Off-hook. At least one call exists
     * that is dialing, active, or on hold, and no calls are ringing
     * or waiting.
     */
    public static final int CALL_STATE_OFFHOOK = 2;
    
	public static PreciseCallState preciseCallState = new PreciseCallState();
	private final SerialPortActivity serialPortActivity;
	public TestControlReceiver(SerialPortActivity serialPortActivity){
		this.serialPortActivity = serialPortActivity;
	}
    @Override  
    public void onReceive(final Context context, Intent intent){	
    	String receiveAction = intent.getAction();

		//region 电池电量
		if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())){
			batteryTemperature = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);

		}//endregion

		//region 接收到短信
		else if (ODMSZ_SMS_RECEIVED.equals(receiveAction)){
			LogUtil.print("enter into ODMSZ_SMS_RECEIVED");
    		StringBuilder strb = new StringBuilder();
    		String phone = intent.getStringExtra("phone");
    		String content = intent.getStringExtra("content");
    		String centerAdress = intent.getStringExtra("centerAddress");
    		strb.append("phone:"+phone)
    			.append("\n")
    			.append("content:"+content)
    			.append("\n")
    			.append("centerAdress:"+centerAdress);
    		//todo
			//后续考虑是否需要用集合将收到的短信存储起来
			//在收到短信指令时，在集合中通过号码判断是否有收到该号码的短信
			//在回复结果后将集合清空
			//这样只存储一个短信可能会被垃圾短信覆盖掉
			//需要让后端在接受短信的数据中加上发送短信的设备号码，以做比对
			Constant.RECEIVE_NEW_SMS = content;

    	}//endregion

		//region 接收到彩信
    	else if (ODMSZ_MMS_RECEIVED.equals(receiveAction)){
			LogUtil.print("enter into ODMSZ_MMS_RECEIVED");
			StringBuilder strb = new StringBuilder();
			long date = intent.getLongExtra("date", 0);
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss SSS");

			String phone = intent.getStringExtra("phone").replace("+","").trim();
			String sub = intent.getStringExtra("sub");
			byte[] image = intent.getByteArrayExtra("image");
    		strb.append("phone:"+phone)
    			.append("\n sub:"+sub)
    			.append("\n dateTime:"+format.format(date));
			Bitmap bp = null;
			if(image!=null){
				strb.append("\n image byteSize:"+image.length);
				LogUtil.print("image byteSize:"+image.length);
				bp = ByteUtil.Bytes2Bimap(image);

			}else{
				strb.append("\n image is null");
				LogUtil.print("image is null");
			}


			Utils.createSaveFile(false,bp);

			Constant.CAIXIN_TARGET_PHONE = phone;
			Constant.CAIXIN_MSG = sub;
			LogUtil.print("enter into ODMSZ_MMS_RECEIVED Constant.CAIXIN_TARGET_PHONE:"+Constant.CAIXIN_TARGET_PHONE);
			if (bp != null){
				bp.recycle();

			}

		}//endregion

    	//region 彩信发送
    	else if (ODMSZ_MMS_SENT_ACTION.equals(receiveAction)){
			LogUtil.print("enter into ODMSZ_MMS_SENT_ACTION");
//    		appIntent.putExtra("result", "彩信发送成功!");
//            appIntent.putExtra("phone",phone);
//            appIntent.putExtra("subject", subject);
//            appIntent.putExtra("text", text);
//            appIntent.putExtra("imagePath", imagePath);
//            appIntent.putExtra("audioPath", audioPath);
			String result = intent.getStringExtra("result");
			if (result.contains("彩信发送成功")){
				Constant.CAIXIN_SEND = true;
				EventBus.getDefault().post("发送了彩信");
			}
		}//endregion

    	//region 呼叫转移的结果
    	else if(ODMSZ_USSD_SENT_ACTION.equals(receiveAction)){
			LogUtil.print("enter into ODMSZ_USSD_SENT_ACTION");
			String request = intent.getStringExtra("request");
			String response = intent.getStringExtra("response");
			//成功 ： code为0
			int code = intent.getIntExtra("code", -1);
//			request = **21*15869186656# response = 来电转接 注册成功。 code = 0

			if (request.equals(Constant.TRANSFER_FLAG)){

				Constant.TRANSFER_FLAG_RESULT = code == 0;

			}
		}//endregion

    	//region 电话接通时间，主叫被叫接通电话时都有广播
		else if(ODMSZ_CALL_ACTIVE.equals(receiveAction)){
			LogUtil.print("enter into ODMSZ_CALL_ACTIVE !Constant.SOUND_PLAY="+!Constant.SOUND_PLAY);
			PhoneStateSingleton.INSTANCE.setDeviceState();
			long time = intent.getLongExtra("time",0);
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss SSS");
			Constant.DIAL_ACCEPT = time;
			//主叫被叫都需要播放语音
			if (!Constant.SOUND_PLAY) {
				Constant.SOUND_PLAY = true;
				serialPortActivity.strategyFactory.getBusinessStrategyPhone().soundPlay();
			}
		}//endregion

    	//region 语音通话广播
    	else if (ODMSZ_CALL_RECEIVED.equals(receiveAction)){
			LogUtil.print("enter into ODMSZ_CALL_RECEIVED");
    		String incomingNumber = intent.getStringExtra("number"); //呼入号码
    		int state = intent.getIntExtra("state",0);
    		preciseCallState =  intent.getParcelableExtra("preciseCallState");
			long time = intent.getLongExtra("time",0);

			LogUtil.print("enter into ODMSZ_CALL_RECEIVED state="+state);
    		//先判断state，再判断preciseCallState
    		switch(state){
    			//挂断,无论作为主叫还是被叫，无论哪方挂断，都会收到这个广播，未接听电话
	  	       case CALL_STATE_IDLE: {

				   PhoneStateSingleton.INSTANCE.setDeviceState();

				   Constant.DIAL_BREAK = time;

				   //无需应答流程的挂断回复
				   if (!TextUtils.isEmpty(Constant.PHONE_DISRESPONSE_NUMBER) && incomingNumber.equals(Constant.PHONE_DISRESPONSE_NUMBER)) {
					   Constant.PHONE_DISRESPONSE_NUMBER = "";
					   serialPortActivity.strategyFactory.getBusinessStrategyPhone().returnPhoneResult(Constant.CODE_1,Utils.getTimeMillis());

				   }


				   break;
			   }

	  	       case CALL_STATE_OFFHOOK: {

	  	       	try {

					JSONObject jsonObject = new JSONObject(preciseCallState.toString());

					int foregroundCallState = jsonObject.getInt("ForegroundCallState");
					LogUtil.print("foregroundCallState="+foregroundCallState);

					switch (foregroundCallState){

							//主叫拨号时会收到这个广播，可以用来判定设备为主叫
						case PreciseCallState.PRECISE_CALL_STATE_ALERTING : //拨号
						case PreciseCallState.PRECISE_CALL_STATE_DIALING : {//拨号
							Constant.DIAL_RING = time;
						}
						case PreciseCallState.PRECISE_CALL_STATE_ACTIVE : {//接听来电
							serialPortActivity.strategyFactory.getBusinessStrategyPhone().setTargetPhone(incomingNumber);
							break;
						}

					}

				}catch (Exception e){
	  	       		e.printStackTrace();
				}
				   break;
			   }

			   //来电响铃，只有来电响铃时才会有这个广播，可以通过这里判断设备为被叫
				case CALL_STATE_RINGING:{
					Constant.DIAL_RING = time;
					break;
				}

	  		}

    	}//endregion


    }

}














