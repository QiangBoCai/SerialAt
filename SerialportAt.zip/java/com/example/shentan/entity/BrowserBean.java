package com.example.shentan.entity;

/**
 * 网页业务数据类
 * @controlNo  控制号
 * @command  命令:1打开网址检索目标网页
 * @targetURL  搜索目标网址
 * @commandResult  执行结果
 * @resultMsg  执行结果的解释信息（通常用于解释失败原因）
 * @moduleFormat   2：2G; 3: 3G; 4 : 4G; 5 : 5G
 * @operator   1 ：移动  2 ：联通  3 ：电信
 * @machinePhone 本机ICCID（不是本机号码）
 * @tac  大区
 * @eci  小区
 * @targetId
 * 2022/4/15
 */
public class BrowserBean extends BaseRequestBean{

    public String controlNo = "";
    public String command = "";
    public String targetURL = "";
    public String commandResult = "";
    public String resultMsg = "";
    public String moduleFormat = "";
    public String operator = "";
    public String machinePhone = "";
    public String tac = "";
    public String eci = "";
    public String targetId = "";

    public void setMachinePhone(String machinePhone) {
        this.machinePhone = machinePhone;
    }

    public void setTac(String tac) {
        this.tac = tac;
    }

    public void setEci(String eci) {
        this.eci = eci;
    }

    public String getModuleFormat() {
        return moduleFormat;
    }

    public String getOperator() {
        return operator;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getCommand() {
        return command;
    }

    public String getTargetURL() {
        return targetURL;
    }

    public void setCommandResult(String commandResult) {
        this.commandResult = commandResult;
    }

}

