package com.example.shentan.entity;

/**
 * 设备网络状态信息数据类
 * 字段详情查阅软硬交互文档
 * @ srvStatus   0 无服务 1 有限制服务 2 有服务 3 有限制区域服务 4 省电状态
 * @ srvDomain   0 无服务1 CS 服务2 PS 服务3 PS 和 CS 服务4 EPS 服务
 * @ roamStatus  0 非漫游状态1 漫游状态
 * @ sysMode     0 无服务2 CDMA 3 GSM/GPRS 模式 4 HDR5 WCDMA 模式  7 GW  9 LTE  10 GWL  11 TDS  12 NR5G 其他值 保留
 * @ simState    0 卡状态无效1 卡状态有效255 卡不存在或需要 PIN 码
 * 2022/4/15
 */
public class SysInfoBean{
    public String srvStatus = "";
    public String srvDomain = "";
    public String roamStatus = "";
    public String sysMode = "";
    public String simState = "";

    public void setSrvStatus(String srvStatus) {
        this.srvStatus = srvStatus;
    }

    public void setSrvDomain(String srvDomain) {
        this.srvDomain = srvDomain;
    }

    public void setRoamStatus(String roamStatus) {
        this.roamStatus = roamStatus;
    }

    public void setSysMode(String sysMode) {
        this.sysMode = sysMode;
    }

    public void setSimState(String simState) {
        this.simState = simState;
    }

}
