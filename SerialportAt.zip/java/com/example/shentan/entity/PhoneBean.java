package com.example.shentan.entity;

import com.example.shentan.SerialPortActivity;

/**
 * 电话业务数据类
 * @controlNo  控制号（服务端生成的）
 * @command  命令
 * @commandResult  执行结果
 * @resultMsg  执行结果的解释信息（通常用于解释失败原因）
 * @conditionsPhone  条件电话号码 例如，无条件前转号码
 * @conditionsAction  条件动作
 * @targetPhone  目标电话号码
 * @talkTime  单位秒，下发指令与目标电话通话时长要求
 * @phoneFormat   2：2G; 3: 3G;  4 : 4G 5 : 5G
 * @operator   1 移动  2 电信  3 联通
 * @machinePhone  IccId（不是本机号码）
 * @tac  大区
 * @eci  小区
 * @isAction 是否执行了动作
 * @actionTime 执行动作的时间
 * @detailMsg 执行动作失败详细信息
 * @networkState 网络状态  -1 无卡，0 无网络，5 5G 4 4G 3 3G 2 2G 1 Wifi
 * 2022/4/15
 */
public class PhoneBean extends BaseRequestBean{
    public String controlNo = "";
    public String command = "";
    public String commandResult = "";
    public String resultMsg = "";
    public String conditionsPhone = "";
    public String conditionsAction = "";
    public String targetPhone = "";
    public String talkTime = "";
    public String phoneFormat = "";
    public String operator = "";
    public String machinePhone = "";
    public String tac = "";
    public String eci = "";

    public void setMachinePhone(String machinePhone) {
        this.machinePhone = machinePhone;
    }

    public void setTac(String tac) {
        this.tac = tac;
    }

    public void setEci(String eci) {
        this.eci = eci;
    }

    public String getOperator() {
        return operator;
    }

    public String getCommand() {
        return command;
    }

    public void setCommandResult(String commandResult) {
        this.commandResult = commandResult;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }
    public String getConditionsPhone() {
        return conditionsPhone;
    }

    public String getTargetPhone() {
        return targetPhone;
    }

    public void setTargetPhone(String targetPhone) {
        this.targetPhone = targetPhone;
    }

    public String getTalkTime() {
        return talkTime;
    }

    public void setTalkTime(String talkTime) {
        this.talkTime = talkTime;
    }


    public String getPhoneFormat() {
        return phoneFormat;
    }

}

