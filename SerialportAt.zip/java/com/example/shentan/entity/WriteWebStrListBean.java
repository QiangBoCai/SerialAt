package com.example.shentan.entity;

/**
 * @strContent  发送给后端的数据内容
 * @sendToWeb 发送给串口的指令，还是发送给后台的数据标志
 * @byteArr  mcu数据byte数据流
 * @hexCommand  发送给mcu的数据是心跳包还是后台指令
 * @isHex  发送给串口的数据是否是Hex，发送给mcu的数据都是hex，发送给后端的都是String
 * 2022/4/15
 */
public class WriteWebStrListBean {
    private String strContent;
    private boolean sendToWeb;
    private byte[] byteArr;
    private boolean hexCommand;
    private boolean isHex;


    public WriteWebStrListBean(String strContent,boolean sendToWeb,boolean isHex,boolean hexCommand,byte[]...byteArr){
        this.strContent =  strContent;
        this.sendToWeb =  sendToWeb;
        this.isHex =  isHex;
        this.hexCommand =  hexCommand;
        if (byteArr.length > 0){
            this.byteArr =  byteArr[0];
        }
    }


    public boolean isHexCommand() {
        return hexCommand;
    }

    public byte[] getByteArr() {
        return byteArr;
    }

    public boolean isHex() {
        return isHex;
    }

    public boolean isSendToWeb() {
        return sendToWeb;
    }

    public String getStrContent() {
        return strContent;
    }

}
