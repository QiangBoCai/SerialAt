package com.example.shentan.entity;

/**
 * @mcuHardwareVersion  硬件版本
 * @mcuSoftwareVersion  单片机软件版本
 * @phoneSystemVersion  手机固件版本(系统版本)
 * @IMEI_4G  手机序列号(4G模块的IMEI)
 * 2022/4/15
 */
public class DevicesRemarkBean {

    private String mcuHardwareVersion = "";
    private String mcuSoftwareVersion = "";
    private String phoneSystemVersion = "";
    private String IMEI_4G = "";


    public void setMcuHardwareVersion(String mcuHardwareVersion) {
        this.mcuHardwareVersion = mcuHardwareVersion;
    }

    public void setMcuSoftwareVersion(String mcuSoftwareVersion) {
        this.mcuSoftwareVersion = mcuSoftwareVersion;
    }

    public void setPhoneSystemVersion(String phoneSystemVersion) {
        this.phoneSystemVersion = phoneSystemVersion;
    }

    public void setIMEI_4G(String IMEI_4G) {
        this.IMEI_4G = IMEI_4G;
    }

}
