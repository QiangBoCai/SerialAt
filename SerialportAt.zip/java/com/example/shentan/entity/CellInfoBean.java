package com.example.shentan.entity;

/**
 * 大区小区数据数据类
 * @pci
 * @tac  大区
 * @arfcn  频点
 * @eci  小区
 * @rssi  信号强度
 * 2022/4/15
 */
public class CellInfoBean {
    private String pci = "";
    private String tac = "";
    private String arfcn = "";
    private String eci = "";
    private String rssi = "";



    public String getPci() {
        return pci;
    }

    public void setPci(String pci) {
        this.pci = pci;
    }

    public String getTac() {
        return tac;
    }

    public void setTac(String tac) {
        this.tac = tac;
    }

    public String getArfcn() {
        return arfcn;
    }

    public void setArfcn(String arfcn) {
        this.arfcn = arfcn;
    }

    public String getEci() {
        return eci;
    }

    public void setEci(String eci) {
        this.eci = eci;
    }

    public String getRssi() {
        return rssi;
    }

    public void setRssi(String rssi) {
        this.rssi = rssi;
    }
}
