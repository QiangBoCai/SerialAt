package com.example.shentan.entity;

/**
 * 微信业务数据类
 * @controlNo  控制号
 * @command  命令
 * @appId  appId=1代表微信
 * @behaviorAppId  从后端接收后原样传回后端
 * @commandResult  执行结果
 * @resultMsg  执行结果的解释信息（通常用于解释失败原因）
 * 2022/4/15
 */
public class WeiChatBean extends BaseRequestBean{

    public String controlNo = "";
    public String command = "";
    public String appId = "";
    public String behaviorAppId = "";
    public String commandResult = "";
    public String resultMsg = "";

    public void setCommandResult(String commandResult) {
        this.commandResult = commandResult;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

}
