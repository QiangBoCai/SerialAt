package com.example.shentan.entity;

/**
 * 高德地图业务数据类
 * @controlNo  控制号
 * @command  1：打开高德地图导航:2：打开高德地图搜索目标
 * @targetLon  目的地经度
 * @targetLat  目的地维度
 * @targetAddress  具体目的地地址
 * @commandResult  执行结果
 * @resultMsg  执行结果的解释信息（通常用于解释失败原因）
 * @appId  appId=3代表高德
 * @behaviorAppId  从后端接收后原样传回后端
 * 2022/4/15
 */
public class GaoDeBean extends BaseRequestBean{

    public String controlNo = "";
    public String command = "";
    public String targetLon = "";
    public String targetLat = "";
    public String targetAddress = "";
    public String commandResult = "";
    public String resultMsg = "";
    public String appId = "";
    public String behaviorAppId = "";

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public void setCommandResult(String commandResult) {
        this.commandResult = commandResult;
    }

    public String getCommand() {
        return command;
    }

    public String getTargetLon() {
        return targetLon;
    }

    public String getTargetLat() {
        return targetLat;
    }

    public String getTargetAddress() {
        return targetAddress;
    }

}
