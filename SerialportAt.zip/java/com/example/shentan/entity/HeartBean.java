package com.example.shentan.entity;

/**
 * 心跳包数据类
 * @cpin 是否有卡  0无卡、1有卡
 * @tac  大区
 * @eci  小区
 * @pci
 * @arfcn  频点号
 * @rssi  信号强度
 * @state  设备当前状态：0空闲，1正忙
 * @machinePhone  iccid（不是本机号码）
 * @devicesRemark  硬件版本 单片机软件版本 手机固件版本(系统版本) 手机序列号(4G模块的IMEI)
 * @sysinfo  SysInfoBean
 * 2022/4/15
 */
public class HeartBean extends BaseRequestBean{

    public String cpin = "";
    public String tac = "";
    public String eci = "";
    public String pci = "";
    public String arfcn = "";
    public String rssi = "";
    public String state = "";
    public String machinePhone = "";
    public String devicesRemark ;
    public SysInfoBean sysinfo;

    public void setDevicesRemark(String devicesRemark) {
        this.devicesRemark = devicesRemark;
    }

    public void setMachinePhone(String machinePhone) {
        this.machinePhone = machinePhone;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setCpin(String cpin) {
        this.cpin = cpin;
    }

    public String getTac() {
        return tac;
    }

    public void setTac(String tac) {
        this.tac = tac;
    }

    public void setEci(String eci) {
        this.eci = eci;
    }

    public void setPci(String pci) {
        this.pci = pci;
    }

    public void setArfcn(String arfcn) {
        this.arfcn = arfcn;
    }

    public void setRssi(String rssi) {
        this.rssi = rssi;
    }

    public void setSysinfo(SysInfoBean sysinfo) {
        this.sysinfo = sysinfo;
    }

}
