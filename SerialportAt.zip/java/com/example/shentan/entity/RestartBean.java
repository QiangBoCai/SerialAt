package com.example.shentan.entity;

/**
 * 重启业务数据类
 * 重启通过飞行实现
 * @commandResult  执行结果
 * @resultMsg  执行结果的解释信息（通常用于解释失败原因）
 * 2022/4/15
 */
public class RestartBean extends BaseRequestBean{
    public String commandResult = "";
    public String resultMsg = "";

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public void setCommandResult(String commandResult) {
        this.commandResult = commandResult;
    }

}
