package com.example.shentan.entity;

/**
 * 废弃
 * 2022/4/15
 */
public class SmsPduBean {
    public int lendth;
    public String content;

    public SmsPduBean(int lendth,String content){
        this.lendth = lendth;
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
