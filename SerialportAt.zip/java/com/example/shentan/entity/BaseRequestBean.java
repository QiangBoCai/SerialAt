package com.example.shentan.entity;

/**
 * 通用请求头数据
 * @devCode  设备编号
 * @infoCode   消息编码
 * @channelCode  通道码
 * @packId  数据包编号
 * @sign  签名
 * @sysTime  时间戳
 *
 * 2022/4/15
 */
public class BaseRequestBean {
    public String devCode = "";
    public String infoCode = "";
    public String channelCode = "";
    public String packId = "";
    public String sign = "";
    public String sysTime = "";
    public String actionTime = "";
    public String networkState = "";

    public void setActionTime(String actionTime) {
        this.actionTime = actionTime;
    }


    public void setNetworkState(String networkState) {
        this.networkState = networkState;
    }

    public String getActionTime() {
        return actionTime;
    }


    public String getNetworkState() {
        return networkState;
    }

    public String getDevCode() {
        return devCode;
    }

    public void setDevCode(String devCode) {
        this.devCode = devCode;
    }

    public void setInfoCode(String infoCode) {
        this.infoCode = infoCode;
    }

    public String getPackId() {
        return packId;
    }

    public void setPackId(String packId) {
        this.packId = packId;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public void setSysTime(String sysTime) {
        this.sysTime = sysTime;
    }

}
