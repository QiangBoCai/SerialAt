package com.example.shentan.entity;

/**
 * 通用应答头
 * @code 200：成功 201：失败。
 * @msg  提示消息
 * @packId  数据包标识
 * @infoCode  请求编号
 * @devCode  4G模块的IMEI
 * 2022/4/15
 */
public class BaseReturnBean {
    public String code = "";
    public String msg = "";
    public String packId = "";
    public String infoCode = "";
    public String devCode = "";

    public void setDevCode(String devCode) {
        this.devCode = devCode;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setPackId(String packId) {
        this.packId = packId;
    }

    public void setInfoCode(String infoCode) {
        this.infoCode = infoCode;
    }

}


