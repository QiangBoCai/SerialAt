package com.example.shentan.entity;

/**
 * IccId数据类
 * @commandResult  执行结果
 * @resultMsg  执行结果的解释信息（通常用于解释失败原因）
 * @operator   1 移动  2 电信  3 联通
 * @machinePhone  IccId（不是本机号码）
 * 2022/4/15
 */
public class IccIdBean extends BaseRequestBean{
    private String commandResult = "";
    private String resultMsg = "";
    private String operator = "";
    private String machinePhone = "";

    public void setCommandResult(String commandResult) {
        this.commandResult = commandResult;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getOperator() {
        return operator;
    }

    public void setMachinePhone(String machinePhone) {
        this.machinePhone = machinePhone;
    }

}
