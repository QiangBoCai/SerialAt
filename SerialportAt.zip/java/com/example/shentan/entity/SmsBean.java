package com.example.shentan.entity;

/**
 * 短信业务数据类
 * @controlNo  控制号
 * @command  命令
 * @msg  短信内容
 * @reSendCount  重发次数（暂未用到）
 * @targetPhone  目标号码
 * @centerPhone  短息中心号码
 * @commandResult  执行结果
 * @resultMsg  执行结果的解释信息（通常用于解释失败原因）
 * @moduleFormat   2：2G; 3: 3G; 4 : 4G 5 : 5G
 * @operator  1 移动  2 电信  3 联通
 * @imageName  彩信图片名称
 * @imageUrl  彩信图片地址（暂未用到）
 * @machinePhone  IccId（不是本机号码）
 * @tac  大区
 * @eci  小区
 * 2022/4/15
 */
public class SmsBean extends BaseRequestBean{

    public String controlNo = "";
    public String command = "";
    public String msg = "";
    public String reSendCount = "";
    public String targetPhone = "";
    public String centerPhone = "";
    public String resultMsg = "";
    public String commandResult = "";
    public String moduleFormat = "";
    public String operator = "";
    public String imageName = "";
    public String imageUrl = "";
    public String machinePhone = "";
    public String tac = "";
    public String eci = "";

    public void setMachinePhone(String machinePhone) {
        this.machinePhone = machinePhone;
    }

    public void setTac(String tac) {
        this.tac = tac;
    }

    public void setEci(String eci) {
        this.eci = eci;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageName() {
        return imageName;
    }

    public String getModuleFormat() {
        return moduleFormat;
    }

    public String getOperator() {
        return operator;
    }

    public void setCommandResult(String commandResult) {
        this.commandResult = commandResult;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getCommand() {
        return command;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getTargetPhone() {
        return targetPhone;
    }

}
