package com.example.shentan;

import android.app.Application;
import android.content.Context;
import com.example.shentan.util.Constant;
import java.io.File;
import java.io.IOException;
import java.security.InvalidParameterException;


public class MyApplication extends Application {

    public SerialPort getSerialPortWeb() throws SecurityException, IOException, InvalidParameterException {

        return new SerialPort(new File(Constant.PORT_4G), 115200, 0);
    }

    public static Context appContext;
    @Override
    public void onCreate() {
        super.onCreate();
        appContext = this;
    }


}
