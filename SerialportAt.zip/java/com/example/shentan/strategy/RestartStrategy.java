package com.example.shentan.strategy;

import android.text.TextUtils;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.entity.RestartBean;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.singleton.DeviceStateSingleton;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.FindJsonUtil;
import com.example.shentan.util.Utils;
import com.example.shentan.util.WriteLogUtil;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

public class RestartStrategy extends BusinessStrategy {
    private final SerialPortActivity serialPortActivity;
    private RestartBean restartResultBean;

    public RestartStrategy(SerialPortActivity serialPortActivity){
        restartResultBean = new RestartBean();
        this.serialPortActivity = serialPortActivity;

    }
    @Override
    public void dealBusiness(String receiveWebData) {

        WriteLogUtil.d("接收到指令:","重启指令");
        Constant.infoCode_business = Constant.NO_RESTART;
        DeviceStateSingleton.INSTANCE.setDeviceState(true);
        restartResultBean = FindJsonUtil.parseJsonData(receiveWebData,RestartBean.class);

        //给后台回复收到消息
        if (TextUtils.isEmpty(restartResultBean.getPackId())){
            serialPortActivity.sendCommonReturnToWebFail(Constant.NO_RESTART,restartResultBean.getPackId(),"packId为空");
        }else {
            serialPortActivity.sendCommonReturnToWebSuccess(Constant.NO_RESTART,restartResultBean.getPackId());
        }
        if (serialPortActivity.iservice != null) {

            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                @Override
                public void run() {
                    try {

                        FutureTask<Boolean> futureTask = serialPortActivity.futureTaskUtils.airPlaneModeFutureTask();

                        CachedThreadPoolSingleton.getInstance().execute(futureTask);

                        boolean airPlaneClose = futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);

                        if (airPlaneClose){

                            FutureTask<Boolean> airPlaneOpenTask = serialPortActivity.futureTaskUtils.airPlaneModeFutureTask();

                            CachedThreadPoolSingleton.getInstance().execute(airPlaneOpenTask);

                            boolean airPlaneOpen = airPlaneOpenTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);

                            if (airPlaneOpen){
                                returnRestartResult(Constant.CODE_1);
                            }else {
                                //关闭飞行模式失败
                                returnRestartResult(Constant.CODE_2,"关闭飞行模式失败");
                            }
                        }else {
                            //打开飞行模式失败
                            returnRestartResult(Constant.CODE_2,"打开飞行模式失败");
                        }

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });


        } else {
            returnRestartResult(Constant.CODE_2,Constant.SERVICE_NULL);
            serialPortActivity.bindODMSZServer();
        }
    }


    public void returnRestartResult(String commandResult, String...resultMsg){

        restartResultBean.setInfoCode(Constant.NO_RESTART_RESULT);
        restartResultBean.setPackId(Utils.getUUID());
        restartResultBean.setCommandResult(commandResult);
        if (resultMsg.length>0){
            restartResultBean.setResultMsg(resultMsg[0]);
        }else {
            restartResultBean.setResultMsg("");
        }
        restartResultBean.setSysTime(Utils.getTimeMillis());
        serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(restartResultBean),true,true);
    }

}
