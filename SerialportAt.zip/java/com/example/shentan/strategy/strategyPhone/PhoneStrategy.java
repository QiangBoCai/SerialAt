package com.example.shentan.strategy.strategyPhone;

import android.text.TextUtils;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.broadcast.TestControlReceiver;
import com.example.shentan.entity.CellInfoBean;
import com.example.shentan.entity.PhoneBean;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.singleton.DeviceStateSingleton;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.FindJsonUtil;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;

import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;
/**
 * 电话策略
 * 2022/4/15
 */
public class PhoneStrategy extends BusinessStrategy{

    public SerialPortActivity serialPortActivity;
    public PhoneBean phoneBean;
    private int playResult;
    private final StringBuilder iccIdSB;
    public StringBuilder conditionsPhone;
    private final StringBuilder forwardNumberSB;
    public PhoneStrategy(SerialPortActivity serialPortActivity){
        this.serialPortActivity = serialPortActivity;
        phoneBean = new PhoneBean();
        iccIdSB = new StringBuilder();
        conditionsPhone = new StringBuilder();
        forwardNumberSB = new StringBuilder();

    }
    @Override
    public void dealBusiness(String receiveWebData) {

        LogUtil.dd("__PhoneStrategy-1",receiveWebData);
        Constant.infoCode_business = Constant.NO_PHONE;
        DeviceStateSingleton.INSTANCE.setDeviceState(true);

        phoneBean = FindJsonUtil.parseJsonData(receiveWebData, PhoneBean.class);

        //给后台回复收到消息
        if (TextUtils.isEmpty(phoneBean.getPackId())){
            serialPortActivity.sendCommonReturnToWebFail(Constant.NO_PHONE,phoneBean.getPackId(),"packId为空");
        }else {
            serialPortActivity.sendCommonReturnToWebSuccess(Constant.NO_PHONE,phoneBean.getPackId());
        }

        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {

                    if (!TextUtils.isEmpty(phoneBean.getOperator())){
                        if (Constant.OPERATOR_FLAG == Integer.parseInt(phoneBean.getOperator())){
                            getPhoneCommand();
                        }else {
                            serialPortActivity.setOperator(phoneBean.getOperator());
                        }
                    } else {
                        getPhoneCommand();

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    @Override
    public void recheckSimSuccess(){
        getPhoneCommand();
    }

    public void getPhoneCommand() {

        if (TextUtils.isEmpty(phoneBean.getCommand())){
            String actionTime = Utils.getTimeMillis();
            returnPhoneResult(Constant.CODE_2,actionTime,"command为空",actionTime);
            return;
        }
        LogUtil.print("phoneBean.getCommand()="+phoneBean.getCommand());
        if (Constant.CODE_9.equals(phoneBean.getCommand())) {
            // 无需应答
            LogUtil.print("Constant.CODE_9 无需应答");
            Constant.PHONE_DISRESPONSE_NUMBER = phoneBean.getTargetPhone();
        } else {
            serialPortActivity.strategyFactory.getStrategy(Constant.TotalStrategyMapEnum.MAP_TYPE_PHONE,phoneBean.getCommand()).dealBusiness();
        }
    }




    public void returnPhoneResult(String commandResult, String actionTime, String... resultMsg){
        LogUtil.print("returnPhoneResult  actionTime="+actionTime );
        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {

                    setCellInfo(serialPortActivity.getCellInfo());
                    sleep(500);

                    FutureTask<String> futureTask = serialPortActivity.futureTaskUtils.iccidFutureTask();
                    CachedThreadPoolSingleton.getInstance().execute(futureTask);
                    Utils.replaceSB(iccIdSB,futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS));
                    if (!TextUtils.isEmpty(iccIdSB.toString())){
                        phoneBean.setMachinePhone(iccIdSB.substring(0, iccIdSB.length()-1));
                    }else {
                        phoneBean.setMachinePhone("");
                    }


                    phoneBean.setInfoCode(Constant.NO_PHONE_RESULT);
                    phoneBean.setPackId(Utils.getUUID());
                    phoneBean.setCommandResult(commandResult);
                    if (resultMsg.length>0){
                        StringBuilder temp = new StringBuilder();
                        for(int i=0;i<resultMsg.length;i++){
                            temp.append(resultMsg[i]);
                        }
                        phoneBean.setResultMsg(temp.toString());
                    }else{
                        phoneBean.setResultMsg("");
                    }
                    phoneBean.setNetworkState(""+serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN));
                    phoneBean.setSysTime(Utils.getTimeMillis());
                    phoneBean.setActionTime(actionTime);
                    if("2".equals(phoneBean.getCommand())&& "1".equals(phoneBean.commandResult)
                     && PhoneStrategyAcceptCall.lastActionTime != actionTime){
                        LogUtil.print("去除重复的接听消息");
                        return;
                    }
                    serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(phoneBean),true,true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }


    public void setCellInfo(CellInfoBean cellInfoBean) {
        if (cellInfoBean != null){
            phoneBean.setTac(TextUtils.isEmpty(cellInfoBean.getTac()) ? "" : cellInfoBean.getTac());
            phoneBean.setEci(TextUtils.isEmpty(cellInfoBean.getEci()) ? "" : cellInfoBean.getEci());

        }

    }

    //调用此方法的地方都有开线程，所以此方法内不需要开线程
    public boolean inactiveWait() {
        boolean isSuccess = false;
        try {

            FutureTask<Integer> futureTask = serialPortActivity.futureTaskUtils.getCallWaitingStatusFutureTask();
            CachedThreadPoolSingleton.getInstance().execute(futureTask);
            if (futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS) == 1){

                try {
                    FutureTask<Boolean> futureTask1 = serialPortActivity.futureTaskUtils.setCallWaitingStatusFutureTask();
                    CachedThreadPoolSingleton.getInstance().execute(futureTask1);
                    isSuccess = futureTask1.get(Constant.TIMER_OUT, TimeUnit.SECONDS);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return isSuccess;

    }

    public void operateTransfer(int type,String...phone) {

        //todo
        // 直接返回，
        // 联通运营商呼叫转移设置有问题，有待讨论解决方案
        // 电信运营商呼叫转移设置是否有问题待测
        if (Constant.OPERATOR_FLAG == Constant.OPERATOR_FLAG_LT || Constant.OPERATOR_FLAG == Constant.OPERATOR_FLAG_DX ){
            Constant.TRANSFER_FLAG_RESULT = true;
            return ;
        }

        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {

                    if (phone.length > 0){
                        Utils.replaceSB(forwardNumberSB,phone[0]);

                    }


                    switch (type){
                        //取消所有前转
                        case Constant.FLAG_TRANSFER_CANCEL_ALL: {
                            Utils.replaceSB(forwardNumberSB,Constant.TRANSFER_CANCEL_ALL);//取消所有呼叫转移
                            break;
                        }
                        //启用无条件前转
                        case Constant.FLAG_TRANSFER_ALL_ACTIVITY: {

                            //启动无条件转移
                            Utils.replaceSB(forwardNumberSB,"**21*"+ forwardNumberSB +"#");
                            break;
                        }
                        //启用无应答前转
                        case Constant.FLAG_TRANSFER_NO_RESPONSE_ACTIVITY: {
                            //启动无应答呼叫转移
                            Utils.replaceSB(forwardNumberSB,"**61*"+ forwardNumberSB +"#");
                            break;
                        }
                        //启用遇忙前转
                        case Constant.FLAG_TRANSFER_BUSY_ACTIVITY: {
                            //启动遇忙呼叫转移
                            Utils.replaceSB(forwardNumberSB,"**67*"+ forwardNumberSB +"#");
                            break;
                        }
                        //启用无法接通时前转
                        case Constant.FLAG_TRANSFER_INACCESSABLE_ACTIVITY : {
                            Utils.replaceSB(forwardNumberSB,"**62*"+ forwardNumberSB +"#");
                            break;
                        }
                    }


                    Constant.TRANSFER_FLAG = forwardNumberSB.toString();
                    serialPortActivity.iservice.sendUssdRequest(Constant.ODMSZ_TOKEN, forwardNumberSB.toString());
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }


    public void soundPlay() {
        LogUtil.print("enter into soundPlay");
        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {

                    Thread.sleep(1000);

                    if (serialPortActivity.iservice != null){
                        try {
                            LogUtil.print("enter into iservice.playSound");
                            playResult = serialPortActivity.iservice.playSound(Constant.ODMSZ_TOKEN, Constant.DIAL_AUDIO_PATH_2);
                            LogUtil.print("enter into iservice.playSound playResult="+playResult);
                            if(playResult==-1||playResult==1){ //播放失败
                                if (serialPortActivity.iservice.getCallState(Constant.ODMSZ_TOKEN) != TestControlReceiver.CALL_STATE_IDLE){
                                    Thread.sleep(5000);
                                    LogUtil.print("enter into soundPlay2");
                                    soundPlay();
                                }
                            }else if (playResult == 0 ){ //播放结束

                                int callState = serialPortActivity.iservice.getCallState(Constant.ODMSZ_TOKEN);
                                if (callState != TestControlReceiver.CALL_STATE_IDLE){
                                    LogUtil.print("enter into soundPlay2");
                                    Thread.sleep(5000);
                                    soundPlay();
                                }

                            }else if (playResult == -2){ //未通话时执行了playSound API
                                LogUtil.print("未通话时执行了playSound API");
                            }

                        } catch (Exception e) {

                            e.printStackTrace();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

    }

    public void setTargetPhone(String targetPhone){
        phoneBean.setTargetPhone(targetPhone);
        if (phoneBean.getCommand().equalsIgnoreCase(Constant.CODE_2)){
            // 回复接听成功
            returnPhoneResult(Constant.CODE_1,Utils.getTimeMillis());
        }


    }

}
