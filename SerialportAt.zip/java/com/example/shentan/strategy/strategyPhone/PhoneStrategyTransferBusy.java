package com.example.shentan.strategy.strategyPhone;

import static java.lang.Thread.sleep;

import android.text.TextUtils;

import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.strategy.McuStrategy;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;

/**
 * 遇忙前转，先删除所有前转再设置
 */
public class PhoneStrategyTransferBusy extends BusinessStrategy {
    private final PhoneStrategy phoneStrategy;

    public PhoneStrategyTransferBusy(BusinessStrategy businessStrategy){
        this.phoneStrategy = (PhoneStrategy) businessStrategy;

    }

    @Override
    public void dealBusiness() {
        super.dealBusiness();
        transferBusyMethod();
    }
    private void transferBusyMethod() {
        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    //如果检测打开了飞行模式，要关闭飞行模式
                    boolean airPlaneModeStatus = phoneStrategy.serialPortActivity.iservice.getAirPlaneModeStatus(Constant.ODMSZ_TOKEN);
                    if(airPlaneModeStatus){
                        LogUtil.print("airPlaneModeStatus="+airPlaneModeStatus);
                        phoneStrategy.serialPortActivity.iservice.setAirPlaneMode(Constant.ODMSZ_TOKEN,false);
                    }
                    // 执行时间
                    String actionTime = Utils.getTimeMillis();
                    LogUtil.print("enter into transferBusyMethod actionTime:"+actionTime);
                    // 检查netWork
                    int netWorkState = phoneStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                    for(int i=0;i<18;i++){//检测3分钟
                        if(netWorkState>0){
                            break;
                        }else{
                            Thread.sleep(10000);
                            netWorkState = phoneStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                        }
                    }
                    LogUtil.print("netWorkState:"+netWorkState);
                    //若无网络，重启一次modem
                    if(netWorkState<1){
                        boolean resetModem = phoneStrategy.serialPortActivity.resetModem();
                        LogUtil.print("resetModem="+resetModem);
                        Thread.sleep(20000);
                        netWorkState = phoneStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                        LogUtil.print("netWorkState:"+netWorkState);
                    }

                    //如果是NR only ，且注册到NSA上，主动开飞行模式掉网
                    if(netWorkState>0 && netWorkState != 5){
                        int networkMode = Constant.formatTotal.get(phoneStrategy.phoneBean.getPhoneFormat()).get(Constant.OPERATOR_FLAG);
                        LogUtil.print("NR only networkMode:"+networkMode);
                        if(networkMode==23){
                            //打开飞行模式
                            phoneStrategy.serialPortActivity.iservice.setAirPlaneMode(Constant.ODMSZ_TOKEN,true);
                            Thread.sleep(3000);
                            phoneStrategy.returnPhoneResult(Constant.CODE_2, actionTime, Constant.NO_SERVICE);
                            return;
                        }
                    }
                    if(netWorkState == -1){
                        phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.NO_SIM);
                        return;
                    }else if (netWorkState == 0){
                        phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.NO_SERVICE);
                        return;
                    }


                    if (phoneStrategy.serialPortActivity.iservice != null) {
                        try {

                            //禁用呼叫等待
                            if (!phoneStrategy.inactiveWait()){
                                phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.INACTIVE_WAITING_FAIL);

                                return;
                            }

                            phoneStrategy.operateTransfer(Constant.FLAG_TRANSFER_CANCEL_ALL);
                            //延时是为了给取消前转留出时间
                            sleep(10000);

                            if (!Constant.TRANSFER_FLAG_RESULT){
                                phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.INACTIVE_ALL_TRANSFER_FAIL);
                                return;
                            }

                            //重置
                            Constant.TRANSFER_FLAG_RESULT = false;

                            if (TextUtils.isEmpty(phoneStrategy.phoneBean.getConditionsPhone())){

                                phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.CONDITION_PHONE_NULL);

                                return;
                            }

                            phoneStrategy.operateTransfer(Constant.FLAG_TRANSFER_BUSY_ACTIVITY);
                            //延时是为了给前转生效留出时间
                            sleep(10000);

                            if (!Constant.TRANSFER_FLAG_RESULT){
                                phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.SET_BUSY_TRANSFER_FAIL);
                                return;
                            }

                            //重置
                            Constant.TRANSFER_FLAG_RESULT = false;
                            //设置遇忙前转
                            phoneStrategy.returnPhoneResult(Constant.CODE_1,actionTime);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }else {

                        phoneStrategy.serialPortActivity.bindODMSZServer();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

}
