package com.example.shentan.strategy.strategyPhone;

import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.strategy.McuStrategy;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;
import com.odmsz.control.RILConstants;

import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

/**
 * 拨号
 */
public class PhoneStrategyDial extends BusinessStrategy {
    private final PhoneStrategy phoneStrategy;

    public PhoneStrategyDial(BusinessStrategy businessStrategy){
        this.phoneStrategy = (PhoneStrategy) businessStrategy;

    }
    @Override
    public void dealBusiness() {
        super.dealBusiness();
        LogUtil.print("dialMethod");
        dialMethod();
    }
    private void dialMethod() {
        if (phoneStrategy.serialPortActivity.iservice != null) {
            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        //如果检测打开了飞行模式，要关闭飞行模式
                        boolean airPlaneModeStatus = phoneStrategy.serialPortActivity.iservice.getAirPlaneModeStatus(Constant.ODMSZ_TOKEN);
                        if(airPlaneModeStatus){
                            LogUtil.print("airPlaneModeStatus="+airPlaneModeStatus);
                            phoneStrategy.serialPortActivity.iservice.setAirPlaneMode(Constant.ODMSZ_TOKEN,false);
                        }
                        // 执行时间
                        String actionTime = Utils.getTimeMillis();
                        LogUtil.print("enter into dialMethod actionTime:"+actionTime);
                        // 根据后台数据设置制式
                        boolean setNetSuccess= phoneStrategy.serialPortActivity.isSetNetSuccess(phoneStrategy.phoneBean.getPhoneFormat());
                        if (!setNetSuccess){
                            phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.SET_NET_FAIL);
                            return;
                        }
                        // 检查netWork
                        int netWorkState = phoneStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                        for(int i=0;i<18;i++){//检测3分钟
                            if(netWorkState>0){
                                break;
                            }else{
                                Thread.sleep(10000);
                                netWorkState = phoneStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                            }
                        }
                        LogUtil.print("netWorkState:"+netWorkState);
                        //若无网络，重启一次modem
                        if(netWorkState<1){
                            boolean resetModem = phoneStrategy.serialPortActivity.resetModem();
                            LogUtil.print("resetModem="+resetModem);
                            Thread.sleep(20000);
                            netWorkState = phoneStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                            LogUtil.print("netWorkState:"+netWorkState);
                        }
                        //如果是NR only ，且注册到NSA上，主动开飞行模式掉网
                        if(netWorkState>0 && netWorkState != 5){
                            int networkMode = Constant.formatTotal.get(phoneStrategy.phoneBean.getPhoneFormat()).get(Constant.OPERATOR_FLAG);
                            LogUtil.print("NR only networkMode:"+networkMode);
                            if(networkMode==23){
                                //打开飞行模式
                                phoneStrategy.serialPortActivity.iservice.setAirPlaneMode(Constant.ODMSZ_TOKEN,true);
                                Thread.sleep(3000);
                                phoneStrategy.returnPhoneResult(Constant.CODE_2, actionTime, Constant.NO_SERVICE);
                                return;
                            }
                        }

                        if(netWorkState == -1){
                            phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.NO_SIM);
                            return;
                        }else if (netWorkState == 0) {
                            phoneStrategy.returnPhoneResult(Constant.CODE_2, actionTime, Constant.NO_SERVICE);
                            return;
                        }
                        if (TextUtils.isEmpty(phoneStrategy.phoneBean.getTargetPhone())){
                            // 回复失败

                            phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.TARGET_PHONE_NULL);

                            return;
                        }
                        for(int i=0;i<3;i++){//若失败，重复3次
                            FutureTask<Boolean> futureTask = phoneStrategy.serialPortActivity.futureTaskUtils.callFutureTask(phoneStrategy.phoneBean.getTargetPhone());
                            CachedThreadPoolSingleton.getInstance().execute(futureTask);

                            if (futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS)){
                                //isInCall
                                Thread.sleep(1500);
                                int callState = phoneStrategy.serialPortActivity.iservice.getCallState(Constant.ODMSZ_TOKEN);
                                LogUtil.print("callState:"+callState);
                                if(callState != TelephonyManager.CALL_STATE_IDLE){
                                    // 回复拨号成功
                                    phoneStrategy.returnPhoneResult(Constant.CODE_1,actionTime);
                                    break;
                                }else{
                                    // 回复拨号失败
                                    phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.DIAL_AND_END);
                                    if(i==2){
                                        boolean restartModemResult = phoneStrategy.serialPortActivity.resetModem();
                                        LogUtil.print("restartModemResult="+restartModemResult);
                                        if(restartModemResult){
                                            Thread.sleep(20000);
                                            futureTask = phoneStrategy.serialPortActivity.futureTaskUtils.callFutureTask(phoneStrategy.phoneBean.getTargetPhone());
                                            CachedThreadPoolSingleton.getInstance().execute(futureTask);

                                            if (futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS)){
                                                //isInCall
                                                Thread.sleep(1500);
                                                callState = phoneStrategy.serialPortActivity.iservice.getCallState(Constant.ODMSZ_TOKEN);
                                                LogUtil.print("after resetModem dial callState:"+callState);
                                                if(callState != TelephonyManager.CALL_STATE_IDLE){
                                                    // 回复拨号成功
                                                    phoneStrategy.returnPhoneResult(Constant.CODE_1,actionTime);
                                                    break;
                                                }else{
                                                    // 回复拨号失败
                                                    phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.DIAL_AND_END);
                                                }
                                            }
                                        }
                                    }
                                }
                            }else {
                                // 回复拨号失败
                                phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.DIAL_FAIL);
                            }
                            //睡眠10s
                            Thread.sleep(10000);
                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        } else {

            phoneStrategy.serialPortActivity.bindODMSZServer();
        }
    }
}
