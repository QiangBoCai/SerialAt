package com.example.shentan.strategy.strategyPhone;

import static java.lang.Thread.sleep;

import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.strategy.McuStrategy;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;

import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

/**
 * 拒接
 * 分两种情况，没通话的情况下挂断和通话的情况下挂断，没通话时直接挂断，有通话时则需要判断talkTime
 */
public class PhoneStrategyEndCall extends BusinessStrategy {
    private final PhoneStrategy phoneStrategy;
    private int talkTime;
    private long currentTime;

    public PhoneStrategyEndCall(BusinessStrategy businessStrategy){
        this.phoneStrategy = (PhoneStrategy) businessStrategy;

    }

    @Override
    public void dealBusiness() {
        super.dealBusiness();
        endCallMethod();
    }
    private void endCallMethod() {
        LogUtil.print("endCallMethod Constant.SOUND_PLAY="+Constant.SOUND_PLAY);
        if (Constant.SOUND_PLAY) {
            Constant.SOUND_PLAY = false;
            soundStop();
        }
        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    if (phoneStrategy.serialPortActivity.iservice != null) {

                            //通过判断是否有接通来判断是否需要立即挂断，没有接通来电直接挂断，后续工作交给dialBreak()
                            if (Constant.DIAL_ACCEPT != 0) {//需要判断talkTime的挂断
                                //没收到响铃广播，有错误了，直接挂断
                                if (Constant.DIAL_RING == 0) {
                                    LogUtil.print("has no ring ,enter into dialBreak");
                                    dialBreak();
                                    return;
                                }

                                talkTime = Integer.parseInt(phoneStrategy.phoneBean.getTalkTime());
                                //判断通话是否已经超时
                                currentTime = (System.currentTimeMillis() - Constant.DIAL_RING) / 1000;

                                //当前通话时间小于指定通话时间，则等待达到指定通话时间再挂断，否则直接挂断
                                if (currentTime < talkTime) {
                                    sleep((talkTime - currentTime) * 1000);
                                }


                            }
                            dialBreak();
                    }else {

                        phoneStrategy.serialPortActivity.bindODMSZServer();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void dialBreak()  {
        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    //如果检测打开了飞行模式，要关闭飞行模式
                    boolean airPlaneModeStatus = phoneStrategy.serialPortActivity.iservice.getAirPlaneModeStatus(Constant.ODMSZ_TOKEN);
                    if(airPlaneModeStatus){
                        LogUtil.print("airPlaneModeStatus="+airPlaneModeStatus);
                        phoneStrategy.serialPortActivity.iservice.setAirPlaneMode(Constant.ODMSZ_TOKEN,false);
                    }
                    boolean isSuccess = false;
                    // 执行时间
                    String actionTime = Utils.getTimeMillis();
                    LogUtil.print("enter into dialBreak actionTime:"+actionTime);
                    // 检查netWork
                    int netWorkState = phoneStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                    for(int i=0;i<18;i++){//检测3分钟
                        if(netWorkState>0){
                            break;
                        }else{
                            Thread.sleep(10000);
                            netWorkState = phoneStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                        }
                    }
                    LogUtil.print("netWorkState:"+netWorkState);
                    //若无网络，重启一次modem
                    if(netWorkState<1){
                        boolean resetModem = phoneStrategy.serialPortActivity.resetModem();
                        LogUtil.print("resetModem="+resetModem);
                        Thread.sleep(20000);
                        netWorkState = phoneStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                        LogUtil.print("netWorkState:"+netWorkState);
                    }

                    //如果是NR only ，且注册到NSA上，主动开飞行模式掉网
                    if(netWorkState>0 && netWorkState != 5){
                        int networkMode = Constant.formatTotal.get(phoneStrategy.phoneBean.getPhoneFormat()).get(Constant.OPERATOR_FLAG);
                        LogUtil.print("NR only networkMode:"+networkMode);
                        if(networkMode==23){
                            //打开飞行模式
                            phoneStrategy.serialPortActivity.iservice.setAirPlaneMode(Constant.ODMSZ_TOKEN,true);
                            Thread.sleep(3000);
                            phoneStrategy.returnPhoneResult(Constant.CODE_2, actionTime, Constant.NO_SERVICE);
                            return;
                        }
                    }

                    if(netWorkState == -1){
                        phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.NO_SIM);
                        return;
                    }else if (netWorkState == 0){
                        phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.NO_SERVICE);
                        return;
                    }

                    FutureTask<Boolean> futureTask = phoneStrategy.serialPortActivity.futureTaskUtils.endCallFutureTask();
                    CachedThreadPoolSingleton.getInstance().execute(futureTask);
                    isSuccess = futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);


                    if (isSuccess){
                        //给挂断广播留出时间
                        sleep(2000);
                        // 回复成功
                        LogUtil.print("Constant.DIAL_BREAK="+Constant.DIAL_BREAK +" Constant.DIAL_RING="+Constant.DIAL_RING);
                        if (Constant.DIAL_BREAK != 0){
                            if (Constant.DIAL_RING != 0 && Constant.DIAL_RING < Constant.DIAL_BREAK){
                                phoneStrategy.phoneBean.setTalkTime(String.valueOf(((Constant.DIAL_BREAK - Constant.DIAL_RING) / 1000)));
                            }else {
                                phoneStrategy.phoneBean.setTalkTime(Constant.CODE_1_NEGATIVE);
                            }
                            phoneStrategy.returnPhoneResult(Constant.CODE_1,actionTime);
                            Constant.DIAL_BREAK = 0;


                        }else {

                            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        //如果挂断失败，再重试挂断一次
                                        boolean endCallRet = phoneStrategy.serialPortActivity.iservice.endCall(Constant.ODMSZ_TOKEN);

                                        sleep(5000);
                                        if(endCallRet){
                                        //if (Constant.DIAL_BREAK != 0){
                                            if (Constant.DIAL_RING != 0 && Constant.DIAL_RING < Constant.DIAL_BREAK){
                                                phoneStrategy.phoneBean.setTalkTime(String.valueOf((Constant.DIAL_BREAK - Constant.DIAL_RING) / 1000));
                                            }else {
                                                phoneStrategy.phoneBean.setTalkTime(Constant.CODE_1_NEGATIVE);
                                            }
                                            phoneStrategy.returnPhoneResult(Constant.CODE_1,actionTime);
                                            Constant.DIAL_BREAK = 0;
                                        }else {
                                            phoneStrategy.phoneBean.setTalkTime(Constant.CODE_1_NEGATIVE);
                                            phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.BREAK_FAIL);
                                        }
                                    }catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                            });

                        }

                    }else {
                        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    //再尝试一下挂断
                                    phoneStrategy.serialPortActivity.iservice.endCall(Constant.ODMSZ_TOKEN);

                                    sleep(5000);
                                    if (Constant.DIAL_BREAK != 0){
                                        long dialTime = (Constant.DIAL_BREAK - Constant.DIAL_RING) / 1000;
                                        phoneStrategy.phoneBean.setTalkTime(String.valueOf(dialTime));
                                        phoneStrategy.returnPhoneResult(Constant.CODE_1,actionTime);

                                    }else {
                                        // 回复失败
                                        phoneStrategy.phoneBean.setTalkTime(Constant.CODE_1_NEGATIVE);
                                        phoneStrategy.returnPhoneResult(Constant.CODE_2,actionTime,Constant.BREAK_FAIL);
                                    }
                                }catch (Exception e){
                                    e.printStackTrace();
                                }
                            }
                        });



                    }
                }catch (Exception e){
                    e.printStackTrace();
                    phoneStrategy.phoneBean.setTalkTime(Constant.CODE_1_NEGATIVE);
                    phoneStrategy.returnPhoneResult(Constant.CODE_2,Utils.getTimeMillis(),e.getMessage());
                }finally {
                    Constant.DIAL_ACCEPT = 0;
                    Constant.DIAL_RING = 0;
                    Constant.DIAL_BREAK = 0;
                }
            }
        });

    }


    public void soundStop(){

        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {
                   int result= phoneStrategy.serialPortActivity.iservice.stopSound(Constant.ODMSZ_TOKEN);
                   LogUtil.print("stopSound result="+result);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

    }
}
