package com.example.shentan.strategy;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.RemoteException;
import android.text.TextUtils;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.entity.BrowserBean;
import com.example.shentan.entity.CellInfoBean;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.singleton.DeviceStateSingleton;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.FindJsonUtil;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.NetUtil;
import com.example.shentan.util.Utils;
import com.example.shentan.util.WriteLogUtil;

import static java.lang.Thread.sleep;

import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

/**
 * 网页策略
 * 2022/4/15
 */
public class BrowserStrategy extends BusinessStrategy {
    private final SerialPortActivity serialPortActivity;
    public static BrowserBean browserBean;
    private final StringBuilder iccIdSB;

    public BrowserStrategy(SerialPortActivity serialPortActivity){
        this.serialPortActivity = serialPortActivity;
        browserBean = new BrowserBean();
        iccIdSB = new StringBuilder();

    }
    @Override
    public void dealBusiness(String receiveWebData) {
        WriteLogUtil.d("接收到指令:","网页指令");

        Constant.infoCode_business = Constant.NO_BROWSER;
        DeviceStateSingleton.INSTANCE.setDeviceState(true);
        browserBean = FindJsonUtil.parseJsonData(receiveWebData, BrowserBean.class);

        //给后台回复收到消息
        if (TextUtils.isEmpty(browserBean.getPackId())){
            serialPortActivity.sendCommonReturnToWebFail(Constant.NO_BROWSER,browserBean.getPackId(),"packId为空");
        }else {
            serialPortActivity.sendCommonReturnToWebSuccess(Constant.NO_BROWSER, browserBean.getPackId());
        }



        if (!TextUtils.isEmpty(browserBean.getOperator())){

            if (Constant.OPERATOR_FLAG == Integer.parseInt(browserBean.getOperator())){

                getBrowserCommand();

            }else {
                serialPortActivity.setOperator(browserBean.getOperator());
            }
        } else {
            getBrowserCommand();
        }
    }

    @Override
    public void recheckSimSuccess(){
        getBrowserCommand();
    }

    public void getBrowserCommand() {
        try{
            // 执行时间
            String actionTime = Utils.getTimeMillis();
            LogUtil.print("enter into getBrowserCommand actionTime:"+actionTime);

            // 检查netWork
            int netWorkState = serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
            for(int i=0;i<18;i++){//检测3分钟
                if(netWorkState>0){
                    break;
                }else{
                    Thread.sleep(10000);
                    netWorkState = serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                }
            }
            LogUtil.print("netWorkState:"+netWorkState);
            //若无网络，重启一次modem
            if(netWorkState<1){
                boolean resetModem = serialPortActivity.resetModem();
                LogUtil.print("resetModem="+resetModem);
                Thread.sleep(20000);
                netWorkState = serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                LogUtil.print("netWorkState:"+netWorkState);
            }
            if(netWorkState == -1){
                returnBrowserResult(Constant.CODE_2,actionTime,Constant.NO_SIM);
                return;
            }else if (netWorkState == 0){
                boolean setNetSuccess = serialPortActivity.isSetNet27();
                if(setNetSuccess){
                    Thread.sleep(5000);
                    netWorkState = serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                    if(netWorkState == 0 ){
                        returnBrowserResult(Constant.CODE_2,actionTime,Constant.NO_SERVICE);
                        return;
                    }
                }
            }
            if (TextUtils.isEmpty(browserBean.getCommand())){
                returnBrowserResult(Constant.CODE_2,actionTime,"command为空");
                return;
            }
            switch (browserBean.getCommand()) {
                case Constant.CODE_1:{
                    CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                //如果检测打开了飞行模式，要关闭飞行模式
                                boolean airPlaneModeStatus = serialPortActivity.iservice.getAirPlaneModeStatus(Constant.ODMSZ_TOKEN);
                                if(airPlaneModeStatus){
                                    LogUtil.print("airPlaneModeStatus="+airPlaneModeStatus);
                                    serialPortActivity.iservice.setAirPlaneMode(Constant.ODMSZ_TOKEN,false);
                                }

                                // 设置制式
                                if (TextUtils.isEmpty(browserBean.getModuleFormat())){
                                    returnBrowserResult(Constant.CODE_2,actionTime,"moduleFormatSB 为空");
                                    return;
                                }
                                boolean setNetSuccess = serialPortActivity.isSetNetSuccess(browserBean.getModuleFormat());

                                if (!setNetSuccess){

                                    returnBrowserResult(Constant.CODE_2,actionTime,Constant.SET_NET_FAIL);
                                    return;
                                }
                                // 检查netWork
                                int netWorkState = serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);

                                while (netWorkState < 1 && McuStrategy.getNetworkStateTimes < 5){
                                    netWorkState = serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                                    McuStrategy.getNetworkStateTimes ++;
                                    Thread.sleep(5000);
                                }
                                //如果是NR only ，且注册到NSA上，主动开飞行模式掉网
                                if(netWorkState>0 && netWorkState != 5){
                                    int networkMode = Constant.formatTotal.get(browserBean.getModuleFormat()).get(Constant.OPERATOR_FLAG);
                                    LogUtil.print("NR only networkMode:"+networkMode);
                                    if(networkMode==23){
                                        //打开飞行模式
                                        serialPortActivity.iservice.setAirPlaneMode(Constant.ODMSZ_TOKEN,true);
                                        Thread.sleep(3000);
                                        returnBrowserResult(Constant.CODE_2, actionTime, Constant.NO_SERVICE);
                                        return;
                                    }
                                }
                                if(netWorkState == -1){
                                    returnBrowserResult(Constant.CODE_2,actionTime,Constant.NO_SIM);
                                    return;
                                }else if (netWorkState == 0){
                                    returnBrowserResult(Constant.CODE_2,actionTime,Constant.NO_SERVICE);
                                    return;
                                }

                                checkNetBrowser(browserBean.getTargetURL());
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    });

                    break;
                }

                default:
                    break;

            }


        }catch (Exception e){
            e.printStackTrace();
        }


    }

    public void returnBrowserResult(String commandResult, String actionTime,String...resultMsg){

        setCellInfo(serialPortActivity.getCellInfo());

        FutureTask<String> futureTask = serialPortActivity.futureTaskUtils.iccidFutureTask();
        CachedThreadPoolSingleton.getInstance().execute(futureTask);

        try {
            Utils.replaceSB(iccIdSB,futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS));
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (!TextUtils.isEmpty(iccIdSB.toString())){
            browserBean.setMachinePhone(iccIdSB.substring(0, iccIdSB.length()-1));
        }else {
            browserBean.setMachinePhone("");
        }

        browserBean.setInfoCode(Constant.NO_BROWSER_RESULT);
        browserBean.setPackId(Utils.getUUID());
        browserBean.setCommandResult(commandResult);

        if (resultMsg.length>0){
            StringBuilder temp = new StringBuilder();
            for(int i=0;i<resultMsg.length;i++){
                temp.append(resultMsg[i]);
            }
            browserBean.setResultMsg(temp.toString());
        }else{
            browserBean.setResultMsg("");
        }
        try {
            browserBean.setNetworkState(""+serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN));
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        browserBean.setSysTime(Utils.getTimeMillis());
        browserBean.setActionTime(actionTime);
        serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(browserBean),true,true);

    }

    public void setCellInfo(CellInfoBean cellInfoBean) {
        if (cellInfoBean != null){
            browserBean.setTac(TextUtils.isEmpty(cellInfoBean.getTac()) ? "" : cellInfoBean.getTac());
            browserBean.setEci(TextUtils.isEmpty(cellInfoBean.getEci()) ? "" : cellInfoBean.getEci());
        }

    }

    private void checkNetBrowser(String url) {
        if (NetUtil.checkNet(serialPortActivity)){
            NetUtil.checkNetTimes = 0;
            Intent intent= new Intent(Intent.ACTION_VIEW, Uri.parse(url));

            if (serialPortActivity.getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) != null) {
                try{
                    serialPortActivity.startActivity(intent);

                    //成功
                    returnBrowserResult(Constant.CODE_1,Utils.getTimeMillis());
                    CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                sleep(30000);
                                Utils.forceStopPackage(serialPortActivity,Constant.WEBVIEW_PACKAGE_NAME);
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    });


                }catch (Exception e){
                    returnBrowserResult(Constant.CODE_2,Utils.getTimeMillis(),e.getMessage());

                }
            }else {
                returnBrowserResult(Constant.CODE_2,Utils.getTimeMillis(),"未安装浏览器");

            }
        }else {

            //没有网络再检查一下
            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        sleep(3000);
                        if (NetUtil.checkNet(serialPortActivity)){
                            checkNetBrowser(url);
                        }else {
                            returnBrowserResult(Constant.CODE_2,Utils.getTimeMillis(),Constant.NO_SERVICE);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            });

        }
    }

}
