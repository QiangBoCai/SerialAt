package com.example.shentan.strategy.strategySms;

import static java.lang.Thread.sleep;

import android.os.Environment;
import android.text.TextUtils;

import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.strategy.McuStrategy;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;

import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

public class SmsStrategyMnsSend extends BusinessStrategy {

    private final StringBuilder smscAddressSB;
    private final SmsStrategy smsStrategy;

    public SmsStrategyMnsSend(BusinessStrategy businessStrategy){
        this.smsStrategy = (SmsStrategy) businessStrategy;
        smscAddressSB = new StringBuilder();

    }
    @Override
    public void dealBusiness() {
        super.dealBusiness();

        sendMms();
    }
    private void sendMms() {
        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // 执行时间
                    String actionTime = Utils.getTimeMillis();
                    LogUtil.print("enter into sendMms actionTime:"+actionTime);
                    //如果检测打开了飞行模式，要关闭飞行模式
                    boolean airPlaneModeStatus = smsStrategy.serialPortActivity.iservice.getAirPlaneModeStatus(Constant.ODMSZ_TOKEN);
                    if(airPlaneModeStatus){
                        LogUtil.print("airPlaneModeStatus="+airPlaneModeStatus);
                        smsStrategy.serialPortActivity.iservice.setAirPlaneMode(Constant.ODMSZ_TOKEN,false);
                    }

                    // 设置制式
                    if (TextUtils.isEmpty(smsStrategy.smsBean.getModuleFormat())){
                        smsStrategy.returnSmsResult(Constant.CODE_2,actionTime,Constant.MODULE_FORMAT_NULL);
                        return;
                    }
                    boolean setNetSuccess = smsStrategy.serialPortActivity.isSetNetSuccess(smsStrategy.smsBean.getModuleFormat());
                    if (!setNetSuccess){
                        smsStrategy.returnSmsResult(Constant.CODE_2,actionTime,Constant.SET_NET_FAIL);
                        return;
                    }


                    // 检查netWork
                    int netWorkState = smsStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                    for(int i=0;i<18;i++){//检测3分钟
                        if(netWorkState>0){
                            break;
                        }else{
                            Thread.sleep(10000);
                            netWorkState = smsStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                        }
                    }
                    LogUtil.print("netWorkState:"+netWorkState);
                    //若无网络，重启一次modem
                    if(netWorkState<1){
                        boolean resetModem = smsStrategy.serialPortActivity.resetModem();
                        LogUtil.print("resetModem="+resetModem);
                        Thread.sleep(20000);
                        netWorkState = smsStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                        LogUtil.print("netWorkState:"+netWorkState);
                    }
                    if(netWorkState == -1){
                        smsStrategy.returnSmsResult(Constant.CODE_2,actionTime,Constant.NO_SIM);
                        return;
                    }else if (netWorkState == 0){
                        smsStrategy.returnSmsResult(Constant.CODE_2,actionTime,Constant.NO_SERVICE);
                        return;
                    }
                    if (smsStrategy.serialPortActivity.iservice != null) {
                        try {


                            FutureTask<String> smscAddressFutureTask = smsStrategy.serialPortActivity.futureTaskUtils.getSmscAddressFutureTask();
                            CachedThreadPoolSingleton.getInstance().execute(smscAddressFutureTask);
                            Utils.replaceSB(smscAddressSB,smscAddressFutureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS));
                            LogUtil.print("短信中心号码:"+smscAddressSB.toString());
                            //获取短信中心号码，获取到则去设置，获取不到则重新尝试一次，第二次再失败则不设置
                            if (TextUtils.isEmpty(smscAddressSB.toString())){

                                FutureTask<String> futureTask2 = smsStrategy.serialPortActivity.futureTaskUtils.getSmscAddressFutureTask();
                                CachedThreadPoolSingleton.getInstance().execute(futureTask2);
                                Utils.replaceSB(smscAddressSB,futureTask2.get(Constant.TIMER_OUT, TimeUnit.SECONDS));
                                LogUtil.print("获取 短信中心号码 futureTask2:"+smscAddressSB.toString());
                                if (!TextUtils.isEmpty(smscAddressSB.toString())){
                                    FutureTask<Boolean> futureTask3 = smsStrategy.serialPortActivity.futureTaskUtils.setSmscAddressFutureTask(smscAddressSB.toString());
                                    LogUtil.print("设置 短信中心号码 futureTask3:"+smscAddressSB.toString());
                                    CachedThreadPoolSingleton.getInstance().execute(futureTask3);
                                    futureTask3.get(Constant.TIMER_OUT, TimeUnit.SECONDS);
                                }
                            }else {

                                FutureTask<Boolean> futureTask4 = smsStrategy.serialPortActivity.futureTaskUtils.setSmscAddressFutureTask(smscAddressSB.toString());
                                LogUtil.print("设置 短信中心号码 futureTask4:"+smscAddressSB.toString());
                                CachedThreadPoolSingleton.getInstance().execute(futureTask4);

                                futureTask4.get(Constant.TIMER_OUT, TimeUnit.SECONDS);


                            }


                            // 彩信内容可为空
                            if (TextUtils.isEmpty(smsStrategy.smsBean.getTargetPhone()) || TextUtils.isEmpty(smsStrategy.smsBean.getImageName())){
                                LogUtil.print("targetPhone或者imageName为空");
                                smsStrategy.returnSmsResult(Constant.CODE_2,actionTime,"targetPhone或者imageName为空");
                                return;
                            }

                            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        String furl = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+Constant.CAIXIN_IMG_FOLD_NAME_SEND +"/"+ smsStrategy.smsBean.getImageName() +".jpg";
                                        LogUtil.print("sendMms furl= "+furl);
                                        smsStrategy.serialPortActivity.iservice.sendMms(Constant.ODMSZ_TOKEN, smsStrategy.smsBean.getTargetPhone(), smsStrategy.smsBean.getMsg(), null, furl, null);


                                        //todo
                                        // 没有在广播接收处主动将发送彩信结果发送，而是使用线程等待
                                        // 主要是考虑到采用主动发送的方式，还要另外开启一个计时器倒计时去推送失败的结果
                                        // 后续可以考虑是否将被动等待改为主动发送通知
                                        // 彩信发送需要一定的时间
                                        sleep(30000);
                                        LogUtil.print("发送彩信标志位 Constant.CAIXIN_SEND="+Constant.CAIXIN_SEND);
                                        if (Constant.CAIXIN_SEND){
                                            Constant.CAIXIN_SEND = false;
                                            smsStrategy.returnSmsResult(Constant.CODE_1,actionTime);

                                        }else {

                                            //重试一次
                                            sleep(30000);
                                            LogUtil.print("重试一次");
                                            if (Constant.CAIXIN_SEND){
                                                Constant.CAIXIN_SEND = false;
                                                smsStrategy.returnSmsResult(Constant.CODE_1,actionTime);
                                            }else {
                                                smsStrategy.returnSmsResult(Constant.CODE_2,actionTime);

                                            }
                                        }
                                    }catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                            });

//                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }else {

                        smsStrategy.returnSmsResult(Constant.CODE_2,actionTime,Constant.SERVICE_NULL);
                        smsStrategy.serialPortActivity.bindODMSZServer();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

}
