package com.example.shentan.strategy.strategySms;

import android.text.TextUtils;

import com.example.shentan.strategy.McuStrategy;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;

public class SmsStrategySmsReceive extends BusinessStrategy {

    private final SmsStrategy smsStrategy;

    public SmsStrategySmsReceive(BusinessStrategy businessStrategy){
        this.smsStrategy = (SmsStrategy) businessStrategy;

    }
    @Override
    public void dealBusiness() {
        super.dealBusiness();
        receiveSms();
    }
    private void receiveSms() {
        try {
            // 执行时间
            String actionTime = Utils.getTimeMillis();
            LogUtil.print("enter into receiveSms actionTime:"+actionTime);
            //如果检测打开了飞行模式，要关闭飞行模式
            boolean airPlaneModeStatus = smsStrategy.serialPortActivity.iservice.getAirPlaneModeStatus(Constant.ODMSZ_TOKEN);
            if(airPlaneModeStatus){
                LogUtil.print("airPlaneModeStatus="+airPlaneModeStatus);
                smsStrategy.serialPortActivity.iservice.setAirPlaneMode(Constant.ODMSZ_TOKEN,false);
            }
            // 检查netWork
            int netWorkState = smsStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
            for(int i=0;i<18;i++){//检测3分钟
                if(netWorkState>0){
                    break;
                }else{
                    Thread.sleep(10000);
                    netWorkState = smsStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                }
            }
            LogUtil.print("netWorkState:"+netWorkState);
            //若无网络，重启一次modem
            if(netWorkState<1){
                boolean resetModem = smsStrategy.serialPortActivity.resetModem();
                LogUtil.print("resetModem="+resetModem);
                Thread.sleep(20000);
                netWorkState = smsStrategy.serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                LogUtil.print("netWorkState:"+netWorkState);
            }
            if(netWorkState == -1){
                smsStrategy.returnSmsResult(Constant.CODE_2,actionTime,Constant.NO_SIM);
                return;
            }else if (netWorkState == 0){
                smsStrategy.returnSmsResult(Constant.CODE_2,actionTime,Constant.NO_SERVICE);
                return;
            }
            if (!TextUtils.isEmpty(Constant.RECEIVE_NEW_SMS)){
                smsStrategy.smsBean.setMsg(Constant.RECEIVE_NEW_SMS);
                smsStrategy.returnSmsResult(Constant.CODE_1,actionTime);
                Constant.RECEIVE_NEW_SMS = "";
            }else {

                smsStrategy.returnSmsResult(Constant.CODE_2,actionTime,Constant.HAVE_NO_NEW_SMS);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
