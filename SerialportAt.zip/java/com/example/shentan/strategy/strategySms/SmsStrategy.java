package com.example.shentan.strategy.strategySms;

import android.text.TextUtils;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.entity.CellInfoBean;
import com.example.shentan.entity.SmsBean;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.singleton.DeviceStateSingleton;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.FindJsonUtil;
import com.example.shentan.util.Utils;
import com.example.shentan.util.WriteLogUtil;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;

public class SmsStrategy extends BusinessStrategy {
    public final SerialPortActivity serialPortActivity;
    public SmsBean smsBean;
    private final StringBuilder iccIdSB;

    public SmsStrategy(SerialPortActivity serialPortActivity){
        smsBean = new SmsBean();
        iccIdSB = new StringBuilder();
        this.serialPortActivity = serialPortActivity;


    }

    @Override
    public void dealBusiness( String receiveWebData) {

        WriteLogUtil.d("接收到指令:","短信指令");
        Constant.infoCode_business = Constant.NO_SMS;
        DeviceStateSingleton.INSTANCE.setDeviceState(true);

        smsBean = FindJsonUtil.parseJsonData(receiveWebData, SmsBean.class);

        //给后台回复收到消息
        if (TextUtils.isEmpty(smsBean.getPackId())){
            serialPortActivity.sendCommonReturnToWebFail(Constant.NO_SMS,smsBean.getPackId(),"packId为空");
        }else {
            serialPortActivity.sendCommonReturnToWebSuccess(Constant.NO_SMS,smsBean.getPackId());
        }

        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {

                    if (!TextUtils.isEmpty(smsBean.getOperator())){
                        Thread.sleep(1000);
                        String operator = smsBean.getOperator();
                        if (Constant.OPERATOR_FLAG == Integer.parseInt(operator)){

                            getSmsCommand();
                        }else {
                            serialPortActivity.setOperator(operator);
                        }
                    } else {
                        getSmsCommand();

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    @Override
    public void recheckSimSuccess(){
        getSmsCommand();
    }
    public void getSmsCommand() {
        if (TextUtils.isEmpty(smsBean.getCommand())){
            returnSmsResult(Constant.CODE_2,"command为空");
            return;
        }
        serialPortActivity.strategyFactory.getStrategy(Constant.TotalStrategyMapEnum.MAP_TYPE_SMS,smsBean.getCommand()).dealBusiness();

    }

    public void returnSmsResult(String commandResult,String actionTime,String...resultMsg){

        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {

                    setCellInfo(serialPortActivity.getCellInfo());

                    sleep(500);

                    FutureTask<String> futureTask4 = serialPortActivity.futureTaskUtils.iccidFutureTask();
                    CachedThreadPoolSingleton.getInstance().execute(futureTask4);
                    Utils.replaceSB(iccIdSB,futureTask4.get(Constant.TIMER_OUT, TimeUnit.SECONDS));

                    if (!TextUtils.isEmpty(iccIdSB.toString())){
                        smsBean.setMachinePhone(iccIdSB.substring(0, iccIdSB.length()-1));
                    }else {
                        smsBean.setMachinePhone("");
                    }

                    smsBean.setInfoCode(Constant.NO_SMS_RESULT);
                    smsBean.setPackId(Utils.getUUID());
                    smsBean.setCommandResult(commandResult);
//                    if (resultMsg.length>0){
//                        smsBean.setResultMsg(resultMsg[0]);
//
//                    }
                    if (resultMsg.length>0){
                        StringBuilder temp = new StringBuilder();
                        for(int i=0;i<resultMsg.length;i++){
                            temp.append(resultMsg[i]);
                        }
                        smsBean.setResultMsg(temp.toString());
                    }else{
                        smsBean.setResultMsg("");
                    }
                    smsBean.setNetworkState(""+serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN));
                    smsBean.setSysTime(Utils.getTimeMillis());
                    smsBean.setActionTime(actionTime);
                    //imageUrl不要传给后台
                    smsBean.setImageUrl("");

                    serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(smsBean),true,true);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });


    }
    
    public void setCellInfo(CellInfoBean cellInfoBean) {
        if (cellInfoBean != null){
            smsBean.setTac(TextUtils.isEmpty(cellInfoBean.getTac()) ? "" : cellInfoBean.getTac());
            smsBean.setEci(TextUtils.isEmpty(cellInfoBean.getEci()) ? "" : cellInfoBean.getEci());
        }

    }
}
