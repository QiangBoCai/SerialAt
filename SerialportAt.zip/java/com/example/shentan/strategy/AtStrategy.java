package com.example.shentan.strategy;

import android.os.Build;
import android.text.TextUtils;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.entity.CellInfoBean;
import com.example.shentan.entity.SysInfoBean;
import com.example.shentan.myThread.HeartThread;
import com.example.shentan.myThread.MCUHeartThreat;
import com.example.shentan.myThread.WriteWebStrListThread;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.singleton.DeviceStateSingleton;
import com.example.shentan.singleton.SendingWebDataSingleton;
import com.example.shentan.singleton.TCPSingleton;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.ATConstant;
import com.example.shentan.util.Constant;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;
import com.example.shentan.util.WriteLogUtil;
import com.odmsz.control.RILConstants;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;

public class AtStrategy extends BusinessStrategy {
    private HeartThread heartThread;
    private final SysInfoBean sysInfoBean;
    //private MCUHeartThreat mcuHeartThreat;
    private final SerialPortActivity serialPortActivity;
    private WriteWebStrListThread writeWebStrListThread;
    private int netWork;
    private int phoneType = 0;
    private int CGATT_TIMES = 0;
    private int ATCPIN_TIMERS = 0;

    //设备号
    private final StringBuffer devCodeCacheSB;
    private final StringBuilder sendSB;
    private final StringBuilder iccIdSB;

    public AtStrategy(SerialPortActivity serialPortActivity){
        this.serialPortActivity = serialPortActivity;
        sysInfoBean = new SysInfoBean();
        sendSB = new StringBuilder();
        iccIdSB = new StringBuilder();
        devCodeCacheSB = new StringBuffer();
    }

    @Override
    public void dealBusiness(String receiveWebData) {
        switch (Constant.AT_STEP_4G.toString()){

            case ATConstant.AT : {

                Constant.Interrupted_Need_Restart = true;
                receiveAt(receiveWebData);
                break;
            }

            case ATConstant.ATCIPSHUT : {
                setIndex(ATConstant.ATCIPSHUT);

                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCIPSHUT) == TCPSingleton.INSTANCE.getIndex()){

                    receiveATCIPSHUT(receiveWebData);
                }
                break;
            }

            case ATConstant.ATCFUN0 :{
                setIndex(ATConstant.ATCFUN0);

                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCFUN0) == TCPSingleton.INSTANCE.getIndex()){

                    receiveATCFUN0(receiveWebData);
                }
                break;
            }

            case ATConstant.ATCFUN1 :{
                setIndex(ATConstant.ATCFUN1);
                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCFUN1) == TCPSingleton.INSTANCE.getIndex()){

                    receiveATCFUN1(receiveWebData);
                }
                break;
            }

            case ATConstant.ATCPIN :{ //进入下一步或者重新开机
                setIndex(ATConstant.ATCPIN);
                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCPIN) == TCPSingleton.INSTANCE.getIndex()){

                    receiveATCPIN(receiveWebData);
                }
                break;
            }

            case ATConstant.ATCGATT :{ //进入下一步或飞行模式
                setIndex(ATConstant.ATCGATT);
                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCGATT) == TCPSingleton.INSTANCE.getIndex()){

                    receiveATCGATT(receiveWebData);
                }
                break;
            }

            case ATConstant.ATCIPMUX :{ //进入下一步
                setIndex(ATConstant.ATCIPMUX);
                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCIPMUX) == TCPSingleton.INSTANCE.getIndex()){

                    addNextAT(ATConstant.ATCIPQSEND);
                }
                break;
            }
            case ATConstant.ATCIPQSEND :{ //进入下一步
                setIndex(ATConstant.ATCIPQSEND);
                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCIPQSEND) == TCPSingleton.INSTANCE.getIndex()){

                    addNextAT(ATConstant.ATCSTT);
                }
                break;
            }

            case ATConstant.ATCSTT :{
                setIndex(ATConstant.ATCSTT);
                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCSTT) == TCPSingleton.INSTANCE.getIndex()){

                    addNextAT(ATConstant.ATCIICR);
                }
                break;
            }
            //进入下一步或者关闭移动网络
            case ATConstant.ATCIICR :{
                setIndex(ATConstant.ATCIICR);
                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCIICR) == TCPSingleton.INSTANCE.getIndex()){

                    receiveATCIICR(receiveWebData);
                }
                break;
            }
            case ATConstant.ATCIFSR : {
                setIndex(ATConstant.ATCIFSR);
                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCIFSR) == TCPSingleton.INSTANCE.getIndex()){

                    addNextAT(ATConstant.ATCIPSTATUS);
                }
                break;
            }
            case ATConstant.ATCIPSTATUS :{
                setIndex(ATConstant.ATCIPSTATUS);
                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCIPSTATUS) == TCPSingleton.INSTANCE.getIndex()){

                    receiveATCIPSTATUS(receiveWebData);
                }
                break;
            }
            case ATConstant.ATCIPSTART :{
                setIndex(ATConstant.ATCIPSTART);
                if (TCPSingleton.INSTANCE.getIndex() == Constant.DIGIT_1_negative ||
                        ATConstant.tcpList.indexOfValue(ATConstant.ATCIPSTART) == TCPSingleton.INSTANCE.getIndex()){

                    receiveATCIPSTART(receiveWebData);
                }
                break;
            }

            case ATConstant.ATCIPCLOSE : {
                closeTCPIP();
                break;
            }


            case ATConstant.AT_CGSN : {
                receiveAT_CGSN(receiveWebData);
                break;
            }

            case ATConstant.ATCIPSEND :{

                receiveATCIPSEND(receiveWebData);
                break;
            }

            case ATConstant.ATRESET :{

                receiveATRESET(receiveWebData);
                break;
            }
        }
    }

    private void setIndex(String currentAT) {
        TCPSingleton.INSTANCE.setIndex(ATConstant.tcpList.indexOfValue(currentAT));

    }
    private void setIndex(int index) {
        TCPSingleton.INSTANCE.setIndex(index);

    }

    private void receiveATCIPSEND(String receiveWebData) {
        if (receiveWebData.contains(">")){
            Constant.SEND_WEB_DATA_ERR_TIMERS = 0;

            Utils.clearSB(Constant.AT_STEP_4G);
            //给web端发送的数据以\0作为结尾
            Utils.replaceSB(sendSB,serialPortActivity.sendToWebSB.toString());

            if (TextUtils.isEmpty(sendSB)){
                SendingWebDataSingleton.INSTANCE.setSendingState(false);
                return;
            }else {

                if (!Utils.isJson(sendSB.toString().replace("@",""))){
                    SendingWebDataSingleton.INSTANCE.setSendingState(false);
                    return;
                }
            }


            //给后台发的数据，需要确认收到回复的才需要开启倒计时和设置webHaveReceived
            if (!TextUtils.isEmpty(sendSB)&&(
                    sendSB.toString().contains(Constant.NO_HEART) ||
                            sendSB.toString().contains(Constant.NO_RESTART_RESULT) ||
                            sendSB.toString().contains(Constant.NO_PHONE_RESULT) ||
                            sendSB.toString().contains(Constant.NO_SMS_RESULT) ||
                            sendSB.toString().contains(Constant.NO_APP_RESULT) ||
                            sendSB.toString().contains(Constant.NO_BROWSER_RESULT)
            )){

                serialPortActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        serialPortActivity.setResendCountDownTimer();
                        serialPortActivity.webHaveReceived = false;
                    }
                });
            }
            LogUtil.dd(Constant.SEND_AT_TAG_INFO, sendSB.toString());

            sendCommandTo4G(sendSB.toString(),serialPortActivity.bufferedOutputStream);

        }else if (receiveWebData.contains(Constant.ERROR)){
            if (Constant.SEND_WEB_DATA_ERR_TIMERS < Constant.SEND_WEB_DATA_ERR_TIMERS_LIMIT){
                Constant.SEND_WEB_DATA_ERR_TIMERS ++;
            }else {
                Constant.SEND_WEB_DATA_ERR_TIMERS = 0;
                closeTCPIP();
            }
        }
        SendingWebDataSingleton.INSTANCE.setSendingState(false);

    }

    private void closeTCPIP() {
        Utils.clearSB( Constant.AT_STEP_4G);
        Constant.TCP_OPEN = false;
        SendingWebDataSingleton.INSTANCE.setSendingState(false);
        //先关闭移动网络再去建立重连
        startTask();
    }

    private void receiveAT_CGSN(String receiveWebData) {
        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                if (receiveWebData.contains(Constant.OK)){

                    String []devCodeArr = receiveWebData.replace(Constant.OK,"").trim().split("\n");
                    Utils.replaceSB(devCodeCacheSB,devCodeArr[devCodeArr.length-1].trim());
                    if (!TextUtils.isEmpty(devCodeCacheSB.toString()) && Utils.isNumberStr(devCodeCacheSB.toString())){
                        serialPortActivity.heartBean.setSign(Utils.md5(Constant.SECRET_KEY+ devCodeCacheSB).trim());
                        serialPortActivity.heartBean.setDevCode(devCodeCacheSB.toString());

                        serialPortActivity.devicesRemarkBean.setIMEI_4G(devCodeCacheSB.toString());
                        serialPortActivity.devicesRemarkBean.setPhoneSystemVersion(Build.DISPLAY);

                        if (serialPortActivity.iservice != null) {

                            try {
                                Utils.replaceSB(iccIdSB,serialPortActivity.getIccid());
                                if (!TextUtils.isEmpty(iccIdSB.toString())){
                                    serialPortActivity.heartBean.setMachinePhone(iccIdSB.substring(0, iccIdSB.toString().length()-1));
                                }else {
                                    serialPortActivity.heartBean.setMachinePhone("");
                                }

                                FutureTask<Integer> futureTaskPhoneType = serialPortActivity.futureTaskUtils.getPhoneTypeFutureTask();
                                CachedThreadPoolSingleton.getInstance().execute(futureTaskPhoneType);
                                phoneType = futureTaskPhoneType.get(Constant.TIMER_OUT, TimeUnit.SECONDS);

                                if (phoneType != 0){
                                    serialPortActivity.heartBean.setCpin(Constant.CODE_1);
                                }else {
                                    serialPortActivity.heartBean.setCpin(Constant.CODE_0);
                                }
                                //获取小区信息
                                setCellInfo(serialPortActivity.getCellInfo());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }else {
                            serialPortActivity.bindODMSZServer();
                        }



                    }else {
                        serialPortActivity.add4GStr(ATConstant.AT_CGSN,false,false);
                    }
                }else {
                    serialPortActivity.add4GStr(ATConstant.AT_CGSN,false,false);
                }
                Utils.clearSB(Constant.AT_STEP_4G);
            }
        });

    }

    private void receiveATCIPSHUT(String receiveWebData) {
        serialPortActivity.synchronizedList.clear();
        if (receiveWebData.contains(Constant.OK)){
            addNextAT(ATConstant.ATCFUN0);

        }
    }

    private void receiveATCIPSTART(String receiveWebData) {
        if (receiveWebData.contains(Constant.RESPONSE_CONNECT_OK)){
            addNextAT(ATConstant.ATCIPSTATUS);
        }else if (receiveWebData.contains(Constant.RESPONSE_ALREADY_CONNECT)){
            Utils.clearSB(Constant.AT_STEP_4G);
            setIndex(Constant.DIGIT_1_negative);
            //建立TCPIP成功，可以向后端发送数据
            Constant.TCP_OPEN = true;
            WriteLogUtil.d(Constant.TCPIP_TAG_SUCCESS,"建立TCPIP通道成功");
            LogUtil.d("__TCPIP","建立TCPIP通道成功");
            //通道建立成功后，获取心跳包信息
            startHeartThread();
        }
    }


    private void receiveATCIPSTATUS(String receiveWebData) {
        if (receiveWebData.contains(Constant.RESPONSE_STATE_CONNECT_OK)){
            Utils.clearSB(Constant.AT_STEP_4G);
            setIndex(Constant.DIGIT_1_negative);
            //建立TCPIP成功，可以向后端发送数据
            Constant.TCP_OPEN = true;
            WriteLogUtil.d(Constant.TCPIP_TAG_SUCCESS,"建立TCPIP通道成功");
            LogUtil.d("__TCPIP","建立TCPIP通道成功");
            //通道建立成功后，获取心跳包信息
            startHeartThread();


            //开启MCU心跳
//            startMCUHeartThreat();

        } else {
            addNextAT(ATConstant.ATCIPSTART);

        }
    }

//    public void startMCUHeartThreat() {
//        if (mcuHeartThreat == null){
//            mcuHeartThreat = new MCUHeartThreat(serialPortActivity);
//            mcuHeartThreat.setName("mcuHeartThreat");
//
//        }
//        if (!mcuHeartThreat.isAlive()){
//            mcuHeartThreat.start();
//        }
//    }


    public void startHeartThread() {
        if (heartThread == null) {
            heartThread = new HeartThread(serialPortActivity);
            heartThread.setName("heartThread");
        }

        if (!heartThread.isAlive()) {
            heartThread.start();
        }
    }


    private void receiveATCIICR(String receiveWebData) {
        if (receiveWebData.contains(Constant.RESPONSE_OK) || receiveWebData.contains(Constant.ERROR_3)){
            addNextAT(ATConstant.ATCIFSR);
        }else {
            addNextAT(ATConstant.ATCIPSHUT);

        }
    }

    private void addNextAT(String nextAT){
        Utils.clearSB(Constant.AT_STEP_4G);
        TCPSingleton.INSTANCE.setTcpLostIndex(ATConstant.tcpList.indexOfValue(nextAT));
        serialPortActivity.add4GStr(nextAT,false,false);
    }

    private void receiveATCFUN1(String receiveWebData) {
        if (receiveWebData.contains(Constant.OK)){
            addNextAT(ATConstant.ATCPIN);
        }
    }

    private void receiveATCFUN0(String receiveWebData) {
        if (receiveWebData.contains(Constant.OK)){

            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        sleep(4000);
                        addNextAT(ATConstant.ATCFUN1);
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                }
            });
        }
    }

    private void receiveATCGATT(String receiveWebData) {

        if (receiveWebData.contains(Constant.RESPONSE_CGATT_1)){
            CGATT_TIMES = 0;
            addNextAT(ATConstant.ATCIPMUX);

        }else if (receiveWebData.contains(Constant.RESPONSE_CGATT_0)){
            if (CGATT_TIMES <= Constant.DIGIT_10){
                CGATT_TIMES ++;
                addNextAT(ATConstant.ATCGATT);
            }else {
                CGATT_TIMES = 0;
                addNextAT(ATConstant.ATCIPSHUT);
            }
        }
    }

    private void receiveATRESET(String receiveWebData) {
        if (receiveWebData.contains(Constant.RESPONSE_OK)){
            Utils.clearSB(Constant.AT_STEP_4G);
            Constant.ACTIVE_4G = false;
            Constant.TCP_OPEN = false;

            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                @Override
                public void run() {
                    while (!Constant.ACTIVE_4G){
                        try {
                            serialPortActivity.add4GStr(ATConstant.AT,false,false);

                            //发送完AT后静默等待一段时间再去检测模块是否启动成功
                            sleep(3000);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        }else {
            addNextAT(ATConstant.ATRESET);
        }
    }

    private void receiveATCPIN(String receiveWebData) {
        if (receiveWebData.contains(Constant.RESPONSE_READY)){
            ATCPIN_TIMERS = 0;
            addNextAT(ATConstant.ATCGATT);

        }else {
            if (ATCPIN_TIMERS <= Constant.DIGIT_10){
                ATCPIN_TIMERS ++;
                addNextAT(ATConstant.ATCPIN);

            }else {
                ATCPIN_TIMERS = 0;
                addNextAT(ATConstant.ATCIPSHUT);

            }
        }
    }

    private void receiveAt(String receiveWebData) {
        if (receiveWebData.contains(Constant.RESPONSE_OK)){
            Utils.clearSB(Constant.AT_STEP_4G);
            startWriteWebStrListThread();
            Constant.ACTIVE_4G = true;
            //重启数据网络后再去开启TCPIP通道
            startTask();

        }
    }

    public void startWriteWebStrListThread() {
        if (writeWebStrListThread == null){
            writeWebStrListThread = new WriteWebStrListThread(serialPortActivity);
            writeWebStrListThread.setName("writeWebStrListThread");
        }
        if (!writeWebStrListThread.isAlive()){
            writeWebStrListThread.start();

        }
    }

    //启动任务
    public void startTask(){
        Constant.TCP_OPEN = false;
        setIndex(Constant.DIGIT_1_negative);
        serialPortActivity.add4GStr(ATConstant.ATCIPSHUT,false,false);
    }
    
    public void stopThread(){
        if (writeWebStrListThread != null){
            serialPortActivity.synchronizedList.clear();
            writeWebStrListThread.interrupt();
            writeWebStrListThread = null;
        }

//        if (mcuHeartThreat != null){
//            mcuHeartThreat.interrupt();
//            mcuHeartThreat = null;
//        }

        if (heartThread != null){
            heartThread.interrupt();
            heartThread = null;
        }

    }

    public void setCellInfo(CellInfoBean cellInfoBean) {
        if (cellInfoBean != null){

            serialPortActivity.heartBean.setPci(TextUtils.isEmpty(cellInfoBean.getPci()) ? "" : cellInfoBean.getPci());
            serialPortActivity.heartBean.setTac(TextUtils.isEmpty(cellInfoBean.getTac()) ? "" : cellInfoBean.getTac());
            serialPortActivity.heartBean.setArfcn(TextUtils.isEmpty(cellInfoBean.getArfcn()) ? "" : cellInfoBean.getArfcn());
            serialPortActivity.heartBean.setEci(TextUtils.isEmpty(cellInfoBean.getEci()) ? "" : cellInfoBean.getEci());
            serialPortActivity.heartBean.setRssi(TextUtils.isEmpty(cellInfoBean.getRssi()) ? "" : cellInfoBean.getRssi());

            getSystemInfo();
        }

    }

    public void getSystemInfo(){

        if (serialPortActivity.iservice != null) {
            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                @Override
                public void run() {
                    try {

                        FutureTask<Integer> futureTask = serialPortActivity.futureTaskUtils.getNetFutureTask();

                        CachedThreadPoolSingleton.getInstance().execute(futureTask);

                        netWork = futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);

                        sysInfoBean.setSysMode(String.valueOf(netWork));

                        //GSM、CDMA 为 CS；其他为 ps
                        // cs:1  ps:2
                        if (netWork == RILConstants.NETWORK_MODE_GSM_ONLY|| netWork == RILConstants.NETWORK_MODE_CDMA_NO_EVDO){
                            sysInfoBean.setSrvDomain(Constant.CODE_1);
                        }else {
                            sysInfoBean.setSrvDomain(Constant.CODE_2);
                        }

                        FutureTask<Integer> simStateTask = serialPortActivity.futureTaskUtils.simStateFutureTask();

                        CachedThreadPoolSingleton.getInstance().execute(simStateTask);


                        sysInfoBean.setSimState(String.valueOf(simStateTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS)));

                        FutureTask<Boolean> RoamingStateTask = serialPortActivity.futureTaskUtils.roamingEnabledFutureTask();

                        CachedThreadPoolSingleton.getInstance().execute(RoamingStateTask);

                        if(RoamingStateTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS)){
                            sysInfoBean.setRoamStatus(Constant.CODE_1);
                        }else {
                            sysInfoBean.setRoamStatus(Constant.CODE_0);
                        }

                        FutureTask<Integer> serviceStateTask = serialPortActivity.futureTaskUtils.serviceStateFutureTask();

                        CachedThreadPoolSingleton.getInstance().execute(serviceStateTask);

                        sysInfoBean.setSrvStatus(String.valueOf(serviceStateTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS)));

                        serialPortActivity.heartBean.setSysinfo(sysInfoBean);

                        if (DeviceStateSingleton.INSTANCE.isDeviceBusyState()){
                            serialPortActivity.heartBean.setState(Constant.CODE_1);
                        }else {
                            serialPortActivity.heartBean.setState(Constant.CODE_0);
                        }

                        serialPortActivity.heartBean.setDevicesRemark(SerialPortActivity.gson.toJson(serialPortActivity.devicesRemarkBean));
                        serialPortActivity.heartBean.setPackId(Utils.getUUID());
                        serialPortActivity.heartBean.setSysTime(Utils.getTimeMillis());
                        serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(serialPortActivity.heartBean),true,false);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }else {

            serialPortActivity.bindODMSZServer();
        }
    }

    public void sendCommandTo4G(String sendStr, BufferedOutputStream bufferedOutputStream) {

        LogUtil.d("__sendCommandTo4G-2",""+sendStr);

        try {
            if (bufferedOutputStream != null) {
                bufferedOutputStream.write(sendStr.getBytes());
                bufferedOutputStream.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
