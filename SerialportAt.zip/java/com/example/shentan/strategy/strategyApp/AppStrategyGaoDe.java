package com.example.shentan.strategy.strategyApp;

import android.content.Context;
import android.os.CountDownTimer;
import android.text.TextUtils;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.entity.GaoDeBean;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.FindJsonUtil;
import com.example.shentan.util.GaoDeUtil;
import com.example.shentan.util.NetUtil;
import com.example.shentan.util.Utils;
import com.example.shentan.util.WriteLogUtil;

import static java.lang.Thread.sleep;

/**
 * App动作策略下的高度地图动作策略
 * 2022/4/15
 */
public class AppStrategyGaoDe extends BusinessStrategy {

    private final AppStrategy appStrategy;
    public static GaoDeBean gaoDeBean;

    public AppStrategyGaoDe(BusinessStrategy appStrategy){
        gaoDeBean = new GaoDeBean();
        this.appStrategy = (AppStrategy)appStrategy;

    }

    @Override
    public void dealBusiness(String receiveWebData) {

        WriteLogUtil.d("接收到指令:","高德地图指令");
        gaoDeBean = FindJsonUtil.parseJsonData(receiveWebData, GaoDeBean.class);

        //给后台回复收到消息
        if (TextUtils.isEmpty(gaoDeBean.getPackId())){
            this.appStrategy.serialPortActivity.sendCommonReturnToWebFail(Constant.NO_APP,gaoDeBean.getPackId(),"packId为空");
        }else {
            this.appStrategy.serialPortActivity.sendCommonReturnToWebSuccess(Constant.NO_APP, gaoDeBean.getPackId());
        }


        checkNetGaoDe(this.appStrategy.serialPortActivity);
    }

    public void checkNetGaoDe(Context context) {
        if (NetUtil.checkNet(context)){
            NetUtil.checkNetTimes = 0;

            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                @Override
                public void run() {
                    try{
                        sleep(2000);
                        if (gaoDeBean.getCommand().equals(Constant.CODE_1)){
                            //打开高德地图导航
                            appStrategy.serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(GaoDeUtil.gaoDeMapNavigation(gaoDeBean,context)),true,true);
                            //30秒后退出高德
                            setForceStopGaoDeDownTimer(context);
                        }else if (gaoDeBean.getCommand().equals(Constant.CODE_2)){
                            //经纬度和目的名至少有一个
                            if ((!TextUtils.isEmpty(gaoDeBean.getTargetLat()) && !TextUtils.isEmpty(gaoDeBean.getTargetLon())) || !TextUtils.isEmpty(gaoDeBean.getTargetAddress())){
                                //经纬度不为空的情况
                                if (!TextUtils.isEmpty(gaoDeBean.getTargetLat()) && !TextUtils.isEmpty(gaoDeBean.getTargetLon())){
                                    //经纬度不为空但目的名为空
                                    if (TextUtils.isEmpty(gaoDeBean.getTargetAddress())){
                                        appStrategy.serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(GaoDeUtil.gaoDeMapRoute("", gaoDeBean,context)),true,true);


                                    }else {//经纬度不为空且目的名不为空

                                        appStrategy.serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(GaoDeUtil.gaoDeMapRoute(gaoDeBean,context)),true,true);

                                    }
                                }else {//经纬度有一个为空则使用目的名

                                    appStrategy.serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(GaoDeUtil.gaoDeMapRoute(gaoDeBean,context)),true,true);


                                }

                                //30秒后退出高德
                                setForceStopGaoDeDownTimer(context);
                            }else {
                                returnGaoDeResult(Constant.CODE_3,Constant.PARAMS_ERR);

                            }
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });

        }else {

            if (NetUtil.checkNetTimes < 10){
                CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(5000);
                            checkNetGaoDe(context);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                });


            }else {
                NetUtil.checkNetTimes = 0;
                returnGaoDeResult(Constant.CODE_2,"没有网络");


            }
        }
    }

    public CountDownTimer forceStopGaoDeDownTimer;
    public void setForceStopGaoDeDownTimer(Context context){

        if (forceStopGaoDeDownTimer != null){
            forceStopGaoDeDownTimer.cancel();
            forceStopGaoDeDownTimer.start();
            return;
        }

        forceStopGaoDeDownTimer = new CountDownTimer(30000,1000){

            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                Utils.forceStopPackage(context,Constant.GAODE_PACKAGE_NAME);


            }
        }.start();
    }

    public void returnGaoDeResult(String commandResult, String...resultMsg){

        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    sleep(500);
                    gaoDeBean.setInfoCode(Constant.NO_APP_RESULT);
                    gaoDeBean.setPackId(Utils.getUUID());
                    gaoDeBean.setCommandResult(commandResult);
                    if (resultMsg.length>0){
                        gaoDeBean.setResultMsg(resultMsg[0]);

                    }
                    gaoDeBean.setSysTime(Utils.getTimeMillis());
                    appStrategy.serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(gaoDeBean),true,true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
