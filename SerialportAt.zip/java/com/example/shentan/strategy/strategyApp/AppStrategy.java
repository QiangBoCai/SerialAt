package com.example.shentan.strategy.strategyApp;

import android.text.TextUtils;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.singleton.DeviceStateSingleton;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.Utils;

import org.json.JSONException;
import org.json.JSONObject;

/**
 *App动作策略
 * 2022/4/15
 */
public class AppStrategy extends BusinessStrategy {
    public final SerialPortActivity serialPortActivity;
    private final StringBuilder appIdSB;

    public AppStrategy(SerialPortActivity serialPortActivity){
        this.serialPortActivity = serialPortActivity;
        appIdSB = new StringBuilder();
    }
    @Override
    public void dealBusiness( String receiveWebData) {

        Constant.infoCode_business = Constant.NO_APP;
        DeviceStateSingleton.INSTANCE.setDeviceState(true);
        try {
            Utils.replaceSB(appIdSB,new JSONObject(receiveWebData).get("appId"));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (!TextUtils.isEmpty(appIdSB.toString())){
            serialPortActivity.strategyFactory.getStrategy(Constant.TotalStrategyMapEnum.MAP_TYPE_APP,appIdSB.toString()).dealBusiness(receiveWebData);

        }
    }
}
