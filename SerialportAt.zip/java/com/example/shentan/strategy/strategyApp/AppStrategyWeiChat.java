package com.example.shentan.strategy.strategyApp;

import android.content.Intent;
import android.text.TextUtils;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.entity.WeiChatBean;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.FindJsonUtil;
import com.example.shentan.util.NetUtil;
import com.example.shentan.util.Utils;
import com.example.shentan.util.WriteLogUtil;

import static java.lang.Thread.sleep;
/**
 * App动作策略下的微信动作策略
 * 2022/4/15
 */
public class AppStrategyWeiChat extends BusinessStrategy {
    private final AppStrategy appStrategy;
    public  WeiChatBean weiChatBean;
    public AppStrategyWeiChat(BusinessStrategy appStrategy){
        weiChatBean = new WeiChatBean();
        this.appStrategy = (AppStrategy) appStrategy;

    }

    @Override
    public void dealBusiness(String receiveWebData) {

        WriteLogUtil.d("接收到指令:","微信指令");

        weiChatBean = FindJsonUtil.parseJsonData(receiveWebData, WeiChatBean.class);

        //给后台回复收到消息
        this.appStrategy.serialPortActivity.sendCommonReturnToWebSuccess(Constant.NO_APP, weiChatBean.getPackId());


        if (TextUtils.isEmpty(weiChatBean.getCommand())){
            returnWeiChatResult(Constant.CODE_2,"command 为空");
            return;
        }

        checkNetWeiChat(Constant.weiChat_action_map.get(weiChatBean.getCommand()));
    }
    public void checkNetWeiChat(String path) {
        if (NetUtil.checkNet(appStrategy.serialPortActivity)){
            NetUtil.checkNetTimes = 0;
            if (!TextUtils.isEmpty(path)){
                //启动微信动作脚本
                Intent intent = new Intent();
                intent.setClassName(Constant.WXTOOL_PACKAGE_NAME, Constant.WXTOOL_CLASS_NAME)
                        .putExtra("path", path)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                appStrategy.serialPortActivity.startActivity(intent);
            }else {
                returnWeiChatResult(Constant.CODE_2,"command 为空");
            }
        }else {
            if (NetUtil.checkNetTimes < 10){

                CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(5000);
                            checkNetWeiChat(path);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                });

            }else {
                NetUtil.checkNetTimes = 0;
                returnWeiChatResult(Constant.CODE_2,"没有网络");
            }


        }
    }

    //给后台回复执行结果
    public void returnWeiChatResult(String commandResult, String...resultMsg){

        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    sleep(500);

                    weiChatBean.setInfoCode(Constant.NO_APP_RESULT);
                    weiChatBean.setPackId(Utils.getUUID());
                    weiChatBean.setCommandResult(commandResult);
                    if (resultMsg.length>0){
                        weiChatBean.setResultMsg(resultMsg[0]);

                    }
                    weiChatBean.setSysTime(Utils.getTimeMillis());
                    appStrategy.serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(weiChatBean),true,true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
