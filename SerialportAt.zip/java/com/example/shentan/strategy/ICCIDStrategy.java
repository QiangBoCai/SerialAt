package com.example.shentan.strategy;

import android.os.RemoteException;
import android.text.TextUtils;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.entity.IccIdBean;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.singleton.DeviceStateSingleton;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.FindJsonUtil;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;
import com.example.shentan.util.WriteLogUtil;

public class ICCIDStrategy extends BusinessStrategy {
    private final SerialPortActivity serialPortActivity;
    private static IccIdBean iccIdBean;

    public ICCIDStrategy(SerialPortActivity serialPortActivity){
        this.serialPortActivity = serialPortActivity;
        iccIdBean = new IccIdBean();

    }
    @Override
    public void dealBusiness(String receiveWebData) {
        WriteLogUtil.d("接收到指令:","获取ICCID");
        Constant.infoCode_business = Constant.NO_GET_ICCID;
        DeviceStateSingleton.INSTANCE.setDeviceState(true);
        iccIdBean = FindJsonUtil.parseJsonData(receiveWebData, IccIdBean.class);

        //给后台回复收到消息
        if (TextUtils.isEmpty(iccIdBean.getPackId())){
            serialPortActivity.sendCommonReturnToWebFail(Constant.NO_GET_ICCID,iccIdBean.getPackId(),"packId为空");
        }else {
            serialPortActivity.sendCommonReturnToWebSuccess(Constant.NO_GET_ICCID, iccIdBean.getPackId());
        }

        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // 执行时间
                    String actionTime = Utils.getTimeMillis();
                    LogUtil.print("enter into IccidStrategy actionTime:"+actionTime);
                    // 检查netWork
                    int netWorkState = serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                    for(int i=0;i<18;i++){//检测3分钟
                        if(netWorkState>=0){
                            break;
                        }else{
                            Thread.sleep(10000);
                            netWorkState = serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                        }
                    }
                    LogUtil.print("netWorkState:"+netWorkState);
                    //若无卡，重启一次modem
                    if(netWorkState<0){
                        boolean resetModem = serialPortActivity.resetModem();
                        LogUtil.print("resetModem="+resetModem);
                        Thread.sleep(20000);
                        netWorkState = serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                        LogUtil.print("netWorkState:"+netWorkState);
                    }
                    if(netWorkState == -1){
                        returnIccIdResult(Constant.CODE_2,actionTime,Constant.NO_SIM,"");
                        return;
                    }
                    if (!TextUtils.isEmpty(iccIdBean.getOperator())){
                        if (Constant.OPERATOR_FLAG == Integer.parseInt(iccIdBean.getOperator())){

                            String iccid = serialPortActivity.getIccid();

                            if (TextUtils.isEmpty(iccid)){
                                returnIccIdResult(Constant.CODE_2,actionTime,"IccId为空","");
                            }else {
                                returnIccIdResult(Constant.CODE_1,actionTime,"",iccid.substring(0,iccid.length()-1));

                            }
                        }else {
                            serialPortActivity.setOperator(iccIdBean.getOperator());
                        }
                    } else {

                        // operator为空时，返回结果
                        returnIccIdResult(Constant.CODE_2,actionTime,"operator为空","");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void recheckSimSuccess(){
        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String iccid = serialPortActivity.getIccid();

                    if (TextUtils.isEmpty(iccid)){
                        returnIccIdResult(Constant.CODE_2,Utils.getTimeMillis(),"IccId为空","");
                    }else {
                        returnIccIdResult(Constant.CODE_1,Utils.getTimeMillis(),"", iccid.substring(0, iccid.length()-1));

                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }


    public void returnIccIdResult(String commandResult,String actionTime, String resultMsg,String iccid){
        iccIdBean.setMachinePhone(iccid);
        iccIdBean.setInfoCode(Constant.NO_GET_ICCID_RESULT);
        iccIdBean.setPackId(Utils.getUUID());
        iccIdBean.setCommandResult(commandResult);
        iccIdBean.setResultMsg(resultMsg);
        iccIdBean.setSysTime(Utils.getTimeMillis());
        iccIdBean.setActionTime(actionTime);
        try {
            iccIdBean.setNetworkState(""+serialPortActivity.iservice.getNetWorkState(Constant.ODMSZ_TOKEN));
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        serialPortActivity.add4GStr(SerialPortActivity.gson.toJson(iccIdBean),true,true);
    }
}
