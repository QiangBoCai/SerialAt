package com.example.shentan.strategy.control;

/**
 * 策略控制类
 * 2022/4/15
 */
public class BusinessDeal {
    private BusinessStrategy businessStrategy;

    public BusinessDeal setBusinessStrategy(BusinessStrategy businessStrategy){
        this.businessStrategy = businessStrategy;
        return this;
    }

    public void dealBusiness(String receiveWebData){
        if (businessStrategy != null){
            businessStrategy.dealBusiness(receiveWebData);
        }
    }
}
