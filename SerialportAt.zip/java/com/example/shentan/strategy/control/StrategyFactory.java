package com.example.shentan.strategy.control;

import android.text.TextUtils;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.strategy.strategyApp.AppStrategy;
import com.example.shentan.strategy.strategyApp.AppStrategyGaoDe;
import com.example.shentan.strategy.strategyApp.AppStrategyWeiChat;
import com.example.shentan.strategy.BrowserStrategy;
import com.example.shentan.strategy.ICCIDStrategy;
import com.example.shentan.strategy.strategyPhone.PhoneStrategy;
import com.example.shentan.strategy.RestartStrategy;
import com.example.shentan.strategy.strategySms.SmsStrategy;
import com.example.shentan.strategy.strategyPhone.PhoneStrategyAcceptCall;
import com.example.shentan.strategy.strategyPhone.PhoneStrategyDial;
import com.example.shentan.strategy.strategyPhone.PhoneStrategyEndCall;
import com.example.shentan.strategy.strategyPhone.PhoneStrategyNoAccessible;
import com.example.shentan.strategy.strategyPhone.PhoneStrategySetCallWaiting;
import com.example.shentan.strategy.strategyPhone.PhoneStrategyTransferBusy;
import com.example.shentan.strategy.strategyPhone.PhoneStrategyTransferCancel;
import com.example.shentan.strategy.strategyPhone.PhoneStrategyTransferNoReason;
import com.example.shentan.strategy.strategyPhone.PhoneStrategyTransferNoRelay;
import com.example.shentan.strategy.strategySms.SmsStrategyMnsReceive;
import com.example.shentan.strategy.strategySms.SmsStrategyMnsSend;
import com.example.shentan.strategy.strategySms.SmsStrategySetNet;
import com.example.shentan.strategy.strategySms.SmsStrategySmsReceive;
import com.example.shentan.strategy.strategySms.SmsStrategySmsSend;
import com.example.shentan.util.Constant;

import java.util.HashMap;

/**
 * 策略池存放策略
 * 2022/4/15
 */
public class StrategyFactory {
    private final HashMap<Constant.TotalStrategyMapEnum,HashMap<String,BusinessStrategy>> totalStrategyMap;

    public volatile static StrategyFactory instance;

    public static StrategyFactory getInstance(SerialPortActivity serialPortActivity){
        if (instance == null){
            synchronized (StrategyFactory.class){
                if (instance == null){
                    instance = new StrategyFactory(serialPortActivity);
                }
            }
        }
        return instance;
    }

    public void clear(){
        totalStrategyMap.clear();
        if (instance != null){
            instance = null;
        }
    }

    private StrategyFactory(SerialPortActivity serialPortActivity){
        RestartStrategy restartStrategy = new RestartStrategy(serialPortActivity);
        PhoneStrategy   phoneStrategy   = new PhoneStrategy  (serialPortActivity);
        SmsStrategy     smsStrategy     = new SmsStrategy    (serialPortActivity);
        AppStrategy     appStrategy     = new AppStrategy    (serialPortActivity);
        BrowserStrategy browserStrategy = new BrowserStrategy(serialPortActivity);
        ICCIDStrategy   iccidStrategy   = new ICCIDStrategy  (serialPortActivity);
        //获取顶层策略
        HashMap<String,BusinessStrategy> businessStrategyMap = new HashMap<String,BusinessStrategy>(){{
            put(Constant.NO_RESTART,restartStrategy);
            put(Constant.NO_PHONE,phoneStrategy);
            put(Constant.NO_SMS,smsStrategy);
            put(Constant.NO_APP,appStrategy);
            put(Constant.NO_BROWSER,browserStrategy);
            put(Constant.NO_GET_ICCID,iccidStrategy);
        }};

        //电话业务的细分策略
        PhoneStrategyAcceptCall phoneStrategyAcceptCall = new PhoneStrategyAcceptCall(phoneStrategy);
        HashMap<String,BusinessStrategy> phoneStrategyMap = new HashMap<String,BusinessStrategy>(){{
            put(Constant.CODE_1,new PhoneStrategyDial(phoneStrategy));
            put(Constant.CODE_2,phoneStrategyAcceptCall);
            put(Constant.CODE_3,new PhoneStrategyEndCall(phoneStrategy));
            put(Constant.CODE_4,new PhoneStrategyTransferNoRelay(phoneStrategy));
            put(Constant.CODE_5,new PhoneStrategyTransferNoReason(phoneStrategy));
            put(Constant.CODE_6,new PhoneStrategyTransferBusy(phoneStrategy));
            put(Constant.CODE_7,new PhoneStrategySetCallWaiting(phoneStrategy));
            put(Constant.CODE_8,new PhoneStrategyTransferCancel(phoneStrategy));
            put(Constant.CODE_10,phoneStrategyAcceptCall);
            put(Constant.CODE_11,new PhoneStrategyNoAccessible(phoneStrategy));
        }};

        //短信业务的细分策略
        HashMap<String,BusinessStrategy> smsStrategyMap = new HashMap<String,BusinessStrategy>(){{
            put(Constant.CODE_1,new SmsStrategySmsSend(smsStrategy));
            put(Constant.CODE_2,new SmsStrategySmsReceive(smsStrategy));
            put(Constant.CODE_3,new SmsStrategySetNet(smsStrategy));
            put(Constant.CODE_4,new SmsStrategyMnsSend(smsStrategy));
            put(Constant.CODE_5,new SmsStrategyMnsReceive(smsStrategy));
        }};

        //App动作业务的细分策略
        HashMap<String,BusinessStrategy> appStrategyMap = new HashMap<String,BusinessStrategy>(){{
            put(Constant.CODE_1,new AppStrategyWeiChat(appStrategy));
            put(Constant.CODE_3,new AppStrategyGaoDe(appStrategy));
        }};

        totalStrategyMap = new HashMap<Constant.TotalStrategyMapEnum,HashMap<String,BusinessStrategy>>(){{
            put(Constant.TotalStrategyMapEnum.MAP_TYPE_BUSINESS,businessStrategyMap);
            put(Constant.TotalStrategyMapEnum.MAP_TYPE_PHONE,phoneStrategyMap);
            put(Constant.TotalStrategyMapEnum.MAP_TYPE_SMS,smsStrategyMap);
            put(Constant.TotalStrategyMapEnum.MAP_TYPE_APP,appStrategyMap);
        }};
    }


    public BusinessStrategy getStrategy(Constant.TotalStrategyMapEnum totalStrategyMapEnum, String strategyType){
        if (TextUtils.isEmpty(strategyType)){
            throw new IllegalArgumentException("strategyType should not be empty");
        }

        return totalStrategyMap.get(totalStrategyMapEnum).get(strategyType);
    }

    public PhoneStrategy getBusinessStrategyPhone(){
        return (PhoneStrategy) getStrategy(Constant.TotalStrategyMapEnum.MAP_TYPE_BUSINESS,Constant.NO_PHONE);
    }

    public AppStrategyWeiChat getAppStrategyWeiChat(){
        return (AppStrategyWeiChat) getStrategy(Constant.TotalStrategyMapEnum.MAP_TYPE_APP,Constant.CODE_1);
    }
}
