package com.example.shentan.strategy.control;

/**
 * 策略基类
 * 2022/4/15
 */
public abstract class BusinessStrategy {
    public void dealBusiness(){}
    public void dealBusiness(String receiveWebData){}
    public void recheckSimSuccess(){}
}
