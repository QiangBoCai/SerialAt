package com.example.shentan.strategy;

import android.text.TextUtils;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.strategy.control.BusinessStrategy;
import com.example.shentan.util.Constant;
import com.example.shentan.util.Utils;

import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

public class McuStrategy extends BusinessStrategy {
    private final SerialPortActivity serialPortActivity;

    public McuStrategy(SerialPortActivity serialPortActivity){
        this.serialPortActivity = serialPortActivity;

    }

    @Override
    public void dealBusiness(String receiveWebData) {
        String [] receiveWebDataArr = receiveWebData.split(",");

        if (receiveWebDataArr.length >= Constant.MCU_DATA_LENGTH){
            if (Constant.OPERATOR_FLAG != Integer.parseInt(receiveWebDataArr[2])){
                Constant.OPERATOR_FLAG = Integer.parseInt(receiveWebDataArr[2]); //sim配置

            }

            int shutState = Integer.parseInt(receiveWebDataArr[6]); //开关机状态

            if (receiveWebDataArr.length > 8){

                serialPortActivity.devicesRemarkBean.setMcuHardwareVersion(receiveWebDataArr[7]);
                serialPortActivity.devicesRemarkBean.setMcuSoftwareVersion(receiveWebDataArr[8]);
            }

            if (shutState == 1){

                //调用shutdown接口关机，不走onDestroy方法，因此需要在这里调用一下释放资源
                serialPortActivity.release();

                if (serialPortActivity.iservice != null){
                    CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                FutureTask<Boolean> futureTask = serialPortActivity.futureTaskUtils.shutdown();

                                CachedThreadPoolSingleton.getInstance().execute(futureTask);

                                futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    });
                }


            }



            if (Constant.IS_MCU_COMMAND){
                Constant.IS_MCU_COMMAND = false;
                //如果是无法接通转移的最后一步切换到其他运营商，那么在这里就可以回复结果了
                if (Constant.IS_FLAG_TRANSFER_INACCESSABLE){
                    Constant.IS_FLAG_TRANSFER_INACCESSABLE = false;
                    serialPortActivity.strategyFactory.getBusinessStrategyPhone().returnPhoneResult(Constant.CODE_1, Utils.getTimeMillis());
                }else {
                    recheckSim();


                }
            }

        }
    }

    public static int getNetworkStateTimes = 0;
    public static int getSimStateTimes = 0;
    public static int recheckSimWaitTimes = 0;
    private void recheckSim() {

        //有竞争时自旋等待
        if (getSimStateTimes != 0){
            if (recheckSimWaitTimes <= Constant.TRY_FAIL_TIMES){
                recheckSimWaitTimes ++;
                CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(3000);
                            recheckSim();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }

            return;
        }

        recheckSimWaitTimes = 0;

        if (serialPortActivity.iservice != null){
            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                @Override
                public void run() {
                    try {

                        FutureTask<Boolean> futureTaskPhoneType = serialPortActivity.futureTaskUtils.restartModemFutureTask();
                        CachedThreadPoolSingleton.getInstance().execute(futureTaskPhoneType);
                        futureTaskPhoneType.get(Constant.TIMER_OUT, TimeUnit.SECONDS);
                        FutureTask<Integer> futureTaskPhoneType2 = serialPortActivity.futureTaskUtils.getSimStateFutureTaskMcu();

                        CachedThreadPoolSingleton.getInstance().execute(futureTaskPhoneType2);
                        if (futureTaskPhoneType2.get(Constant.TIMER_OUT, TimeUnit.SECONDS) != null){
                            futureTaskPhoneType2.get(Constant.TIMER_OUT, TimeUnit.SECONDS);

                        }

                        if (!TextUtils.isEmpty(Constant.infoCode_business)){
                            serialPortActivity.strategyFactory.getStrategy(Constant.TotalStrategyMapEnum.MAP_TYPE_BUSINESS,Constant.infoCode_business).recheckSimSuccess();

                        }

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
        }
    }
}
