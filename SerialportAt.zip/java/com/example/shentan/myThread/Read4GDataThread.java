package com.example.shentan.myThread;

import android.text.TextUtils;
import com.example.shentan.SerialPortActivity;
import com.example.shentan.catchExection.MyCrashHandler;
import com.example.shentan.chain.ManagerInterceptorChain;
import com.example.shentan.util.Constant;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;

import java.lang.ref.WeakReference;

/**
 * 读取4G串口数据的线程
 * 2022/4/15
 */
public class Read4GDataThread extends Thread {
    private final WeakReference<SerialPortActivity> serialPortActivity;

    private final StringBuilder receiveWebDataSB;

    private final ManagerInterceptorChain managerInterceptorChain;//传递下发任务可执行等级

    public Read4GDataThread(SerialPortActivity serialPortActivity){
        this.serialPortActivity = new WeakReference<>(serialPortActivity);
        Thread.currentThread().setUncaughtExceptionHandler(MyCrashHandler.INSTANCE);

        receiveWebDataSB = new StringBuilder();
        managerInterceptorChain = ManagerInterceptorChain.getInstance();

    }

    @Override
    public void run() {
        super.run();

            try {
                while (!Thread.currentThread().isInterrupted()) {

                    if (serialPortActivity.get().bufferedInputStream == null){
                        return;
                    }

                if (serialPortActivity.get().bufferedInputStream.available() > 0) {
                        sleep(500);
                    byte[] buffer = new byte[serialPortActivity.get().bufferedInputStream.available()];
                    int size = serialPortActivity.get().bufferedInputStream.read(buffer);
                        if (size > 0) {

                            Utils.replaceSB(receiveWebDataSB,new String(buffer));

                            LogUtil.dd("__串口回复的数据",receiveWebDataSB.toString());
                            if (!TextUtils.isEmpty(receiveWebDataSB.toString())) {
                                for (String str : managerInterceptorChain.proceed(buffer, size, receiveWebDataSB.toString())){
                                    LogUtil.d("__receiveWebData",str);
                                    serialPortActivity.get().onDataReceivedTcpIp(str);

                                }
                            }
                        }
                    }
                }
            }
            catch (InterruptedException e){
                e.printStackTrace();
                if (Constant.Interrupted_Need_Restart){
                    serialPortActivity.get().startRead4GDataThread();
                }
            }catch (Exception e){
                managerInterceptorChain.removeAllInterceptor();

                e.printStackTrace();

            }
    }


}

