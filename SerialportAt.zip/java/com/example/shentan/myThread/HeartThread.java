package com.example.shentan.myThread;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.catchExection.MyCrashHandler;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.util.Constant;
import com.example.shentan.util.Utils;

import java.lang.ref.WeakReference;

/**
 * 跟后端通信的心跳包线程
 *
 * 2022/4/15
 */
public class HeartThread extends Thread {
    private final WeakReference<SerialPortActivity> serialPortActivity;
    public HeartThread(SerialPortActivity serialPortActivity){
        this.serialPortActivity = new WeakReference<>(serialPortActivity);
        Thread.currentThread().setUncaughtExceptionHandler(MyCrashHandler.INSTANCE);

    }

    @Override
    public void run() {
        super.run();
            try {
                while (!Thread.currentThread().isInterrupted()) {

                    if (Constant.TCP_OPEN) {
                        serialPortActivity.get().getDeviceInfo();
                    }


                    //每隔一段时间获取一下cpu温度和电池电量，放在心跳包这里主要是获取的时间间隔和心跳包间隔差不多，避免创建过多线程
                    //单独使用线程池是避免获取数据阻塞导致心跳包线程阻塞
                    CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                        @Override
                        public void run() {
                            try {

                                Utils.replaceSB(serialPortActivity.get().cpuTemperatureSB,serialPortActivity.get().iservice.getCpuTemperature(Constant.ODMSZ_TOKEN).trim());
                                sleep(1000);
                                serialPortActivity.get().batteryLevel = serialPortActivity.get().iservice.getBatteryLevel(Constant.ODMSZ_TOKEN);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });


                    sleep(28000);
                }
            }

            catch (InterruptedException e){
                e.printStackTrace();
                if (Constant.Interrupted_Need_Restart){
                    serialPortActivity.get().atStrategy.startHeartThread();
                }

            }catch (Exception e){
                e.printStackTrace();

            }

    }

}
