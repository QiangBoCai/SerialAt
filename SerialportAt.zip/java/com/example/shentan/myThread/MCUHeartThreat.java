package com.example.shentan.myThread;


import com.example.shentan.SerialPortActivity;
import com.example.shentan.catchExection.MyCrashHandler;
import com.example.shentan.util.Constant;

import java.lang.ref.WeakReference;

/**
 *跟硬件通信的心跳包线程
 * 2022/4/15
 */
public class MCUHeartThreat extends Thread {

    private final WeakReference<SerialPortActivity> serialPortActivity;


    public MCUHeartThreat(SerialPortActivity serialPortActivity){
        this.serialPortActivity = new WeakReference<>(serialPortActivity);
        Thread.currentThread().setUncaughtExceptionHandler(MyCrashHandler.INSTANCE);

    }

    @Override
    public void run() {
        super.run();

            try {
                sleep(5000);
                while (!Thread.currentThread().isInterrupted()) {
                   // if (Constant.TCP_OPEN) {
                        //hexCommand 区分操作运营商的指令数据和普通的mcu数据
                        //operatorFlag 0为查询数据
                        serialPortActivity.get().sendMcuData(false, 0);
                   // }
                    sleep(5000);
                }
            }catch (InterruptedException e){
                e.printStackTrace();
//                if (Constant.Interrupted_Need_Restart){
//                    serialPortActivity.get().atStrategy.startMCUHeartThreat();
//                    serialPortActivity.get().startMCUHeartThreat(serialPortActivity);
//                }

            }
            catch (Exception e){
                e.printStackTrace();

            }


    }
}
