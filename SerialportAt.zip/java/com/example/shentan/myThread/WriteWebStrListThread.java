package com.example.shentan.myThread;

import com.example.shentan.SerialPortActivity;
import com.example.shentan.catchExection.MyCrashHandler;
import com.example.shentan.entity.WriteWebStrListBean;
import com.example.shentan.singleton.SendingWebDataSingleton;
import com.example.shentan.singleton.TCPSingleton;
import com.example.shentan.util.ATConstant;
import com.example.shentan.util.Constant;

import java.lang.ref.WeakReference;

/**
 * 向4G串口写入数据的线程
 * 2022/4/15
 */
public class WriteWebStrListThread extends Thread{
    private final WeakReference<SerialPortActivity> serialPortActivity;
    public WriteWebStrListThread(SerialPortActivity serialPortActivity){
        this.serialPortActivity = new WeakReference<>(serialPortActivity);
        Thread.currentThread().setUncaughtExceptionHandler(MyCrashHandler.INSTANCE);

    }

    @Override
    public void run() {
        super.run();
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    //若不是处于正在发送数据状态
                    if (!SendingWebDataSingleton.INSTANCE.isSendingWebStateState()){
                        //数据队列中有数据 && 上一次发送给后端的数据串口已经收到
                        if (serialPortActivity.get().synchronizedList != null && serialPortActivity.get().synchronizedList.size() > 0 && serialPortActivity.get().webHaveReceived) {

                            WriteWebStrListBean writeWebStrListBean = serialPortActivity.get().synchronizedList.get(0);

                            serialPortActivity.get().sendDataToWeb(writeWebStrListBean);

                            serialPortActivity.get().synchronizedList.remove(writeWebStrListBean);
                        }
                    }


                    //TCP连接步骤的重发机制，只当正在建立TCP连接时才生效
                    if (TCPSingleton.INSTANCE.getIndex() != Constant.DIGIT_1_negative){

                        //从上一次发送AT指令后到本次循环还未收到串口回复，则重发一次
                        if (TCPSingleton.INSTANCE.compareIndexFlagFlag()){

                            //{Constant.DIGIT_1_negative}的情况，没有未收到回复的步骤
                            //{Constant.DIGIT_1}的情况，开启飞行模式，会等待一会儿，所以这种情况没收到回复不会重发
                            //{Constant.DIGIT_11}的情况，建立TCP连接时可能需要等待一会儿才能收到回复，所以这种情况没收到回复不会重发
                            if (TCPSingleton.INSTANCE.getTcpLostIndex() != Constant.DIGIT_1_negative &&
                                    TCPSingleton.INSTANCE.getIndex() != Constant.DIGIT_1 &&
                                    TCPSingleton.INSTANCE.getIndex() != Constant.DIGIT_11){

                                TCPSingleton.INSTANCE.setIndex();
                                serialPortActivity.get().add4GStr(ATConstant.tcpList.get(TCPSingleton.INSTANCE.getTcpLostIndex()),false,false);

                            }
                        }else {
                            //与上次的值不一致，说明上次发送的指令已经收到串口回复
                            TCPSingleton.INSTANCE.setIndexFlagCheck();

                        }
                    }

                    sleep(2000);
                }
            }
            catch (InterruptedException e){
                e.printStackTrace();
                if (Constant.Interrupted_Need_Restart){
                    serialPortActivity.get().atStrategy.startWriteWebStrListThread();
                }

            }
            catch (Exception e){
                e.printStackTrace();

            }
    }
}
