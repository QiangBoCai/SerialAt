package com.example.shentan;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.RemoteException;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import com.example.shentan.broadcast.TestControlReceiver;
import com.example.shentan.broadcast.TimeReceiver;
import com.example.shentan.broadcast.WeiChatActionBroadcastReceiver;
import com.example.shentan.entity.BaseReturnBean;
import com.example.shentan.entity.CellInfoBean;
import com.example.shentan.entity.DevicesRemarkBean;
import com.example.shentan.entity.HeartBean;
import com.example.shentan.entity.WriteWebStrListBean;
import com.example.shentan.myThread.MCUHeartThreat;
import com.example.shentan.myThread.Read4GDataThread;
import com.example.shentan.singleton.CachedThreadPoolSingleton;
import com.example.shentan.singleton.DeviceStateSingleton;
import com.example.shentan.singleton.SendingWebDataSingleton;
import com.example.shentan.strategy.AtStrategy;
import com.example.shentan.strategy.control.BusinessDeal;
import com.example.shentan.strategy.McuStrategy;
import com.example.shentan.strategy.control.StrategyFactory;
import com.example.shentan.util.ATConstant;
import com.example.shentan.util.ByteUtil;
import com.example.shentan.util.Constant;
import com.example.shentan.util.FutureTaskUtils;
import com.example.shentan.util.IpConfigUtil;
import com.example.shentan.util.LogUtil;
import com.example.shentan.util.Utils;
import com.example.shentan.util.WriteLogUtil;
import com.google.gson.Gson;
import com.odmsz.control.CellIdentity;
import com.odmsz.control.CellIdentityCdma;
import com.odmsz.control.CellIdentityGsm;
import com.odmsz.control.CellIdentityLte;
import com.odmsz.control.CellIdentityNr;
import com.odmsz.control.CellIdentityWcdma;
import com.odmsz.control.IOdmSzControlService;
import com.odmsz.control.RILConstants;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

import static com.example.shentan.util.Utils.strTo16;
import static java.lang.Thread.sleep;

public abstract class SerialPortActivity extends Activity {

    public AtStrategy atStrategy;
    public McuStrategy mcuStrategy;
    public BusinessDeal businessDeal;
    public FutureTaskUtils futureTaskUtils;
    private WriteWebStrListBean writeWebStrListBean;
    private WeiChatActionBroadcastReceiver weiChatActionBroadcastReceiver;
    private int sendToWebStrLength = 0;
    public boolean webHaveReceived = true;
    private BaseReturnBean baseReturnBean;
    private StringBuilder sendCommandSB;
    public StrategyFactory strategyFactory;
    private PowerManager mPowerManager;
    private PowerManager.WakeLock mWakeLock;

    //存储发送给后台的指令
    public final List<WriteWebStrListBean> synchronizedList = Collections.synchronizedList(new LinkedList<>());

    //发送给后台的字符串
    public  StringBuffer sendToWebSB;
    //发送给后台的数据长度，最长不超过1460字节
    public HeartBean heartBean;
    public DevicesRemarkBean devicesRemarkBean;
    public static Gson gson;
    private final String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE

    };
    //请求状态码
    private final int REQUEST_CODE = 100;
    private int tempInt;
    public int batteryLevel;
    private StringBuffer pciSB;
    private StringBuffer tacSB;
    private StringBuffer eciSB;
    private StringBuffer rssiSB;
    private StringBuffer arfcnSB;
    private int batteryTemperature;
    private SerialPort mSerialPortWeb;
    private CellInfoBean cellInfoBean;
    private  ArrayList<byte[]> byteArr;
    private MyApplication mApplication;
    private StringBuilder batteryLevelSB;
    public StringBuilder cpuTemperatureSB;
    private StringBuilder hexOperateFlagSB;
    private Read4GDataThread read4GDataThread;
    private  StringBuilder batteryTemperatureSB;
    private ArrayList<CellIdentity> cellIdentitys;
    public BufferedInputStream bufferedInputStream;
    public TestControlReceiver testControlReceiver;
    public TimeReceiver TimeReceiver;
    public BufferedOutputStream bufferedOutputStream;
    private MCUHeartThreat mcuHeartThreat;
    private Context context;
    public static  String OdmSzToolsVerName="";
    public static  String appVerName="";
    /**
     * 获取版本号名称
     *
     * @param context 上下文
     * @return
     */
    public  String getVerName(Context context) {
        try {
            appVerName = context.getPackageManager().
                    getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        LogUtil.print("OdmSzToolsVersionName:"+OdmSzToolsVerName );
        LogUtil.print("appVersionName:"+appVerName );
        return appVerName;
    }





    /**
     *
     * @param hexCommand：区分指令数据和普通心跳包数据
     * @param operatorFlag
     * -1：重启（自己处理逻辑）
     * 0：查询（跟硬件约定的）
     * 1：移动（跟硬件约定的）
     * 2：电信（跟硬件约定的）
     * 3：联通（跟硬件约定的）
     */
    public void sendMcuData(boolean hexCommand,int operatorFlag) {
        CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    if(TextUtils.isEmpty(OdmSzToolsVerName)){
                        OdmSzToolsVerName= iservice.getVersion(Constant.ODMSZ_TOKEN);
                        LogUtil.d("OdmSzToolsVerName="+OdmSzToolsVerName);
                    }
                    // 检查netWork
                    int netWorkState = iservice.getNetWorkState(Constant.ODMSZ_TOKEN);
                    LogUtil.d("netWorkState="+netWorkState);
                    LogUtil.d("sendMcuData hexCommand="+hexCommand+" operatorFlag="+operatorFlag);
                    Utils.replaceSB(hexOperateFlagSB,Constant.CODE_0,operatorFlag);
                    Utils.replaceSB(cpuTemperatureSB,iservice.getCpuTemperature(Constant.ODMSZ_TOKEN).trim());
                    LogUtil.d("cpuTemperatureSB="+cpuTemperatureSB);

                    //cpu温度 //需要除以1000  eg:36700
                    if (!TextUtils.isEmpty(cpuTemperatureSB)){
                        try {
                            tempInt = Integer.parseInt(cpuTemperatureSB.toString()) / 1000;
                            LogUtil.d("tempInt="+tempInt);//36

                            if (tempInt<10){
                                Utils.replaceSB(cpuTemperatureSB,Constant.CODE_0,tempInt);

                            }else {
                                Utils.replaceSB(cpuTemperatureSB,Constant.CODE_0,Integer.toHexString(tempInt));

                            }
                            LogUtil.d("Hex cpuTemperatureSB="+cpuTemperatureSB);

                        }catch (Exception e){
                            e.printStackTrace();
                        }

                    }
                    //电池电量
                    if(batteryLevel==0){
                        batteryLevel = 100;
                    }
                    LogUtil.d("batteryLevel="+batteryLevel);

                    if (batteryLevel < 10){
                        Utils.replaceSB(batteryLevelSB,Constant.CODE_0,batteryLevel);
                    }else {
                        Utils.replaceSB(batteryLevelSB,Integer.toHexString(batteryLevel));

                    }
                    LogUtil.d("Hex batteryLevelSB="+batteryLevelSB);


                    //电池温度 //需要除以10
                    batteryTemperature = TestControlReceiver.batteryTemperature;

                    if (batteryTemperature != 0){
                        batteryTemperature = batteryTemperature / 10;
                        LogUtil.d("batteryTemperature="+batteryTemperature);
                        if (batteryTemperature < 10){
                            Utils.replaceSB(batteryTemperatureSB,Constant.CODE_0,batteryTemperature);

                        }else {
                            Utils.replaceSB(batteryTemperatureSB,Integer.toHexString(batteryTemperature));


                        }
                    }
                    LogUtil.d("Hex batteryTemperatureSB="+batteryTemperatureSB);

                    //手机主板发送，stdz,心跳，CPU温度，手机主板电池电量，电池温度，SIM配置 ，回车换行
                    byte[] b1 = ByteUtil.hexStr2bytes(strTo16(Constant.MCU_PRE));//STDZ为心跳包包头，字符为大写ASCII码。
                    byte[] b2 = ByteUtil.hexStr2bytes(Constant.MCU_HEART);//A为恒为0x00 代表该数据为心跳包
                    byte[] b3 = ByteUtil.hexStr2bytes(strTo16(","));//“，”为字段分隔符，对应ASCII码0x2C
                    byte[] b4 = ByteUtil.hexStr2bytes(cpuTemperatureSB.toString()); //CPU温度//B代表手机主板温度，进制为十六进制。
                    byte[] b6 = ByteUtil.hexStr2bytes(batteryLevelSB.toString()); //手机主板电池电量 // C代表手机电池电量，进制为十六进制。
                    byte[] b8 = ByteUtil.hexStr2bytes(batteryTemperatureSB.toString()); //电池温度 //D代表手机电池温度，进制为十六进制
                    byte[] b10 = ByteUtil.hexStr2bytes((hexOperateFlagSB.toString())); //SIM配置 //E代表SIM卡配置操作码，0x01代表卡槽01生效；0x02代表卡槽02生效；0x03代表卡槽03生效。0x00代表查询SIM卡配置
                    byte[] b12;
                    if(Constant.TCP_OPEN){//是否连接到web平台
                        LogUtil.dd("TCP_OPEN",""+Constant.TCP_OPEN);
                        b12 = new byte[]{1}; //F 代表是否连接到web平台
                    }else{
                        b12 = new byte[]{0};
                    }
                    byte[] b14 = ByteUtil.hexStr2bytes(ATConstant.RETURN_HEX); //\r\n：回车换行
                    byteArr.clear();
                    byteArr.add(b1 );//包头
                    byteArr.add(b2 );//A
                    byteArr.add(b3 );//,
                    byteArr.add(b4 );//B
                    byteArr.add(b3 );//,
                    byteArr.add(b6 );//C
                    byteArr.add(b3 );//,
                    byteArr.add(b8 );//D
                    byteArr.add(b3 );//,
                    byteArr.add(b10);//E
                    byteArr.add(b3 );//,
                    byteArr.add(b12);//F
                    byteArr.add(b14);//\r\n
                    add4GStr(ByteUtil.addBytes(byteArr),hexCommand);
                    LogUtil.dd("MCU_HEART bytes",ByteUtil.bytes2hex(ByteUtil.addBytes(byteArr)));
                    //参考ACII码表 https://blog.csdn.net/weixin_56063394/article/details/119886081
                    //STDZ,A(0),B(CPU温度),C(手机主板电池电量),D(电池温度),E(SIM配置),F(TCP连接状态)\r\n
                    //[73 74 64 7a 2c 00 2c 02 2c 64 2c 19 2c 00 2c 01 0d 0a]
                    // __向串口写入数据|[115, 116, 100, 122, 44, 0, 44, 2, 44, 100, 44, 25, 44, 0, 44, 1, 13, 10]
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

    }


    //移动：2G GSM    3G TD-SCDMA    4G LTE      5G NR
    //联通：2G GSM    3G WCDMA       4G LTE      5G NR
    //电信：2G CDMA   3G EvDo        4G LTE      5G NR
    public boolean isSetNetSuccess(String phoneFormat) {

        boolean setNetSuccess = false;
        try {
            //对比制式，检测是否需要进行切换
            FutureTask<Integer> getNetFutureTask = futureTaskUtils.getNetFutureTask();
            CachedThreadPoolSingleton.getInstance().execute(getNetFutureTask);
            int getNetResult = getNetFutureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);

            if (getNetResult == Constant.formatTotal.get(phoneFormat).get(Constant.OPERATOR_FLAG)){
                setNetSuccess = true;
            }else {
                FutureTask<Boolean> setNetFutureTask = futureTaskUtils.setNetFutureTask(Constant.formatTotal.get(phoneFormat).get(Constant.OPERATOR_FLAG));
                CachedThreadPoolSingleton.getInstance().execute(setNetFutureTask);
                setNetSuccess = setNetFutureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);

            }
        }catch (Exception e){

            e.printStackTrace();
        }
        return setNetSuccess;

    }

    public boolean resetModem(){

        boolean resetSuccess = false;
        try {
            FutureTask<Boolean> futureTask = futureTaskUtils.restartModemFutureTask();

            CachedThreadPoolSingleton.getInstance().execute(futureTask);
            futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);
        }catch (Exception e){

            e.printStackTrace();
        }
        return resetSuccess;

    }
    //切到全网通
    public boolean isSetNet27() {

        boolean setNetSuccess = false;
        try {
            FutureTask<Boolean> setNetFutureTask = futureTaskUtils.setNetFutureTask(27);
            CachedThreadPoolSingleton.getInstance().execute(setNetFutureTask);
            setNetSuccess = setNetFutureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);
            LogUtil.print("isSetNet27:"+setNetSuccess);
       }catch (Exception e){

            e.printStackTrace();
        }
        return setNetSuccess;

    }

    public  IOdmSzControlService iservice;

    public ServiceConnection connection = new ServiceConnection() {

        public void onServiceConnected(ComponentName name, IBinder service) {
            iservice = IOdmSzControlService.Stub.asInterface(service);
        }

        public void onServiceDisconnected(ComponentName name) {
            iservice = null;
        }
    };

    public void startMCUHeartThreat(SerialPortActivity serialPortActivity) {
        if (mcuHeartThreat == null){
            mcuHeartThreat = new MCUHeartThreat(serialPortActivity);
            mcuHeartThreat.setName("mcuHeartThreat");

        }
        if (!mcuHeartThreat.isAlive()){
            mcuHeartThreat.start();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        WriteLogUtil.deleteFileBeforeSevenDays();
        gson = new Gson();
        heartBean = new HeartBean();
        devicesRemarkBean = new DevicesRemarkBean();
        businessDeal = new BusinessDeal();
        cpuTemperatureSB = new StringBuilder();
        batteryLevelSB = new StringBuilder();

        hexOperateFlagSB = new StringBuilder();
        batteryLevelSB = new StringBuilder();
        batteryTemperatureSB = new StringBuilder();
        cellIdentitys = new ArrayList<>();
        cellInfoBean = new CellInfoBean();
        byteArr = new ArrayList<>();

        pciSB = new StringBuffer();
        tacSB = new StringBuffer();
        eciSB = new StringBuffer();
        rssiSB = new StringBuffer();
        arfcnSB = new StringBuffer();
        sendToWebSB = new StringBuffer();

        baseReturnBean = new BaseReturnBean();
        sendCommandSB = new StringBuilder();
        mcuStrategy = new McuStrategy(this);
        atStrategy = new AtStrategy(this);
        strategyFactory = StrategyFactory.getInstance(this);
        weiChatActionBroadcastReceiver = new WeiChatActionBroadcastReceiver(strategyFactory.getAppStrategyWeiChat());
        futureTaskUtils = new FutureTaskUtils(this);

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, PERMISSIONS_STORAGE, REQUEST_CODE);
            }else {
                IpConfigUtil.createIPFile();
            }
        }

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.wxtools");
        registerReceiver(weiChatActionBroadcastReceiver, intentFilter);
        mApplication = new MyApplication();
        open4GSerialPort();
        bindODMSZServer();
        //注册监听广播
        IntentFilter odmszfilter = new IntentFilter();
        odmszfilter.addAction(TestControlReceiver.ODMSZ_SMS_RECEIVED);
        odmszfilter.addAction(TestControlReceiver.ODMSZ_MMS_RECEIVED);
        odmszfilter.addAction(TestControlReceiver.ODMSZ_MMS_SENT_ACTION);
        odmszfilter.addAction(TestControlReceiver.ODMSZ_USSD_SENT_ACTION);
        odmszfilter.addAction(TestControlReceiver.ODMSZ_CALL_RECEIVED);
        odmszfilter.addAction(TestControlReceiver.ODMSZ_CALL_ACTIVE);
        odmszfilter.addAction(Intent.ACTION_BATTERY_CHANGED);
        testControlReceiver = new TestControlReceiver(this);
        registerReceiver(testControlReceiver, odmszfilter);


        IntentFilter timeReceiverFilter = new IntentFilter();
        timeReceiverFilter.addAction(Intent.ACTION_TIME_TICK);
        TimeReceiver = new TimeReceiver(this);
        registerReceiver(TimeReceiver, timeReceiverFilter);

        initWakeLock();
        acquireWakeLock();

    }

    protected void onStart() {

        getVerName(context);
        super.onStart();
    }

    public void bindODMSZServer() {
        if(iservice == null){
            Intent service = new Intent(Constant.ACTION).setPackage(Constant.COM_ODMSZ_CONTROL);
            bindService(service, connection, BIND_AUTO_CREATE);
        }
    }

    public void open4GSerialPort(){
        if (mSerialPortWeb != null) {
            close4GSerialPort(false);
        }
        try {
            mSerialPortWeb = mApplication.getSerialPortWeb();
            bufferedOutputStream = mSerialPortWeb.getBufferedOutputStream();
            bufferedInputStream = mSerialPortWeb.getBufferedInputStream();

            //开启Read4GDataThread线程，读取串口回复数据
            startRead4GDataThread();
            startMCUHeartThreat(this);
            CachedThreadPoolSingleton.getInstance().execute(new Runnable() {
                @Override
                public void run() {

                    //循环判断ACTIVE_4G，当发送AT后收到串口回复，则说明串口已经准备完毕
                    while (!Constant.ACTIVE_4G){
                        try {
                            //此处等待，是为了不让模块启动后马上去发送指令，串口返回的数据可能会有问题
                            sleep(5000);
                            sendCommandTo4G(ATConstant.AT, bufferedOutputStream);
                            //此处等待，是为了发送AT后，不立即结束本次循环，留出时间设置Constant.ACTIVE_4G
                            sleep(2000);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }
            });
        } catch (Exception e) {
            close4GSerialPort(false);
            e.printStackTrace();
        }
    }

    //接收web后端的数据
    public abstract void onDataReceivedTcpIp(final String receiveWebData);

    @Override
    protected void onDestroy() {
        super.onDestroy();
        WriteLogUtil.d("__onDestroy","destroy");

        release();
    }

    public void release(){
        close4GSerialPort(false);

        if (weiChatActionBroadcastReceiver != null){
            unregisterReceiver(weiChatActionBroadcastReceiver);
        }

        if (testControlReceiver != null){
            unregisterReceiver(testControlReceiver);
        }

        if (TimeReceiver != null){
            unregisterReceiver(TimeReceiver);
        }

        if (resendCountDownTimer != null){
            resendCountDownTimer.cancel();
            resendCountDownTimer = null;
        }

        CachedThreadPoolSingleton.shutdown();
        unbindService(connection);
        strategyFactory.clear();
    }

    public void close4GSerialPort(boolean needOpenSerialPort){
        Constant.ACTIVE_4G = false;
        Constant.Interrupted_Need_Restart = false;
        if (mcuHeartThreat != null){
            mcuHeartThreat.interrupt();
            mcuHeartThreat = null;
        }
        atStrategy.stopThread();

        if (read4GDataThread != null){
            read4GDataThread.interrupt();
            read4GDataThread = null;

        }

        if (bufferedOutputStream != null){
            try {
                bufferedOutputStream.close();
                bufferedOutputStream = null;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (bufferedInputStream != null){
            try {
                bufferedInputStream.close();
                bufferedInputStream = null;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (mSerialPortWeb !=null){
            mSerialPortWeb.close();
            mSerialPortWeb = null;
        }

        if (needOpenSerialPort){
            open4GSerialPort();
        }
    }

    //给后台回复已经收到后台的数据 - 数据是正常的
    public synchronized void sendCommonReturnToWebSuccess(String infoCode,String packId) {
        baseReturnBean.setPackId(packId);
        baseReturnBean.setInfoCode(infoCode);
        baseReturnBean.setCode(Constant.CODE_SUCCESS);
        baseReturnBean.setMsg(Constant.MSG_SUCCESS);
        if (!TextUtils.isEmpty(heartBean.getDevCode())){
            baseReturnBean.setDevCode(heartBean.getDevCode());
        }
        add4GStr(gson.toJson(baseReturnBean),true,false);

    }
    //给后台回复已经收到后台的数据 - 数据是异常的
    public synchronized void sendCommonReturnToWebFail(String infoCode,String packId,String msg) {
        baseReturnBean.setPackId(packId);
        baseReturnBean.setInfoCode(infoCode);
        baseReturnBean.setCode(Constant.CODE_FAIL);
        baseReturnBean.setMsg(msg);
        if (!TextUtils.isEmpty(heartBean.getDevCode())){
            baseReturnBean.setDevCode(heartBean.getDevCode());
        }
        add4GStr(gson.toJson(baseReturnBean),true,false);

    }

    public void sendDataToWeb(WriteWebStrListBean writeWebStrListBean) {

        if (writeWebStrListBean.isSendToWeb()){
            SendingWebDataSingleton.INSTANCE.setSendingState(true);
            Utils.replaceSB(sendToWebSB,writeWebStrListBean.getStrContent(),"@");
            sendToWebStrLength = sendToWebSB.toString().getBytes().length;
            sendCommandTo4G(ATConstant.ATCIPSEND, bufferedOutputStream);

        }else {
            if (writeWebStrListBean.isHex()){
                if (writeWebStrListBean.isHexCommand()){
                    Constant.IS_MCU_COMMAND = true;
                }
                sendCommandTo4G(writeWebStrListBean.getByteArr(), bufferedOutputStream);
            }else {
                sendCommandTo4G(writeWebStrListBean.getStrContent(), bufferedOutputStream);

            }
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {


        if (requestCode == REQUEST_CODE) {
            boolean requestSuccess = true;
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    requestSuccess = false;
                    break;
                }
            }

            if (requestSuccess) {
                IpConfigUtil.createIPFile();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);


    }

    public synchronized void sendCommandTo4G(String sendStr, BufferedOutputStream bufferedOutputStream) {
        LogUtil.dd("__向串口写入数据",sendStr);

        try {
            if (bufferedOutputStream != null) {

                //排除MCU的数据，MCU数据独立判断，不需要根据AT_STEP_4G去判断
                if (!sendStr.contains(Constant.MCU_PRE)){

                    //存储当前指令作为执行步骤标志
                    Utils.replaceSB(Constant.AT_STEP_4G,sendStr);


                }
                Utils.replaceSB(sendCommandSB,sendStr);

                if (sendStr.equals(ATConstant.ATCIPSTART)){

                    try {
                        JSONObject jsonObject = new JSONObject(IpConfigUtil.ReadIPFile());
                        sendCommandSB.append("\"");
                        sendCommandSB.append(jsonObject.get("ip"));
                        sendCommandSB.append("\"");
                        sendCommandSB.append(",");
                        sendCommandSB.append(jsonObject.get("port"));
                        LogUtil.d("ATCIPSTART json:",jsonObject.toString());

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else if (sendStr.equals(ATConstant.ATCIPSEND)){
                    sendCommandSB.append(sendToWebStrLength);
                }

                sendCommandSB.append(ATConstant.RETURN);
                LogUtil.d("__sendCommandTo4G-1",sendCommandSB.toString());

                bufferedOutputStream.write(sendCommandSB.toString().getBytes());
                bufferedOutputStream.flush();


            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void sendCommandTo4G(byte[] byteArr, BufferedOutputStream bufferedOutputStream) {
        LogUtil.dd("__向串口写入数据",Arrays.toString(byteArr));

        try {
            if (bufferedOutputStream != null) {

                LogUtil.d("__sendCommandTo4GHex-2","sendStr = "+Arrays.toString(byteArr));
                bufferedOutputStream.write(byteArr);
                bufferedOutputStream.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    public void add4GStr(String sendTo4GStr,boolean sendToWeb,boolean releaseBusy) {

        if (releaseBusy){
            DeviceStateSingleton.INSTANCE.setDeviceState(false);
        }
        writeWebStrListBean = new WriteWebStrListBean(sendTo4GStr,sendToWeb,false,false);
        synchronizedList.add(writeWebStrListBean);


    }

    public void add4GStr(byte[] byteArr,boolean hexCommand) {
        writeWebStrListBean = new WriteWebStrListBean("",false,true,hexCommand,byteArr);
        //检测一遍待发送列表中是否有mcu心跳包数据，
        if (!hexCommand){ //如果添加的数据不是mcu指令心跳包（普通mcu心跳包）
            for (WriteWebStrListBean sendToWebStr : synchronizedList) {
                if (sendToWebStr.isHex() && !sendToWebStr.isHexCommand()){ //发送列表中已经存在mcu普通心跳包数据，则不再添加
                    return;
                }
            }
        }
        synchronizedList.add(writeWebStrListBean);

    }

    public synchronized CellInfoBean getCellInfo() {

        FutureTask<List<CellIdentity>> cellInfoTask = futureTaskUtils.getCellInfoFutureTask();

        CachedThreadPoolSingleton.getInstance().execute(cellInfoTask);



        try {
            cellIdentitys = (ArrayList<CellIdentity>) cellInfoTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
            return cellInfoBean;
        }

        if (cellIdentitys!=null){
            if(cellIdentitys.size() == 0){
                clearCellInfoSB();

                cellInfoBean.setPci(pciSB.toString());
                cellInfoBean.setTac(tacSB.toString());
                cellInfoBean.setArfcn(arfcnSB.toString());
                cellInfoBean.setEci(eciSB.toString());
                cellInfoBean.setRssi(rssiSB.toString());
                return cellInfoBean;
            }

            for (CellIdentity cellIdentity : cellIdentitys){

                clearCellInfoSB();

                if(cellIdentity instanceof CellIdentityGsm){

                    try {

                        JSONObject jsonObject = new JSONObject(cellIdentity.toString());
                        pciSB.append(jsonObject.get("mBsic"));
                        tacSB.append(jsonObject.get("mLac"));
                        arfcnSB.append(jsonObject.get("mArfcn"));
                        eciSB.append(jsonObject.get("mCid"));
                        rssiSB.append(jsonObject.get("mDbm"));
                        if (!TextUtils.isEmpty(pciSB.toString()) &&
                                !TextUtils.isEmpty(tacSB.toString()) &&
                                !TextUtils.isEmpty(arfcnSB.toString()) &&
                                !TextUtils.isEmpty(eciSB.toString()) &&
                                !TextUtils.isEmpty(rssiSB.toString()) ){
                            break;
                        }


                    }catch (Exception e){
                        e.printStackTrace();
                    }

                }
                else if(cellIdentity instanceof CellIdentityCdma){

                    try {

                        JSONObject jsonObject = new JSONObject(cellIdentity.toString());

                        pciSB.append(jsonObject.get("mBasestationId"));
                        tacSB.append(jsonObject.get("mSystemId"));
                        arfcnSB.append("283");
                        eciSB.append(jsonObject.get("mNetworkId"));
                        rssiSB.append(jsonObject.get("mDbm"));
                        if (!TextUtils.isEmpty(pciSB.toString()) &&
                                !TextUtils.isEmpty(tacSB.toString()) &&
                                !TextUtils.isEmpty(arfcnSB.toString()) &&
                                !TextUtils.isEmpty(eciSB.toString()) &&
                                !TextUtils.isEmpty(rssiSB.toString()) ){
                            break;
                        }

                    }catch (Exception e){
                        e.printStackTrace();
                    }

                }
                else if(cellIdentity instanceof CellIdentityWcdma){

                    try {

                        JSONObject jsonObject = new JSONObject(cellIdentity.toString());

                        pciSB.append(jsonObject.get("mPsc"));
                        tacSB.append(jsonObject.get("mLac"));
                        arfcnSB.append(jsonObject.get("mUarfcn"));
                        eciSB.append(jsonObject.get("mCid"));
                        rssiSB.append(jsonObject.get("mDbm"));
                        if (!TextUtils.isEmpty(pciSB.toString()) &&
                                !TextUtils.isEmpty(tacSB.toString()) &&
                                !TextUtils.isEmpty(arfcnSB.toString()) &&
                                !TextUtils.isEmpty(eciSB.toString()) &&
                                !TextUtils.isEmpty(rssiSB.toString()) ){
                            break;
                        }


                    }catch (Exception e){
                        e.printStackTrace();
                    }

                }
                else if(cellIdentity instanceof CellIdentityLte){
                    try {

                        JSONObject jsonObject = new JSONObject(cellIdentity.toString());

                        pciSB.append(jsonObject.get("mPci"));
                        tacSB.append(jsonObject.get("mTac"));
                        arfcnSB.append(jsonObject.get("mEarfcn"));
                        eciSB.append(jsonObject.get("mCi"));
                        rssiSB.append(jsonObject.get("mDbm"));
                        if (!TextUtils.isEmpty(pciSB.toString()) &&
                                !TextUtils.isEmpty(tacSB.toString()) &&
                                !TextUtils.isEmpty(arfcnSB.toString()) &&
                                !TextUtils.isEmpty(eciSB.toString()) &&
                                !TextUtils.isEmpty(rssiSB.toString()) ){
                            break;
                        }


                    }catch (Exception e){
                        e.printStackTrace();
                    }

                }
                else if(cellIdentity instanceof CellIdentityNr){
                    try {

                        JSONObject jsonObject = new JSONObject(cellIdentity.toString());

                        pciSB.append(jsonObject.get("mPci"));
                        tacSB.append(jsonObject.get("mTac"));
                        arfcnSB.append(jsonObject.get("mNrArfcn"));
                        eciSB.append(jsonObject.get("mNci"));
                        rssiSB.append(jsonObject.get("mDbm"));
                        if (!TextUtils.isEmpty(pciSB.toString()) &&
                                !TextUtils.isEmpty(tacSB.toString()) &&
                                !TextUtils.isEmpty(arfcnSB.toString()) &&
                                !TextUtils.isEmpty(eciSB.toString()) &&
                                !TextUtils.isEmpty(rssiSB.toString()) ){
                            break;
                        }

                    }catch (Exception e){
                        e.printStackTrace();
                    }

                }
            }
            cellInfoBean.setPci(pciSB.toString());
            cellInfoBean.setTac(tacSB.toString());
            cellInfoBean.setArfcn(arfcnSB.toString());
            cellInfoBean.setEci(eciSB.toString());
            cellInfoBean.setRssi(rssiSB.toString());
        }
        return cellInfoBean;
    }

    private void clearCellInfoSB() {
        Utils.clearSB(pciSB);
        Utils.clearSB(tacSB);
        Utils.clearSB(arfcnSB);
        Utils.clearSB(eciSB);
        Utils.clearSB(rssiSB);
    }

    public void setOperator(String operator){
        sendMcuData(true,Integer.parseInt(operator));

    }

    public void getDeviceInfo(){
        heartBean.setInfoCode(Constant.NO_HEART);
        add4GStr(ATConstant.AT_CGSN,false,false);

    }

    //给后台重传数据倒计时
    public CountDownTimer resendCountDownTimer;
    public void setResendCountDownTimer(){
        if (resendCountDownTimer != null){
            resendCountDownTimer.cancel();
            resendCountDownTimer.start();
            return;
        }

        resendCountDownTimer = new CountDownTimer(10000,1000){

            @Override
            public void onTick(long millisUntilFinished) {

                if (webHaveReceived){
                    cancel();
                }
            }

            @Override
            public void onFinish() {
                //倒计时结束，不再重发，逻辑跟重发成功一样
                webReceivedData(true);
            }
        }.start();
    }

    public void webReceivedData(boolean releaseBusy) {
        webHaveReceived = true;

        if (releaseBusy){
            DeviceStateSingleton.INSTANCE.setDeviceState(false);
        }
        if (resendCountDownTimer != null){
            resendCountDownTimer.cancel();
        }

    }

    public String getIccid(){
        String iccid = "";
        try {

            FutureTask<String> futureTask = futureTaskUtils.iccidFutureTask();

            CachedThreadPoolSingleton.getInstance().execute(futureTask);

            iccid = futureTask.get(Constant.TIMER_OUT, TimeUnit.SECONDS);
        }catch (Exception e){
            e.printStackTrace();
        }
        return iccid;
    }

    public void startRead4GDataThread() {
        if (read4GDataThread == null){
            read4GDataThread = new Read4GDataThread(SerialPortActivity.this);
            read4GDataThread.setName("read4GDataThread");

        }

        if (!read4GDataThread.isAlive()){
            read4GDataThread.start();

        }
    }

    /**
     * 初始化电源锁
     */
    @SuppressLint("InvalidWakeLockTag")
    private void initWakeLock() {
        mPowerManager = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
        mWakeLock = mPowerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK | PowerManager.ON_AFTER_RELEASE, "My Lock");
    }

    /**
     * 唤醒屏幕
     */
    private void acquireWakeLock() {
        if (mWakeLock != null) {
            LogUtil.d("acquireWakeLock");
            mWakeLock.acquire();
        }
    }

    /**
     * 熄灭屏幕
     */
    private void releaseWakeLock() {
        if (mWakeLock != null) {
            mWakeLock.release();
        }
    }
}
