/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: D:\\Android\\OdmSzTools\\src\\com\\odmsz\\control\\IOdmSzControlService.aidl
 */
package com.odmsz.control;
public interface IOdmSzControlService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements IOdmSzControlService
{
private static final String DESCRIPTOR = "com.odmsz.control.IOdmSzControlService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.odmsz.control.IOdmSzControlService interface,
 * generating a proxy if needed.
 */
public static IOdmSzControlService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof IOdmSzControlService))) {
return ((IOdmSzControlService)iin);
}
return new Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_initialize:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _result = this.initialize(_arg0);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getVersion:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _result = this.getVersion(_arg0);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_call:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _arg1;
_arg1 = data.readString();
boolean _result = this.call(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getPhoneType:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getPhoneType();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getCallForwarding:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
CallForwardingInfo _result = this.getCallForwarding(_arg0, _arg1);
reply.writeNoException();
if ((_result!=null)) {
reply.writeInt(1);
_result.writeToParcel(reply, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
}
else {
reply.writeInt(0);
}
return true;
}
case TRANSACTION_setCallForwarding:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
CallForwardingInfo _arg1;
if ((0!=data.readInt())) {
_arg1 = CallForwardingInfo.CREATOR.createFromParcel(data);
}
else {
_arg1 = null;
}
boolean _result = this.setCallForwarding(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getCallWaitingStatus:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _result = this.getCallWaitingStatus(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_setCallWaitingStatus:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _arg1;
_arg1 = (0!=data.readInt());
boolean _result = this.setCallWaitingStatus(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_isRinging:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _result = this.isRinging(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_isInCall:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _result = this.isInCall(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_silenceRinger:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _result = this.silenceRinger(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_endCall:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _result = this.endCall(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_acceptRingingCall:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _result = this.acceptRingingCall(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_sendTextMessage:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _arg1;
_arg1 = data.readString();
String _arg2;
_arg2 = data.readString();
String _arg3;
_arg3 = data.readString();
boolean _result = this.sendTextMessage(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getPreferredNetwork:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
int _result = this.getPreferredNetwork(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_setPreferredNetwork:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
int _arg2;
_arg2 = data.readInt();
boolean _result = this.setPreferredNetwork(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getAirPlaneModeStatus:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _result = this.getAirPlaneModeStatus(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_setAirPlaneMode:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _arg1;
_arg1 = (0!=data.readInt());
boolean _result = this.setAirPlaneMode(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getCellInfo:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
java.util.List<CellIdentity> _result = this.getCellInfo(_arg0);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_getSimState:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _result = this.getSimState(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_isDataRoamingEnabled:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _result = this.isDataRoamingEnabled(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_setDataRoamingEnabled:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _arg1;
_arg1 = (0!=data.readInt());
boolean _result = this.setDataRoamingEnabled(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getServiceState:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _result = this.getServiceState(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getServiceDomain:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _result = this.getServiceDomain(_arg0);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_readSms:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
long _arg1;
_arg1 = data.readLong();
boolean _arg2;
_arg2 = (0!=data.readInt());
int _arg3;
_arg3 = data.readInt();
boolean _result = this.readSms(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_readMms:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
long _arg1;
_arg1 = data.readLong();
boolean _arg2;
_arg2 = (0!=data.readInt());
int _arg3;
_arg3 = data.readInt();
boolean _result = this.readMms(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_updateMms:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
long _arg1;
_arg1 = data.readLong();
String _arg2;
_arg2 = data.readString();
this.updateMms(_arg0, _arg1, _arg2);
reply.writeNoException();
return true;
}
case TRANSACTION_updateSms:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
long _arg1;
_arg1 = data.readLong();
String _arg2;
_arg2 = data.readString();
this.updateSms(_arg0, _arg1, _arg2);
reply.writeNoException();
return true;
}
case TRANSACTION_playSound:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _arg1;
_arg1 = data.readString();
int _result = this.playSound(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_stopSound:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _result = this.stopSound(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_exeCmd:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _arg1;
_arg1 = data.readString();
String _result = this.exeCmd(_arg0, _arg1);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_sendMms:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _arg1;
_arg1 = data.readString();
String _arg2;
_arg2 = data.readString();
String _arg3;
_arg3 = data.readString();
String _arg4;
_arg4 = data.readString();
String _arg5;
_arg5 = data.readString();
boolean _result = this.sendMms(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_hold:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
int _result = this.hold(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_restartModem:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _result = this.restartModem(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_callForward:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _arg1;
_arg1 = data.readString();
int _result = this.callForward(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_sendUssdRequest:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _arg1;
_arg1 = data.readString();
this.sendUssdRequest(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_getCurrentImsi:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _result = this.getCurrentImsi(_arg0);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getCurrentPhoneNumber:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _result = this.getCurrentPhoneNumber(_arg0);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getCallState:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _result = this.getCallState(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_shutdown:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
boolean _arg1;
_arg1 = (0!=data.readInt());
this.shutdown(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_reboot:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
int _arg2;
_arg2 = data.readInt();
int _arg3;
_arg3 = data.readInt();
this.reboot(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
return true;
}
case TRANSACTION_getSmscAddress:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _result = this.getSmscAddress(_arg0);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_setSmscAddress:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _arg1;
_arg1 = data.readString();
boolean _result = this.setSmscAddress(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getIccid:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _result = this.getIccid(_arg0);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getCpuTemperature:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
String _result = this.getCpuTemperature(_arg0);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getBatteryLevel:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _result = this.getBatteryLevel(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getNetWorkState:
{
data.enforceInterface(DESCRIPTOR);
String _arg0;
_arg0 = data.readString();
int _result = this.getNetWorkState(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements IOdmSzControlService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**
     * aidl 初始校验,获取token
     * 废弃接口
     * @param 
     * String token 默认值"token"
     * @return
     * String  默认值 odmsz
     */
@Override public String initialize(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_initialize, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 获取当期OdmSzTools 版本号
     * @param 
     * String token,
     * @return
     * String version OdmSzTools版本号
     * */
@Override public String getVersion(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getVersion, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 拨打电话
     *
     * @param 
     * String token, 
     * String number
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean call(String token, String number) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeString(number);
mRemote.transact(Stub.TRANSACTION_call, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     *获取网络类型
     *@return
     *int NO_PHONE = 0;//无卡
     *int GSM_PHONE = 1;//G网
     *int CDMA_PHONE = 2;//C网
     *int SIP_PHONE  = 3;
     *int THIRD_PARTY_PHONE = 4;
     *int IMS_PHONE = 5;
     *int CDMA_LTE_PHONE = 6;
     */
@Override public int getPhoneType() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPhoneType, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 获取呼叫转移信息
     *
     * @param 
     * String token, 
     * String number
     * @return
     * CallForwardingInfo 呼叫转移信息实例
     */
@Override public CallForwardingInfo getCallForwarding(String token, int callForwardingReason) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
CallForwardingInfo _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeInt(callForwardingReason);
mRemote.transact(Stub.TRANSACTION_getCallForwarding, _data, _reply, 0);
_reply.readException();
if ((0!=_reply.readInt())) {
_result = CallForwardingInfo.CREATOR.createFromParcel(_reply);
}
else {
_result = null;
}
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 设置呼叫转移信息
     *
     * @param 
     * String token, 
     * CallForwardingInfo 呼叫转移信息实例
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean setCallForwarding(String token, CallForwardingInfo callForwardingInfo) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
if ((callForwardingInfo!=null)) {
_data.writeInt(1);
callForwardingInfo.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_setCallForwarding, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     *  获取呼叫等待状态
     *
     * @param 
     * String token, 
     * @return
     *int CALL_WAITING_STATUS_ACTIVE = 1; 
     *int CALL_WAITING_STATUS_INACTIVE = 2;
     *int CALL_WAITING_STATUS_UNKNOWN_ERROR = 3;
     *int CALL_WAITING_STATUS_NOT_SUPPORTED = 4;
     */
@Override public int getCallWaitingStatus(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getCallWaitingStatus, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 设置呼叫等待状态
     *
     * @param 
     * String token, 
     * boolean isEnable
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean setCallWaitingStatus(String token, boolean isEnable) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeInt(((isEnable)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_setCallWaitingStatus, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 是否来电中
     * incoming-call.
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean isRinging(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_isRinging, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * @param 
     * String token
     * 是否通话中
     * can be in dialing, ringing, active or holding
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean isInCall(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_isInCall, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 来电静音
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean silenceRinger(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_silenceRinger, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 挂断电话
     *
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean endCall(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_endCall, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 接听电话
     *
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean acceptRingingCall(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_acceptRingingCall, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 发送短信
     *
     * @param 
     * String token
     * String destinationAddress  对方的手机号
     * String scAddress 服务中心地址，为null的话就是默认的SMSC
     * String message  短信内容：文字，数字，字母
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean sendTextMessage(String token, String destinationAddress, String scAddress, String message) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeString(destinationAddress);
_data.writeString(scAddress);
_data.writeString(message);
mRemote.transact(Stub.TRANSACTION_sendTextMessage, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 获取网络模式
     *
     * @param 
     * String token
     * int slot 0表示卡1,1表示卡2
     * @return
     * int 参考RILConstants.java中对应的网络模式值
     * 若无卡，返回-2
     */
@Override public int getPreferredNetwork(String token, int slot) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeInt(slot);
mRemote.transact(Stub.TRANSACTION_getPreferredNetwork, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 设置网络模式
     *
     * @param 
     * String token
     * int slot 0表示卡1,1表示卡2
     * int 参考RILConstants.java中对应的网络模式值
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean setPreferredNetwork(String token, int slot, int networktype) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeInt(slot);
_data.writeInt(networktype);
mRemote.transact(Stub.TRANSACTION_setPreferredNetwork, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 设置网络模式
     *
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean getAirPlaneModeStatus(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getAirPlaneModeStatus, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 设置网络模式
     *
     * @param 
     * String token
     * Boolean  enable  true表示打开,false表示关闭
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean setAirPlaneMode(String token, boolean enable) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeInt(((enable)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_setAirPlaneMode, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
   	 * 获取小区信息列表
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
   	 */
@Override public java.util.List<CellIdentity> getCellInfo(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<CellIdentity> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getCellInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(CellIdentity.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
   	 * 获取sim卡状态
     * @param 
     * String token
     * @return
     * int simState ,参考RILConstants.java (SIM card state)
   	 */
@Override public int getSimState(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getSimState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 获取漫游状态
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean isDataRoamingEnabled(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_isDataRoamingEnabled, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 设置漫游状态
     * @param 
     * String token
     * boolean enable  true打开，false关闭
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean setDataRoamingEnabled(String token, boolean enable) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeInt(((enable)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_setDataRoamingEnabled, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * @param 
     * String token
     * @return
     * int 
     * #STATE_IN_SERVICE  0 
     * #STATE_OUT_OF_SERVICE 1
     * #STATE_EMERGENCY_ONLY  2 
     * #STATE_POWER_OFF  3
     *
     */
@Override public int getServiceState(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getServiceState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * @param 
     * String token
     * @return
     * String 
     * #STATE_IN_SERVICE  0 
     * #STATE_OUT_OF_SERVICE 1
     * #STATE_EMERGENCY_ONLY  2 
     * #STATE_POWER_OFF  3
     *
     */
@Override public String getServiceDomain(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getServiceDomain, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/*
     * 读短信
     * @param 
     * String token
     * long id 从mmssms.db获取_id
     * boolean 是否更改read 的类型 ，false表示不修改
     * int read 0表示未读 1表示已读
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean readSms(String token, long id, boolean update, int read) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeLong(id);
_data.writeInt(((update)?(1):(0)));
_data.writeInt(read);
mRemote.transact(Stub.TRANSACTION_readSms, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/*
     * 读彩信
     * @param 
     * String token
     * long id 从mmssms.db获取_id
     * boolean 是否更改read 的类型 ，false表示不修改
     * String read 0表示未读 1表示已读
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
@Override public boolean readMms(String token, long id, boolean update, int read) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeLong(id);
_data.writeInt(((update)?(1):(0)));
_data.writeInt(read);
mRemote.transact(Stub.TRANSACTION_readMms, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public void updateMms(String token, long id, String read) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeLong(id);
_data.writeString(read);
mRemote.transact(Stub.TRANSACTION_updateMms, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void updateSms(String token, long id, String read) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeLong(id);
_data.writeString(read);
mRemote.transact(Stub.TRANSACTION_updateSms, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 *播放声音
     * @param 
     * String token
     * String file 声音名称
     * @return
     * int 0 播放结束，1 播放失败，-1 播放报错,-2未通话时执行了播放声音api
     * 注：播放声音接口会阻塞，UI需要新建线程处理
	 */
@Override public int playSound(String token, String file) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeString(file);
mRemote.transact(Stub.TRANSACTION_playSound, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 *停止播放
     * @param 
     * String token
     * @return
     *  int 1 停止播放成功 ，-1 停止失败
	 */
@Override public int stopSound(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_stopSound, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 * 执行指令
     * @param 
     * String token
     * @return
     *  String 指令响应结果
	 */
@Override public String exeCmd(String token, String cmd) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeString(cmd);
mRemote.transact(Stub.TRANSACTION_exeCmd, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 * 发送彩信
     * @param 
     * String token
     * String phone 目标号码
     * String subject 彩信主题
     * String text 文字内容
     * String imagePath 图片内容路径 eg: /sdcard/1.jpg;
     * String opath 预留参数，eg: null
     * @return
     *  boolean  接口无异常返回true,有异常返回false
	 */
@Override public boolean sendMms(String token, String phone, String subject, String text, String imagePath, String opath) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeString(phone);
_data.writeString(subject);
_data.writeString(text);
_data.writeString(imagePath);
_data.writeString(opath);
mRemote.transact(Stub.TRANSACTION_sendMms, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 *hold
	 *@param
	 *String token
	 *int  1 hold 2 unhold
	 *@return
	 *int 
	 */
@Override public int hold(String token, int hold) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeInt(hold);
mRemote.transact(Stub.TRANSACTION_hold, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean restartModem(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_restartModem, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int callForward(String token, String forwardNumber) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeString(forwardNumber);
mRemote.transact(Stub.TRANSACTION_callForward, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public void sendUssdRequest(String token, String number) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeString(number);
mRemote.transact(Stub.TRANSACTION_sendUssdRequest, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * 获取当前imsi
     * @param 
     * String token
     * @return
     *  String 响应结果
	 */
@Override public String getCurrentImsi(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getCurrentImsi, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 * 获取当前手机号
     * @param 
     * String token
     * @return
     *  String 响应结果
	 */
@Override public String getCurrentPhoneNumber(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getCurrentPhoneNumber, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 * 获取卡通话状态
     * @param 
     * String token 
     * @return
     *  int 响应结果
	 */
@Override public int getCallState(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getCallState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 *关机
     * @param 
     * String token 
     * Boolean tag false 不显示，true显示弹窗
	 */
@Override public void shutdown(String token, boolean tag) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeInt(((tag)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_shutdown, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 *重启
     * @param 
     * String token 
     * int nowait 1
     * int interval 1
     * int window 0
	 */
@Override public void reboot(String token, int nowait, int interval, int window) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeInt(nowait);
_data.writeInt(interval);
_data.writeInt(window);
mRemote.transact(Stub.TRANSACTION_reboot, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 *获取短信中心号码
     * @param 
     * String token 
     * @return
     *  String 响应结果
	 */
@Override public String getSmscAddress(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getSmscAddress, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 *设置短信中心号码
     * @param 
     * String token 
     * String smscAddress
     * @return
     *  boolean 响应结果
	 */
@Override public boolean setSmscAddress(String token, String smscAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
_data.writeString(smscAddress);
mRemote.transact(Stub.TRANSACTION_setSmscAddress, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 *获取当前iccid
     * @param 
     * String token 
     * @return
     *  String 响应结果
	 */
@Override public String getIccid(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getIccid, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 *获取当前cpu温度
     * @param 
     * String token 
     * @return
     *  String 响应结果
	 */
@Override public String getCpuTemperature(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getCpuTemperature, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 *获取当前电池电量
     * @param 
     * String token 
     * @return
     *  int currentLevel
   	 */
@Override public int getBatteryLevel(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getBatteryLevel, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
	 * 获取当前网络状态
	 */
@Override public int getNetWorkState(String token) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(token);
mRemote.transact(Stub.TRANSACTION_getNetWorkState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_initialize = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_getVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_call = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_getPhoneType = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_getCallForwarding = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_setCallForwarding = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_getCallWaitingStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_setCallWaitingStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_isRinging = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_isInCall = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_silenceRinger = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_endCall = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_acceptRingingCall = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_sendTextMessage = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
static final int TRANSACTION_getPreferredNetwork = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
static final int TRANSACTION_setPreferredNetwork = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
static final int TRANSACTION_getAirPlaneModeStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
static final int TRANSACTION_setAirPlaneMode = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
static final int TRANSACTION_getCellInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
static final int TRANSACTION_getSimState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
static final int TRANSACTION_isDataRoamingEnabled = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
static final int TRANSACTION_setDataRoamingEnabled = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
static final int TRANSACTION_getServiceState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
static final int TRANSACTION_getServiceDomain = (android.os.IBinder.FIRST_CALL_TRANSACTION + 23);
static final int TRANSACTION_readSms = (android.os.IBinder.FIRST_CALL_TRANSACTION + 24);
static final int TRANSACTION_readMms = (android.os.IBinder.FIRST_CALL_TRANSACTION + 25);
static final int TRANSACTION_updateMms = (android.os.IBinder.FIRST_CALL_TRANSACTION + 26);
static final int TRANSACTION_updateSms = (android.os.IBinder.FIRST_CALL_TRANSACTION + 27);
static final int TRANSACTION_playSound = (android.os.IBinder.FIRST_CALL_TRANSACTION + 28);
static final int TRANSACTION_stopSound = (android.os.IBinder.FIRST_CALL_TRANSACTION + 29);
static final int TRANSACTION_exeCmd = (android.os.IBinder.FIRST_CALL_TRANSACTION + 30);
static final int TRANSACTION_sendMms = (android.os.IBinder.FIRST_CALL_TRANSACTION + 31);
static final int TRANSACTION_hold = (android.os.IBinder.FIRST_CALL_TRANSACTION + 32);
static final int TRANSACTION_restartModem = (android.os.IBinder.FIRST_CALL_TRANSACTION + 33);
static final int TRANSACTION_callForward = (android.os.IBinder.FIRST_CALL_TRANSACTION + 34);
static final int TRANSACTION_sendUssdRequest = (android.os.IBinder.FIRST_CALL_TRANSACTION + 35);
static final int TRANSACTION_getCurrentImsi = (android.os.IBinder.FIRST_CALL_TRANSACTION + 36);
static final int TRANSACTION_getCurrentPhoneNumber = (android.os.IBinder.FIRST_CALL_TRANSACTION + 37);
static final int TRANSACTION_getCallState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 38);
static final int TRANSACTION_shutdown = (android.os.IBinder.FIRST_CALL_TRANSACTION + 39);
static final int TRANSACTION_reboot = (android.os.IBinder.FIRST_CALL_TRANSACTION + 40);
static final int TRANSACTION_getSmscAddress = (android.os.IBinder.FIRST_CALL_TRANSACTION + 41);
static final int TRANSACTION_setSmscAddress = (android.os.IBinder.FIRST_CALL_TRANSACTION + 42);
static final int TRANSACTION_getIccid = (android.os.IBinder.FIRST_CALL_TRANSACTION + 43);
static final int TRANSACTION_getCpuTemperature = (android.os.IBinder.FIRST_CALL_TRANSACTION + 44);
static final int TRANSACTION_getBatteryLevel = (android.os.IBinder.FIRST_CALL_TRANSACTION + 45);
static final int TRANSACTION_getNetWorkState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 46);
}
/**
     * aidl 初始校验,获取token
     * 废弃接口
     * @param 
     * String token 默认值"token"
     * @return
     * String  默认值 odmsz
     */
public String initialize(String token) throws android.os.RemoteException;
/**
     * 获取当期OdmSzTools 版本号
     * @param 
     * String token,
     * @return
     * String version OdmSzTools版本号
     * */
public String getVersion(String token) throws android.os.RemoteException;
/**
     * 拨打电话
     *
     * @param 
     * String token, 
     * String number
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean call(String token, String number) throws android.os.RemoteException;
/**
     *获取网络类型
     *@return
     *int NO_PHONE = 0;//无卡
     *int GSM_PHONE = 1;//G网
     *int CDMA_PHONE = 2;//C网
     *int SIP_PHONE  = 3;
     *int THIRD_PARTY_PHONE = 4;
     *int IMS_PHONE = 5;
     *int CDMA_LTE_PHONE = 6;
     */
public int getPhoneType() throws android.os.RemoteException;
/**
     * 获取呼叫转移信息
     *
     * @param 
     * String token, 
     * String number
     * @return
     * CallForwardingInfo 呼叫转移信息实例
     */
public CallForwardingInfo getCallForwarding(String token, int callForwardingReason) throws android.os.RemoteException;
/**
     * 设置呼叫转移信息
     *
     * @param 
     * String token, 
     * CallForwardingInfo 呼叫转移信息实例
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean setCallForwarding(String token, CallForwardingInfo callForwardingInfo) throws android.os.RemoteException;
/**
     *  获取呼叫等待状态
     *
     * @param 
     * String token, 
     * @return
     *int CALL_WAITING_STATUS_ACTIVE = 1; 
     *int CALL_WAITING_STATUS_INACTIVE = 2;
     *int CALL_WAITING_STATUS_UNKNOWN_ERROR = 3;
     *int CALL_WAITING_STATUS_NOT_SUPPORTED = 4;
     */
public int getCallWaitingStatus(String token) throws android.os.RemoteException;
/**
     * 设置呼叫等待状态
     *
     * @param 
     * String token, 
     * boolean isEnable
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean setCallWaitingStatus(String token, boolean isEnable) throws android.os.RemoteException;
/**
     * 是否来电中
     * incoming-call.
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean isRinging(String token) throws android.os.RemoteException;
/**
     * @param 
     * String token
     * 是否通话中
     * can be in dialing, ringing, active or holding
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean isInCall(String token) throws android.os.RemoteException;
/**
     * 来电静音
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean silenceRinger(String token) throws android.os.RemoteException;
/**
     * 挂断电话
     *
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean endCall(String token) throws android.os.RemoteException;
/**
     * 接听电话
     *
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean acceptRingingCall(String token) throws android.os.RemoteException;
/**
     * 发送短信
     *
     * @param 
     * String token
     * String destinationAddress  对方的手机号
     * String scAddress 服务中心地址，为null的话就是默认的SMSC
     * String message  短信内容：文字，数字，字母
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean sendTextMessage(String token, String destinationAddress, String scAddress, String message) throws android.os.RemoteException;
/**
     * 获取网络模式
     *
     * @param 
     * String token
     * int slot 0表示卡1,1表示卡2
     * @return
     * int 参考RILConstants.java中对应的网络模式值
     * 若无卡，返回-2
     */
public int getPreferredNetwork(String token, int slot) throws android.os.RemoteException;
/**
     * 设置网络模式
     *
     * @param 
     * String token
     * int slot 0表示卡1,1表示卡2
     * int 参考RILConstants.java中对应的网络模式值
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean setPreferredNetwork(String token, int slot, int networktype) throws android.os.RemoteException;
/**
     * 设置网络模式
     *
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean getAirPlaneModeStatus(String token) throws android.os.RemoteException;
/**
     * 设置网络模式
     *
     * @param 
     * String token
     * Boolean  enable  true表示打开,false表示关闭
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean setAirPlaneMode(String token, boolean enable) throws android.os.RemoteException;
/**
   	 * 获取小区信息列表
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
   	 */
public java.util.List<CellIdentity> getCellInfo(String token) throws android.os.RemoteException;
/**
   	 * 获取sim卡状态
     * @param 
     * String token
     * @return
     * int simState ,参考RILConstants.java (SIM card state)
   	 */
public int getSimState(String token) throws android.os.RemoteException;
/**
     * 获取漫游状态
     * @param 
     * String token
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean isDataRoamingEnabled(String token) throws android.os.RemoteException;
/**
     * 设置漫游状态
     * @param 
     * String token
     * boolean enable  true打开，false关闭
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean setDataRoamingEnabled(String token, boolean enable) throws android.os.RemoteException;
/**
     * @param 
     * String token
     * @return
     * int 
     * #STATE_IN_SERVICE  0 
     * #STATE_OUT_OF_SERVICE 1
     * #STATE_EMERGENCY_ONLY  2 
     * #STATE_POWER_OFF  3
     *
     */
public int getServiceState(String token) throws android.os.RemoteException;
/**
     * @param 
     * String token
     * @return
     * String 
     * #STATE_IN_SERVICE  0 
     * #STATE_OUT_OF_SERVICE 1
     * #STATE_EMERGENCY_ONLY  2 
     * #STATE_POWER_OFF  3
     *
     */
public String getServiceDomain(String token) throws android.os.RemoteException;
/*
     * 读短信
     * @param 
     * String token
     * long id 从mmssms.db获取_id
     * boolean 是否更改read 的类型 ，false表示不修改
     * int read 0表示未读 1表示已读
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean readSms(String token, long id, boolean update, int read) throws android.os.RemoteException;
/*
     * 读彩信
     * @param 
     * String token
     * long id 从mmssms.db获取_id
     * boolean 是否更改read 的类型 ，false表示不修改
     * String read 0表示未读 1表示已读
     * @return
     * boolean 接口无异常返回true,有异常返回false
     */
public boolean readMms(String token, long id, boolean update, int read) throws android.os.RemoteException;
public void updateMms(String token, long id, String read) throws android.os.RemoteException;
public void updateSms(String token, long id, String read) throws android.os.RemoteException;
/**
	 *播放声音
     * @param 
     * String token
     * String file 声音名称
     * @return
     * int 0 播放结束，1 播放失败，-1 播放报错,-2未通话时执行了播放声音api
     * 注：播放声音接口会阻塞，UI需要新建线程处理
	 */
public int playSound(String token, String file) throws android.os.RemoteException;
/**
	 *停止播放
     * @param 
     * String token
     * @return
     *  int 1 停止播放成功 ，-1 停止失败
	 */
public int stopSound(String token) throws android.os.RemoteException;
/**
	 * 执行指令
     * @param 
     * String token
     * @return
     *  String 指令响应结果
	 */
public String exeCmd(String token, String cmd) throws android.os.RemoteException;
/**
	 * 发送彩信
     * @param 
     * String token
     * String phone 目标号码
     * String subject 彩信主题
     * String text 文字内容
     * String imagePath 图片内容路径 eg: /sdcard/1.jpg;
     * String opath 预留参数，eg: null
     * @return
     *  boolean  接口无异常返回true,有异常返回false
	 */
public boolean sendMms(String token, String phone, String subject, String text, String imagePath, String opath) throws android.os.RemoteException;
/**
	 *hold
	 *@param
	 *String token
	 *int  1 hold 2 unhold
	 *@return
	 *int 
	 */
public int hold(String token, int hold) throws android.os.RemoteException;
public boolean restartModem(String token) throws android.os.RemoteException;
public int callForward(String token, String forwardNumber) throws android.os.RemoteException;
public void sendUssdRequest(String token, String number) throws android.os.RemoteException;
/**
	 * 获取当前imsi
     * @param 
     * String token
     * @return
     *  String 响应结果
	 */
public String getCurrentImsi(String token) throws android.os.RemoteException;
/**
	 * 获取当前手机号
     * @param 
     * String token
     * @return
     *  String 响应结果
	 */
public String getCurrentPhoneNumber(String token) throws android.os.RemoteException;
/**
	 * 获取卡通话状态
     * @param 
     * String token 
     * @return
     *  int 响应结果
	 */
public int getCallState(String token) throws android.os.RemoteException;
/**
	 *关机
     * @param 
     * String token 
     * Boolean tag false 不显示，true显示弹窗
	 */
public void shutdown(String token, boolean tag) throws android.os.RemoteException;
/**
	 *重启
     * @param 
     * String token 
     * int nowait 1
     * int interval 1
     * int window 0
	 */
public void reboot(String token, int nowait, int interval, int window) throws android.os.RemoteException;
/**
	 *获取短信中心号码
     * @param 
     * String token 
     * @return
     *  String 响应结果
	 */
public String getSmscAddress(String token) throws android.os.RemoteException;
/**
	 *设置短信中心号码
     * @param 
     * String token 
     * String smscAddress
     * @return
     *  boolean 响应结果
	 */
public boolean setSmscAddress(String token, String smscAddress) throws android.os.RemoteException;
/**
	 *获取当前iccid
     * @param 
     * String token 
     * @return
     *  String 响应结果
	 */
public String getIccid(String token) throws android.os.RemoteException;
/**
	 *获取当前cpu温度
     * @param 
     * String token 
     * @return
     *  String 响应结果
	 */
public String getCpuTemperature(String token) throws android.os.RemoteException;
/**
	 *获取当前电池电量
     * @param 
     * String token 
     * @return
     *  int currentLevel
   	 */
public int getBatteryLevel(String token) throws android.os.RemoteException;
/**
	 * 获取当前网络状态
	 */
public int getNetWorkState(String token) throws android.os.RemoteException;
}
