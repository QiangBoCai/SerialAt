/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.odmsz.control;

import android.os.Parcel;
import android.telephony.gsm.GsmCellLocation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * CellIdentity is to represent a unique LTE cell
 */
public final class CellIdentityLte extends CellIdentity {
    private static final String TAG = CellIdentityLte.class.getSimpleName();
    private static final boolean DBG = false;

    private static final int MAX_CI = 268435455;
    private static final int MAX_PCI = 503;
    private static final int MAX_TAC = 65535;
    private static final int MAX_EARFCN = 262143;
    private static final int MAX_BANDWIDTH = 20000;

    // 28-bit cell identity
    private final int mCi;
    // physical cell id 0..503
    private final int mPci;
    // 16-bit tracking area code
    private final int mTac;
    // 18-bit Absolute RF Channel Number
    private final int mEarfcn;
    // cell bandwidth, in kHz
    private final int mBandwidth;
    // cell bands
    private final int[] mBands;

    // a list of additional PLMN-IDs reported for this cell
    private final List<String> mAdditionalPlmns;

//    private ClosedSubscriberGroupInfo mCsgInfo;
    
    /**
     * Indicates whether the cell is restricted to only CSG members.
     *
     * A cell not broadcasting the CSG Indication but reporting CSG information is considered a
     * Hybrid Cell.
     * Refer to the "csg-Indication" field in 3GPP TS 36.331 section 6.2.2
     * SystemInformationBlockType1.
     * Also refer to "CSG Indicator" in 3GPP TS 25.331 section 10.2.48.8.1 and TS 25.304.
     *
     */
    private final boolean mCsgIndicator;

    /**
     * Returns human-readable name of the closed subscriber group operating this cell (Node-B).
     *
     * Refer to "hnb-Name" in TS 36.331 section 6.2.2 SystemInformationBlockType9.
     * Also refer to "HNB Name" in 3GPP TS25.331 section 10.2.48.8.23 and TS 23.003 section 4.8.
     *
     */

    private final String mHomeNodebName;

    /* The identity of the closed subscriber group that the cell belongs to.
    *
    * Refer to "CSG-Identity" in TS 36.336 section 6.3.4.
    * Also refer to "CSG Identity" in 3GPP TS 25.331 section 10.3.2.8 and TS 23.003 section 4.7.
	*/
    private final int mCsgIdentity;

    protected int mDbm;
//    /**
//     * @hide
//     */
//    public CellIdentityLte() {
//        super(TAG, CellInfo.TYPE_LTE, null, null, null, null,CellInfo.UNAVAILABLE);
//        mCi = CellInfo.UNAVAILABLE;
//        mPci = CellInfo.UNAVAILABLE;
//        mTac = CellInfo.UNAVAILABLE;
//        mEarfcn = CellInfo.UNAVAILABLE;
//        mBands = new int[] {};
//        mBandwidth = CellInfo.UNAVAILABLE;
//        mAdditionalPlmns = new ArrayList<>();
//        mCsgInfo = null;
//        mGlobalCellId = null;
//    }

    /**
     *
     * @param mcc 3-digit Mobile Country Code, 0..999
     * @param mnc 2 or 3-digit Mobile Network Code, 0..999
     * @param ci 28-bit Cell Identity
     * @param pci Physical Cell Id 0..503
     * @param tac 16-bit Tracking Area Code
     *
     * @hide
     */
//    public CellIdentityLte(int mcc, int mnc, int ci, int pci, int tac) {
//        this(ci, pci, tac, CellInfo.UNAVAILABLE, new int[] {}, CellInfo.UNAVAILABLE,
//                String.valueOf(mcc), String.valueOf(mnc), null, null, new ArrayList<>(),
//                null);
//    }

    /**
     *
     * @param ci 28-bit Cell Identity
     * @param pci Physical Cell Id 0..503
     * @param tac 16-bit Tracking Area Code
     * @param earfcn 18-bit LTE Absolute RF Channel Number
     * @param bandwidth cell bandwidth in kHz
     * @param mccStr 3-digit Mobile Country Code in string format
     * @param mncStr 2 or 3-digit Mobile Network Code in string format
     * @param alphal long alpha Operator Name String or Enhanced Operator Name String
     * @param alphas short alpha Operator Name String or Enhanced Operator Name String
     * @param additionalPlmns a list of additional PLMN IDs broadcast by the cell
     *
     * @hide
     */
    public CellIdentityLte(int ci, int pci, int tac, int earfcn,  int[] bands,
            int bandwidth,  String mccStr,  String mncStr,
             String alphal,  String alphas,
             Collection<String> additionalPlmns,
             boolean csgIndicator,String homeNodebName,int csgIdentity,int dbm){
//             ClosedSubscriberGroupInfo csgInfo) {
        super(TAG, CellInfo.TYPE_LTE, mccStr, mncStr, alphal, alphas);
        mCi = inRangeOrUnavailable(ci, 0, MAX_CI);
        mPci = inRangeOrUnavailable(pci, 0, MAX_PCI);
        mTac = inRangeOrUnavailable(tac, 0, MAX_TAC);
        mEarfcn = inRangeOrUnavailable(earfcn, 0, MAX_EARFCN);
        mBands = bands;
        mBandwidth = inRangeOrUnavailable(bandwidth, 0, MAX_BANDWIDTH);
        mAdditionalPlmns = new ArrayList<>(additionalPlmns.size());
        for (String plmn : additionalPlmns) {
            if (isValidPlmn(plmn)) {
                mAdditionalPlmns.add(plmn);
            }
        }
        mCsgIndicator = csgIndicator;
        mHomeNodebName = homeNodebName;
        mCsgIdentity = csgIdentity;
        mDbm = dbm;
        updateGlobalCellId();
    }

    private CellIdentityLte(CellIdentityLte cid) {
        this(cid.mCi, cid.mPci, cid.mTac, cid.mEarfcn, cid.mBands, cid.mBandwidth, cid.mMccStr,
                cid.mMncStr, cid.mAlphaLong, cid.mAlphaShort, cid.mAdditionalPlmns,
        		cid.mCsgIndicator,cid.mHomeNodebName,cid.mCsgIdentity,cid.mDbm);
    }

    /** @hide */
    @Override
    public CellIdentityLte sanitizeLocationInfo() {
        return new CellIdentityLte(CellInfo.UNAVAILABLE, CellInfo.UNAVAILABLE, CellInfo.UNAVAILABLE,
                CellInfo.UNAVAILABLE, mBands, CellInfo.UNAVAILABLE,
                mMccStr, mMncStr, mAlphaLong, mAlphaShort, mAdditionalPlmns,mCsgIndicator,mHomeNodebName,mCsgIdentity,mDbm);
    }

    CellIdentityLte copy() {
        return new CellIdentityLte(this);
    }

    /** @hide */
    @Override
    protected void updateGlobalCellId() {
        mGlobalCellId = null;
        String plmn = getPlmn();
        if (plmn == null) return;

        if (mCi == CellInfo.UNAVAILABLE) return;

        mGlobalCellId = plmn + String.format("%07x", mCi);
    }

    /**
     * @return 3-digit Mobile Country Code, 0..999,
     *         {@link android.telephony.CellInfo#UNAVAILABLE UNAVAILABLE} if unavailable.
     * @deprecated Use {@link #getMccString} instead.
     */
    @Deprecated
    public int getMcc() {
        return (mMccStr != null) ? Integer.parseInt(mMccStr) : CellInfo.UNAVAILABLE;
    }

    /**
     * @return 2 or 3-digit Mobile Network Code, 0..999,
     *         {@link android.telephony.CellInfo#UNAVAILABLE UNAVAILABLE} if unavailable.
     * @deprecated Use {@link #getMncString} instead.
     */
    @Deprecated
    public int getMnc() {
        return (mMncStr != null) ? Integer.parseInt(mMncStr) : CellInfo.UNAVAILABLE;
    }

    /**
     * @return 28-bit Cell Identity,
     *         {@link android.telephony.CellInfo#UNAVAILABLE UNAVAILABLE} if unavailable.
     */
    public int getCi() {
        return mCi;
    }

    /**
     * @return Physical Cell Id 0..503,
     *         {@link android.telephony.CellInfo#UNAVAILABLE UNAVAILABLE} if unavailable.
     */
    public int getPci() {
        return mPci;
    }

    /**
     * @return 16-bit Tracking Area Code,
     *         {@link android.telephony.CellInfo#UNAVAILABLE UNAVAILABLE} if unavailable.
     */
    public int getTac() {
        return mTac;
    }

    /**
     * @return 18-bit Absolute RF Channel Number,
     *         {@link android.telephony.CellInfo#UNAVAILABLE UNAVAILABLE} if unavailable.
     */
    public int getEarfcn() {
        return mEarfcn;
    }

    public int getmDbm() {
		return mDbm;
	}


	/**
     * Get bands of the cell
     *
     * Reference: 3GPP TS 36.101 section 5.5
     *
     * @return Array of band number or empty array if not available.
     */
    public int[] getBands() {
        return Arrays.copyOf(mBands, mBands.length);
    }

    /**
     * @return Cell bandwidth in kHz,
     *         {@link android.telephony.CellInfo#UNAVAILABLE UNAVAILABLE} if unavailable.
     */
    public int getBandwidth() {
        return mBandwidth;
    }

    /**
     * @return Mobile Country Code in string format, null if unavailable.
     */
    public String getMccString() {
        return mMccStr;
    }

    /**
     * @return Mobile Network Code in string format, null if unavailable.
     */
    public String getMncString() {
        return mMncStr;
    }

    /**
     * @return a 5 or 6 character string (MCC+MNC), null if any field is unknown.
     */
    public String getMobileNetworkOperator() {
        return (mMccStr == null || mMncStr == null) ? null : mMccStr + mMncStr;
    }

    /** @hide */
    @Override
    public int getChannelNumber() {
        return mEarfcn;
    }


    /**
     * A hack to allow tunneling of LTE information via GsmCellLocation
     * so that older Network Location Providers can return some information
     * on LTE only networks, see bug 9228974.
     *
     * The tunnel'd LTE information is returned as follows:
     *   LAC = TAC field
     *   CID = CI field
     *   PSC = 0.
     *
     * @hide
     */
    @Override
    public GsmCellLocation asCellLocation() {
        GsmCellLocation cl = new GsmCellLocation();
        int tac = mTac != CellInfo.UNAVAILABLE ? mTac : -1;
        int cid = mCi != CellInfo.UNAVAILABLE ? mCi : -1;
        cl.setLacAndCid(tac, cid);
        return cl;
    }


    @Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((mAdditionalPlmns == null) ? 0 : mAdditionalPlmns.hashCode());
		result = prime * result + Arrays.hashCode(mBands);
		result = prime * result + mBandwidth;
		result = prime * result + mCi;
		result = prime * result + mCsgIdentity;
		result = prime * result + (mCsgIndicator ? 1231 : 1237);
		result = prime * result + mDbm;
		result = prime * result + mEarfcn;
		result = prime * result
				+ ((mHomeNodebName == null) ? 0 : mHomeNodebName.hashCode());
		result = prime * result + mPci;
		result = prime * result + mTac;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CellIdentityLte other = (CellIdentityLte) obj;
		if (mAdditionalPlmns == null) {
			if (other.mAdditionalPlmns != null)
				return false;
		} else if (!mAdditionalPlmns.equals(other.mAdditionalPlmns))
			return false;
		if (!Arrays.equals(mBands, other.mBands))
			return false;
		if (mBandwidth != other.mBandwidth)
			return false;
		if (mCi != other.mCi)
			return false;
		if (mCsgIdentity != other.mCsgIdentity)
			return false;
		if (mCsgIndicator != other.mCsgIndicator)
			return false;
		if (mDbm != other.mDbm)
			return false;
		if (mEarfcn != other.mEarfcn)
			return false;
		if (mHomeNodebName == null) {
			if (other.mHomeNodebName != null)
				return false;
		} else if (!mHomeNodebName.equals(other.mHomeNodebName))
			return false;
		if (mPci != other.mPci)
			return false;
		if (mTac != other.mTac)
			return false;
		return true;
	}

	@Override
    public String toString() {
        return new StringBuilder("{")
                // eci
                .append("\"mCi\":\"").append(mCi).append("\"").append(",")
                // pci
                .append("\"mPci\":\"").append(mPci).append("\"").append(",")
                // tac
                .append("\"mTac\":\"").append(mTac).append("\"").append(",")
                // arfcn
                .append("\"mEarfcn\":\"").append(mEarfcn).append("\"").append(",")
                .append("\"mBands\":\"").append(Arrays.toString(mBands)).append("\"").append(",")
                .append("\"mBandwidth\":\"").append(mBandwidth).append("\"").append(",")
                .append("\"mMcc\":\"").append(mMccStr).append("\"").append(",")
                .append("\"mMnc\":\"").append(mMncStr).append("\"").append(",")
                .append("\"mAlphaLong\":\"").append(mAlphaLong).append("\"").append(",")
                .append("\"mAlphaShort\":\"").append(mAlphaShort).append("\"").append(",")
                .append("\"mAdditionalPlmns\":\"").append(mAdditionalPlmns).append("\"").append(",")
                .append("\"mCsgIndicator\":\"").append(mCsgIndicator).append("\"").append(",")
                .append("\"mHomeNodebName\":\"").append(mHomeNodebName).append("\"").append(",")
                .append("\"mCsgIdentity\":\"").append(mCsgIdentity).append("\"").append(",")
                // rssi
                .append("\"mDbm\":\"").append(mDbm).append("\"")
                .append("}").toString();
    }

	
	/** Implement the Parcelable interface */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (DBG) log("writeToParcel(Parcel, int): ");
        super.writeToParcel(dest, CellInfo.TYPE_LTE);
        dest.writeInt(mCi);
        dest.writeInt(mPci);
        dest.writeInt(mTac);
        dest.writeInt(mEarfcn);
        dest.writeIntArray(mBands);
        dest.writeInt(mBandwidth);
        dest.writeList(mAdditionalPlmns);
        dest.writeByte((byte) (mCsgIndicator ? 1 : 0));
        dest.writeString(mHomeNodebName);
        dest.writeInt(mCsgIdentity);
        dest.writeInt(mDbm);
    }

    /** Construct from Parcel, type has already been processed */
    private CellIdentityLte(Parcel in) {
        super(TAG, CellInfo.TYPE_LTE, in);
        mCi = in.readInt();
        mPci = in.readInt();
        mTac = in.readInt();
        mEarfcn = in.readInt();
        mBands = in.createIntArray();
        mBandwidth = in.readInt();
        mAdditionalPlmns = (ArrayList<String>) in.readArrayList(null);
        mCsgIndicator = in.readByte() != 0; 
        mHomeNodebName = in.readString();
        mCsgIdentity = in.readInt() ;
        mDbm = in.readInt();
        updateGlobalCellId();
        if (DBG) log(toString());
    }

    /** Implement the Parcelable interface */
    @SuppressWarnings("hiding")
    public static final  Creator<CellIdentityLte> CREATOR =
            new Creator<CellIdentityLte>() {
                @Override
                public CellIdentityLte createFromParcel(Parcel in) {
                    in.readInt();   // skip;
                    return createFromParcelBody(in);
                }

                @Override
                public CellIdentityLte[] newArray(int size) {
                    return new CellIdentityLte[size];
                }
            };

    /** @hide */
    protected static CellIdentityLte createFromParcelBody(Parcel in) {
        return new CellIdentityLte(in);
    }
}
